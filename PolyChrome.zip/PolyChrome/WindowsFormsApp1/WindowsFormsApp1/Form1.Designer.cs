﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.notes_per_octave = new System.Windows.Forms.NumericUpDown();
            this.retune = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.C = new System.Windows.Forms.Button();
            this.wave_type = new System.Windows.Forms.ComboBox();
            this.C_Sharp = new System.Windows.Forms.Button();
            this.D = new System.Windows.Forms.Button();
            this.D_Sharp = new System.Windows.Forms.Button();
            this.E = new System.Windows.Forms.Button();
            this.F = new System.Windows.Forms.Button();
            this.F_Sharp = new System.Windows.Forms.Button();
            this.G = new System.Windows.Forms.Button();
            this.G_Sharp = new System.Windows.Forms.Button();
            this.A = new System.Windows.Forms.Button();
            this.A_Sharp = new System.Windows.Forms.Button();
            this.B = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.C_1 = new System.Windows.Forms.Button();
            this.C_2 = new System.Windows.Forms.Button();
            this.C_3 = new System.Windows.Forms.Button();
            this.C_4 = new System.Windows.Forms.Button();
            this.C_5 = new System.Windows.Forms.Button();
            this.C_6 = new System.Windows.Forms.Button();
            this.C_7 = new System.Windows.Forms.Button();
            this.C_8 = new System.Windows.Forms.Button();
            this.C_9 = new System.Windows.Forms.Button();
            this.C_10 = new System.Windows.Forms.Button();
            this.C_11 = new System.Windows.Forms.Button();
            this.C_12 = new System.Windows.Forms.Button();
            this.C_Sharp_1 = new System.Windows.Forms.Button();
            this.D_1 = new System.Windows.Forms.Button();
            this.D_Sharp_1 = new System.Windows.Forms.Button();
            this.E_1 = new System.Windows.Forms.Button();
            this.F_1 = new System.Windows.Forms.Button();
            this.F_Sharp_1 = new System.Windows.Forms.Button();
            this.G_1 = new System.Windows.Forms.Button();
            this.G_Sharp_1 = new System.Windows.Forms.Button();
            this.A_1 = new System.Windows.Forms.Button();
            this.A_Sharp_1 = new System.Windows.Forms.Button();
            this.B_1 = new System.Windows.Forms.Button();
            this.D_Cycle = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.C_Sharp_2 = new System.Windows.Forms.Button();
            this.D_2 = new System.Windows.Forms.Button();
            this.D_Sharp_2 = new System.Windows.Forms.Button();
            this.E_2 = new System.Windows.Forms.Button();
            this.F_2 = new System.Windows.Forms.Button();
            this.F_Sharp_2 = new System.Windows.Forms.Button();
            this.G_2 = new System.Windows.Forms.Button();
            this.G_Sharp_2 = new System.Windows.Forms.Button();
            this.A_2 = new System.Windows.Forms.Button();
            this.A_Sharp_2 = new System.Windows.Forms.Button();
            this.B_2 = new System.Windows.Forms.Button();
            this.C_Sharp_3 = new System.Windows.Forms.Button();
            this.D_3 = new System.Windows.Forms.Button();
            this.D_Sharp_3 = new System.Windows.Forms.Button();
            this.E_3 = new System.Windows.Forms.Button();
            this.F_3 = new System.Windows.Forms.Button();
            this.F_Sharp_3 = new System.Windows.Forms.Button();
            this.G_3 = new System.Windows.Forms.Button();
            this.G_Sharp_3 = new System.Windows.Forms.Button();
            this.A_3 = new System.Windows.Forms.Button();
            this.A_Sharp_3 = new System.Windows.Forms.Button();
            this.B_3 = new System.Windows.Forms.Button();
            this.C_Sharp_4 = new System.Windows.Forms.Button();
            this.D_4 = new System.Windows.Forms.Button();
            this.D_Sharp_4 = new System.Windows.Forms.Button();
            this.E_4 = new System.Windows.Forms.Button();
            this.F_4 = new System.Windows.Forms.Button();
            this.F_Sharp_4 = new System.Windows.Forms.Button();
            this.G_4 = new System.Windows.Forms.Button();
            this.G_Sharp_4 = new System.Windows.Forms.Button();
            this.A_4 = new System.Windows.Forms.Button();
            this.A_Sharp_4 = new System.Windows.Forms.Button();
            this.B_4 = new System.Windows.Forms.Button();
            this.C_Sharp_5 = new System.Windows.Forms.Button();
            this.D_5 = new System.Windows.Forms.Button();
            this.D_Sharp_5 = new System.Windows.Forms.Button();
            this.E_5 = new System.Windows.Forms.Button();
            this.F_5 = new System.Windows.Forms.Button();
            this.F_Sharp_5 = new System.Windows.Forms.Button();
            this.G_5 = new System.Windows.Forms.Button();
            this.G_Sharp_5 = new System.Windows.Forms.Button();
            this.A_5 = new System.Windows.Forms.Button();
            this.A_Sharp_5 = new System.Windows.Forms.Button();
            this.B_5 = new System.Windows.Forms.Button();
            this.C_Sharp_6 = new System.Windows.Forms.Button();
            this.D_6 = new System.Windows.Forms.Button();
            this.D_Sharp_6 = new System.Windows.Forms.Button();
            this.E_6 = new System.Windows.Forms.Button();
            this.F_6 = new System.Windows.Forms.Button();
            this.B_6 = new System.Windows.Forms.Button();
            this.F_Sharp_6 = new System.Windows.Forms.Button();
            this.G_6 = new System.Windows.Forms.Button();
            this.G_Sharp_6 = new System.Windows.Forms.Button();
            this.A_6 = new System.Windows.Forms.Button();
            this.A_Sharp_6 = new System.Windows.Forms.Button();
            this.C_Sharp_7 = new System.Windows.Forms.Button();
            this.D_7 = new System.Windows.Forms.Button();
            this.D_Sharp_7 = new System.Windows.Forms.Button();
            this.E_7 = new System.Windows.Forms.Button();
            this.F_7 = new System.Windows.Forms.Button();
            this.F_Sharp_7 = new System.Windows.Forms.Button();
            this.G_7 = new System.Windows.Forms.Button();
            this.G_Sharp_7 = new System.Windows.Forms.Button();
            this.A_7 = new System.Windows.Forms.Button();
            this.A_Sharp_7 = new System.Windows.Forms.Button();
            this.B_7 = new System.Windows.Forms.Button();
            this.C_Sharp_8 = new System.Windows.Forms.Button();
            this.D_8 = new System.Windows.Forms.Button();
            this.D_Sharp_8 = new System.Windows.Forms.Button();
            this.E_8 = new System.Windows.Forms.Button();
            this.F_8 = new System.Windows.Forms.Button();
            this.F_Sharp_8 = new System.Windows.Forms.Button();
            this.G_8 = new System.Windows.Forms.Button();
            this.G_Sharp_8 = new System.Windows.Forms.Button();
            this.A_8 = new System.Windows.Forms.Button();
            this.A_Sharp_8 = new System.Windows.Forms.Button();
            this.B_8 = new System.Windows.Forms.Button();
            this.C_Sharp_9 = new System.Windows.Forms.Button();
            this.D_9 = new System.Windows.Forms.Button();
            this.D_Sharp_9 = new System.Windows.Forms.Button();
            this.E_9 = new System.Windows.Forms.Button();
            this.F_9 = new System.Windows.Forms.Button();
            this.F_Sharp_9 = new System.Windows.Forms.Button();
            this.G_9 = new System.Windows.Forms.Button();
            this.G_Sharp_9 = new System.Windows.Forms.Button();
            this.A_9 = new System.Windows.Forms.Button();
            this.A_Sharp_9 = new System.Windows.Forms.Button();
            this.B_9 = new System.Windows.Forms.Button();
            this.C_Sharp_10 = new System.Windows.Forms.Button();
            this.D_10 = new System.Windows.Forms.Button();
            this.D_Sharp_10 = new System.Windows.Forms.Button();
            this.E_10 = new System.Windows.Forms.Button();
            this.F_10 = new System.Windows.Forms.Button();
            this.F_Sharp_10 = new System.Windows.Forms.Button();
            this.G_10 = new System.Windows.Forms.Button();
            this.G_Sharp_10 = new System.Windows.Forms.Button();
            this.A_10 = new System.Windows.Forms.Button();
            this.A_Sharp_10 = new System.Windows.Forms.Button();
            this.B_10 = new System.Windows.Forms.Button();
            this.C_Sharp_11 = new System.Windows.Forms.Button();
            this.D_11 = new System.Windows.Forms.Button();
            this.D_Sharp_11 = new System.Windows.Forms.Button();
            this.E_11 = new System.Windows.Forms.Button();
            this.F_11 = new System.Windows.Forms.Button();
            this.F_Sharp_11 = new System.Windows.Forms.Button();
            this.G_11 = new System.Windows.Forms.Button();
            this.G_Sharp_11 = new System.Windows.Forms.Button();
            this.A_11 = new System.Windows.Forms.Button();
            this.A_Sharp_11 = new System.Windows.Forms.Button();
            this.B_11 = new System.Windows.Forms.Button();
            this.C_Sharp_12 = new System.Windows.Forms.Button();
            this.D_12 = new System.Windows.Forms.Button();
            this.D_Sharp_12 = new System.Windows.Forms.Button();
            this.E_12 = new System.Windows.Forms.Button();
            this.F_12 = new System.Windows.Forms.Button();
            this.F_Sharp_12 = new System.Windows.Forms.Button();
            this.G_12 = new System.Windows.Forms.Button();
            this.G_Sharp_12 = new System.Windows.Forms.Button();
            this.A_12 = new System.Windows.Forms.Button();
            this.A_Sharp_12 = new System.Windows.Forms.Button();
            this.B_12 = new System.Windows.Forms.Button();
            this.Octave = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Amplitude = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.Color_Disp = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.notes_per_octave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.D_Cycle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Octave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Amplitude)).BeginInit();
            this.SuspendLayout();
            // 
            // notes_per_octave
            // 
            this.notes_per_octave.Location = new System.Drawing.Point(106, 11);
            this.notes_per_octave.Maximum = new decimal(new int[] {
            144,
            0,
            0,
            0});
            this.notes_per_octave.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.notes_per_octave.Name = "notes_per_octave";
            this.notes_per_octave.Size = new System.Drawing.Size(75, 20);
            this.notes_per_octave.TabIndex = 0;
            this.notes_per_octave.Value = new decimal(new int[] {
            12,
            0,
            0,
            0});
            // 
            // retune
            // 
            this.retune.Location = new System.Drawing.Point(106, 37);
            this.retune.Name = "retune";
            this.retune.Size = new System.Drawing.Size(75, 23);
            this.retune.TabIndex = 1;
            this.retune.Text = "Retune";
            this.retune.UseVisualStyleBackColor = true;
            this.retune.Click += new System.EventHandler(this.retune_Click);
            this.retune.MouseDown += new System.Windows.Forms.MouseEventHandler(this.retune_MouseDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Notes per Octave";
            // 
            // C
            // 
            this.C.Location = new System.Drawing.Point(12, 535);
            this.C.Name = "C";
            this.C.Size = new System.Drawing.Size(75, 23);
            this.C.TabIndex = 3;
            this.C.Text = "C4";
            this.C.UseVisualStyleBackColor = true;
            this.C.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_MouseDown);
            this.C.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_MouseUp);
            // 
            // wave_type
            // 
            this.wave_type.AutoCompleteCustomSource.AddRange(new string[] {
            "Sine",
            "Triangle",
            "Pulse",
            "Sawtooth"});
            this.wave_type.FormattingEnabled = true;
            this.wave_type.Items.AddRange(new object[] {
            "Sine",
            "Triangle",
            "Pulse",
            "Sawtooth"});
            this.wave_type.Location = new System.Drawing.Point(255, 10);
            this.wave_type.Name = "wave_type";
            this.wave_type.Size = new System.Drawing.Size(121, 21);
            this.wave_type.TabIndex = 4;
            this.wave_type.Text = "Sawtooth";
            this.wave_type.SelectedIndexChanged += new System.EventHandler(this.wave_type_SelectedIndexChanged);
            // 
            // C_Sharp
            // 
            this.C_Sharp.Location = new System.Drawing.Point(93, 535);
            this.C_Sharp.Name = "C_Sharp";
            this.C_Sharp.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp.TabIndex = 5;
            this.C_Sharp.Text = "C#4";
            this.C_Sharp.UseVisualStyleBackColor = true;
            this.C_Sharp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_MouseDown);
            this.C_Sharp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_MouseUp);
            // 
            // D
            // 
            this.D.Location = new System.Drawing.Point(174, 535);
            this.D.Name = "D";
            this.D.Size = new System.Drawing.Size(75, 23);
            this.D.TabIndex = 6;
            this.D.Text = "D4";
            this.D.UseVisualStyleBackColor = true;
            this.D.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_MouseDown);
            this.D.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_MouseUp);
            // 
            // D_Sharp
            // 
            this.D_Sharp.Location = new System.Drawing.Point(255, 535);
            this.D_Sharp.Name = "D_Sharp";
            this.D_Sharp.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp.TabIndex = 7;
            this.D_Sharp.Text = "D#4";
            this.D_Sharp.UseVisualStyleBackColor = true;
            this.D_Sharp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_MouseDown);
            this.D_Sharp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_MouseUp);
            // 
            // E
            // 
            this.E.Location = new System.Drawing.Point(336, 535);
            this.E.Name = "E";
            this.E.Size = new System.Drawing.Size(75, 23);
            this.E.TabIndex = 8;
            this.E.Text = "E4";
            this.E.UseVisualStyleBackColor = true;
            this.E.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_MouseDown);
            this.E.MouseUp += new System.Windows.Forms.MouseEventHandler(this.E_MouseUp);
            // 
            // F
            // 
            this.F.Location = new System.Drawing.Point(417, 535);
            this.F.Name = "F";
            this.F.Size = new System.Drawing.Size(75, 23);
            this.F.TabIndex = 9;
            this.F.Text = "F4";
            this.F.UseVisualStyleBackColor = true;
            this.F.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_MouseDown);
            this.F.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_MouseUp);
            // 
            // F_Sharp
            // 
            this.F_Sharp.Location = new System.Drawing.Point(498, 535);
            this.F_Sharp.Name = "F_Sharp";
            this.F_Sharp.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp.TabIndex = 10;
            this.F_Sharp.Text = "F#4";
            this.F_Sharp.UseVisualStyleBackColor = true;
            this.F_Sharp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_MouseDown);
            this.F_Sharp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_MouseUp);
            // 
            // G
            // 
            this.G.Location = new System.Drawing.Point(579, 535);
            this.G.Name = "G";
            this.G.Size = new System.Drawing.Size(75, 23);
            this.G.TabIndex = 11;
            this.G.Text = "G4";
            this.G.UseVisualStyleBackColor = true;
            this.G.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_MouseDown);
            this.G.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_MouseUp);
            // 
            // G_Sharp
            // 
            this.G_Sharp.Location = new System.Drawing.Point(660, 535);
            this.G_Sharp.Name = "G_Sharp";
            this.G_Sharp.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp.TabIndex = 12;
            this.G_Sharp.Text = "G#4";
            this.G_Sharp.UseVisualStyleBackColor = true;
            this.G_Sharp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_MouseDown);
            this.G_Sharp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_MouseUp);
            // 
            // A
            // 
            this.A.Location = new System.Drawing.Point(741, 535);
            this.A.Name = "A";
            this.A.Size = new System.Drawing.Size(75, 23);
            this.A.TabIndex = 13;
            this.A.Text = "A4";
            this.A.UseVisualStyleBackColor = true;
            this.A.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_MouseDown);
            this.A.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_MouseUp);
            // 
            // A_Sharp
            // 
            this.A_Sharp.Location = new System.Drawing.Point(822, 535);
            this.A_Sharp.Name = "A_Sharp";
            this.A_Sharp.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp.TabIndex = 14;
            this.A_Sharp.Text = "A#4";
            this.A_Sharp.UseVisualStyleBackColor = true;
            this.A_Sharp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_MouseDown);
            this.A_Sharp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_MouseUp);
            // 
            // B
            // 
            this.B.Location = new System.Drawing.Point(903, 535);
            this.B.Name = "B";
            this.B.Size = new System.Drawing.Size(75, 23);
            this.B.TabIndex = 15;
            this.B.Text = "B4";
            this.B.UseVisualStyleBackColor = true;
            this.B.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_MouseDown);
            this.B.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_MouseUp);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(187, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Wave Type";
            // 
            // C_1
            // 
            this.C_1.BackColor = System.Drawing.Color.Red;
            this.C_1.Location = new System.Drawing.Point(12, 506);
            this.C_1.Name = "C_1";
            this.C_1.Size = new System.Drawing.Size(75, 23);
            this.C_1.TabIndex = 17;
            this.C_1.UseVisualStyleBackColor = false;
            this.C_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_1_MouseDown);
            this.C_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_1_MouseUp);
            // 
            // C_2
            // 
            this.C_2.BackColor = System.Drawing.Color.LightGray;
            this.C_2.Enabled = false;
            this.C_2.Location = new System.Drawing.Point(12, 477);
            this.C_2.Name = "C_2";
            this.C_2.Size = new System.Drawing.Size(75, 23);
            this.C_2.TabIndex = 18;
            this.C_2.UseVisualStyleBackColor = false;
            this.C_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_2_MouseDown);
            this.C_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_2_MouseUp);
            // 
            // C_3
            // 
            this.C_3.BackColor = System.Drawing.Color.LightGray;
            this.C_3.Enabled = false;
            this.C_3.Location = new System.Drawing.Point(12, 448);
            this.C_3.Name = "C_3";
            this.C_3.Size = new System.Drawing.Size(75, 23);
            this.C_3.TabIndex = 19;
            this.C_3.UseVisualStyleBackColor = false;
            this.C_3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_3_MouseDown);
            this.C_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_3_MouseUp);
            // 
            // C_4
            // 
            this.C_4.BackColor = System.Drawing.Color.LightGray;
            this.C_4.Enabled = false;
            this.C_4.Location = new System.Drawing.Point(12, 419);
            this.C_4.Name = "C_4";
            this.C_4.Size = new System.Drawing.Size(75, 23);
            this.C_4.TabIndex = 20;
            this.C_4.UseVisualStyleBackColor = false;
            this.C_4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_4_MouseDown);
            this.C_4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_4_MouseUp);
            // 
            // C_5
            // 
            this.C_5.BackColor = System.Drawing.Color.LightGray;
            this.C_5.Enabled = false;
            this.C_5.Location = new System.Drawing.Point(12, 390);
            this.C_5.Name = "C_5";
            this.C_5.Size = new System.Drawing.Size(75, 23);
            this.C_5.TabIndex = 21;
            this.C_5.UseVisualStyleBackColor = false;
            this.C_5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_5_MouseDown);
            this.C_5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_5_MouseUp);
            // 
            // C_6
            // 
            this.C_6.BackColor = System.Drawing.Color.LightGray;
            this.C_6.Enabled = false;
            this.C_6.Location = new System.Drawing.Point(12, 361);
            this.C_6.Name = "C_6";
            this.C_6.Size = new System.Drawing.Size(75, 23);
            this.C_6.TabIndex = 22;
            this.C_6.UseVisualStyleBackColor = false;
            this.C_6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_6_MouseDown);
            this.C_6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_6_MouseUp);
            // 
            // C_7
            // 
            this.C_7.BackColor = System.Drawing.Color.LightGray;
            this.C_7.Enabled = false;
            this.C_7.Location = new System.Drawing.Point(12, 332);
            this.C_7.Name = "C_7";
            this.C_7.Size = new System.Drawing.Size(75, 23);
            this.C_7.TabIndex = 23;
            this.C_7.UseVisualStyleBackColor = false;
            this.C_7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_7_MouseDown);
            this.C_7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_7_MouseUp);
            // 
            // C_8
            // 
            this.C_8.BackColor = System.Drawing.Color.LightGray;
            this.C_8.Enabled = false;
            this.C_8.Location = new System.Drawing.Point(12, 303);
            this.C_8.Name = "C_8";
            this.C_8.Size = new System.Drawing.Size(75, 23);
            this.C_8.TabIndex = 24;
            this.C_8.UseVisualStyleBackColor = false;
            this.C_8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_8_MouseDown);
            this.C_8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_8_MouseUp);
            // 
            // C_9
            // 
            this.C_9.BackColor = System.Drawing.Color.LightGray;
            this.C_9.Enabled = false;
            this.C_9.Location = new System.Drawing.Point(12, 274);
            this.C_9.Name = "C_9";
            this.C_9.Size = new System.Drawing.Size(75, 23);
            this.C_9.TabIndex = 25;
            this.C_9.UseVisualStyleBackColor = false;
            this.C_9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_9_MouseDown);
            this.C_9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_9_MouseUp);
            // 
            // C_10
            // 
            this.C_10.BackColor = System.Drawing.Color.LightGray;
            this.C_10.Enabled = false;
            this.C_10.Location = new System.Drawing.Point(12, 245);
            this.C_10.Name = "C_10";
            this.C_10.Size = new System.Drawing.Size(75, 23);
            this.C_10.TabIndex = 26;
            this.C_10.UseVisualStyleBackColor = false;
            this.C_10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_10_MouseDown);
            this.C_10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_10_MouseUp);
            // 
            // C_11
            // 
            this.C_11.BackColor = System.Drawing.Color.LightGray;
            this.C_11.Enabled = false;
            this.C_11.Location = new System.Drawing.Point(12, 216);
            this.C_11.Name = "C_11";
            this.C_11.Size = new System.Drawing.Size(75, 23);
            this.C_11.TabIndex = 27;
            this.C_11.UseVisualStyleBackColor = false;
            this.C_11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_11_MouseDown);
            this.C_11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_11_MouseUp);
            // 
            // C_12
            // 
            this.C_12.BackColor = System.Drawing.Color.LightGray;
            this.C_12.Enabled = false;
            this.C_12.Location = new System.Drawing.Point(12, 187);
            this.C_12.Name = "C_12";
            this.C_12.Size = new System.Drawing.Size(75, 23);
            this.C_12.TabIndex = 28;
            this.C_12.UseVisualStyleBackColor = false;
            this.C_12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_12_MouseDown);
            this.C_12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_12_MouseUp);
            // 
            // C_Sharp_1
            // 
            this.C_Sharp_1.BackColor = System.Drawing.Color.Red;
            this.C_Sharp_1.Location = new System.Drawing.Point(93, 506);
            this.C_Sharp_1.Name = "C_Sharp_1";
            this.C_Sharp_1.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp_1.TabIndex = 29;
            this.C_Sharp_1.UseVisualStyleBackColor = false;
            this.C_Sharp_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_1_MouseDown);
            this.C_Sharp_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_1_MouseUp);
            // 
            // D_1
            // 
            this.D_1.BackColor = System.Drawing.Color.Red;
            this.D_1.Location = new System.Drawing.Point(174, 506);
            this.D_1.Name = "D_1";
            this.D_1.Size = new System.Drawing.Size(75, 23);
            this.D_1.TabIndex = 30;
            this.D_1.UseVisualStyleBackColor = false;
            this.D_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_1_MouseDown);
            this.D_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_1_MouseUp);
            // 
            // D_Sharp_1
            // 
            this.D_Sharp_1.BackColor = System.Drawing.Color.Red;
            this.D_Sharp_1.Location = new System.Drawing.Point(255, 506);
            this.D_Sharp_1.Name = "D_Sharp_1";
            this.D_Sharp_1.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp_1.TabIndex = 31;
            this.D_Sharp_1.UseVisualStyleBackColor = false;
            this.D_Sharp_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_1_MouseDown);
            this.D_Sharp_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_1_MouseUp);
            // 
            // E_1
            // 
            this.E_1.BackColor = System.Drawing.Color.Red;
            this.E_1.Location = new System.Drawing.Point(336, 506);
            this.E_1.Name = "E_1";
            this.E_1.Size = new System.Drawing.Size(75, 23);
            this.E_1.TabIndex = 32;
            this.E_1.UseVisualStyleBackColor = false;
            this.E_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_1_MouseDown);
            this.E_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.E_1_MouseUp);
            // 
            // F_1
            // 
            this.F_1.BackColor = System.Drawing.Color.Red;
            this.F_1.Location = new System.Drawing.Point(417, 506);
            this.F_1.Name = "F_1";
            this.F_1.Size = new System.Drawing.Size(75, 23);
            this.F_1.TabIndex = 33;
            this.F_1.UseVisualStyleBackColor = false;
            this.F_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_1_MouseDown);
            this.F_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_1_MouseUp);
            // 
            // F_Sharp_1
            // 
            this.F_Sharp_1.BackColor = System.Drawing.Color.Red;
            this.F_Sharp_1.Location = new System.Drawing.Point(498, 506);
            this.F_Sharp_1.Name = "F_Sharp_1";
            this.F_Sharp_1.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp_1.TabIndex = 34;
            this.F_Sharp_1.UseVisualStyleBackColor = false;
            this.F_Sharp_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_1_MouseDown);
            this.F_Sharp_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_1_MouseUp);
            // 
            // G_1
            // 
            this.G_1.BackColor = System.Drawing.Color.Red;
            this.G_1.Location = new System.Drawing.Point(579, 506);
            this.G_1.Name = "G_1";
            this.G_1.Size = new System.Drawing.Size(75, 23);
            this.G_1.TabIndex = 35;
            this.G_1.UseVisualStyleBackColor = false;
            this.G_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_1_MouseDown);
            this.G_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_1_MouseUp);
            // 
            // G_Sharp_1
            // 
            this.G_Sharp_1.BackColor = System.Drawing.Color.Red;
            this.G_Sharp_1.Location = new System.Drawing.Point(660, 506);
            this.G_Sharp_1.Name = "G_Sharp_1";
            this.G_Sharp_1.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp_1.TabIndex = 36;
            this.G_Sharp_1.UseVisualStyleBackColor = false;
            this.G_Sharp_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_1_MouseDown);
            this.G_Sharp_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_1_MouseUp);
            // 
            // A_1
            // 
            this.A_1.BackColor = System.Drawing.Color.Red;
            this.A_1.Location = new System.Drawing.Point(741, 506);
            this.A_1.Name = "A_1";
            this.A_1.Size = new System.Drawing.Size(75, 23);
            this.A_1.TabIndex = 37;
            this.A_1.UseVisualStyleBackColor = false;
            this.A_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_1_MouseDown);
            this.A_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_1_MouseUp);
            // 
            // A_Sharp_1
            // 
            this.A_Sharp_1.BackColor = System.Drawing.Color.Red;
            this.A_Sharp_1.Location = new System.Drawing.Point(822, 506);
            this.A_Sharp_1.Name = "A_Sharp_1";
            this.A_Sharp_1.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp_1.TabIndex = 38;
            this.A_Sharp_1.UseVisualStyleBackColor = false;
            this.A_Sharp_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_1_MouseDown);
            this.A_Sharp_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_1_MouseUp);
            // 
            // B_1
            // 
            this.B_1.BackColor = System.Drawing.Color.Red;
            this.B_1.Location = new System.Drawing.Point(903, 506);
            this.B_1.Name = "B_1";
            this.B_1.Size = new System.Drawing.Size(75, 23);
            this.B_1.TabIndex = 39;
            this.B_1.UseVisualStyleBackColor = false;
            this.B_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_1_MouseDown);
            this.B_1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_1_MouseUp);
            // 
            // D_Cycle
            // 
            this.D_Cycle.Location = new System.Drawing.Point(256, 37);
            this.D_Cycle.Name = "D_Cycle";
            this.D_Cycle.Size = new System.Drawing.Size(120, 20);
            this.D_Cycle.TabIndex = 41;
            this.D_Cycle.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.D_Cycle.ValueChanged += new System.EventHandler(this.D_Cycle_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(187, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 42;
            this.label3.Text = "Duty Cycle";
            // 
            // C_Sharp_2
            // 
            this.C_Sharp_2.BackColor = System.Drawing.Color.LightGray;
            this.C_Sharp_2.Enabled = false;
            this.C_Sharp_2.Location = new System.Drawing.Point(93, 477);
            this.C_Sharp_2.Name = "C_Sharp_2";
            this.C_Sharp_2.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp_2.TabIndex = 43;
            this.C_Sharp_2.UseVisualStyleBackColor = false;
            this.C_Sharp_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_2_MouseDown);
            this.C_Sharp_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_2_MouseUp);
            // 
            // D_2
            // 
            this.D_2.BackColor = System.Drawing.Color.LightGray;
            this.D_2.Enabled = false;
            this.D_2.Location = new System.Drawing.Point(174, 477);
            this.D_2.Name = "D_2";
            this.D_2.Size = new System.Drawing.Size(75, 23);
            this.D_2.TabIndex = 44;
            this.D_2.UseVisualStyleBackColor = false;
            this.D_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_2_MouseDown);
            this.D_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_2_MouseUp);
            // 
            // D_Sharp_2
            // 
            this.D_Sharp_2.BackColor = System.Drawing.Color.LightGray;
            this.D_Sharp_2.Enabled = false;
            this.D_Sharp_2.Location = new System.Drawing.Point(256, 477);
            this.D_Sharp_2.Name = "D_Sharp_2";
            this.D_Sharp_2.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp_2.TabIndex = 45;
            this.D_Sharp_2.UseVisualStyleBackColor = false;
            this.D_Sharp_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_2_MouseDown);
            this.D_Sharp_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_2_MouseUp);
            // 
            // E_2
            // 
            this.E_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.E_2.Location = new System.Drawing.Point(336, 477);
            this.E_2.Name = "E_2";
            this.E_2.Size = new System.Drawing.Size(75, 23);
            this.E_2.TabIndex = 46;
            this.E_2.UseVisualStyleBackColor = false;
            this.E_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_2_MouseDown);
            this.E_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.E_2_MouseUp);
            // 
            // F_2
            // 
            this.F_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.F_2.Location = new System.Drawing.Point(417, 477);
            this.F_2.Name = "F_2";
            this.F_2.Size = new System.Drawing.Size(75, 23);
            this.F_2.TabIndex = 47;
            this.F_2.UseVisualStyleBackColor = false;
            this.F_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_2_MouseDown);
            this.F_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_2_MouseUp);
            // 
            // F_Sharp_2
            // 
            this.F_Sharp_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.F_Sharp_2.Location = new System.Drawing.Point(498, 477);
            this.F_Sharp_2.Name = "F_Sharp_2";
            this.F_Sharp_2.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp_2.TabIndex = 48;
            this.F_Sharp_2.UseVisualStyleBackColor = false;
            this.F_Sharp_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_2_MouseDown);
            this.F_Sharp_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_2_MouseUp);
            // 
            // G_2
            // 
            this.G_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.G_2.Location = new System.Drawing.Point(579, 477);
            this.G_2.Name = "G_2";
            this.G_2.Size = new System.Drawing.Size(75, 23);
            this.G_2.TabIndex = 49;
            this.G_2.UseVisualStyleBackColor = false;
            this.G_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_2_MouseDown);
            this.G_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_2_MouseUp);
            // 
            // G_Sharp_2
            // 
            this.G_Sharp_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.G_Sharp_2.Location = new System.Drawing.Point(660, 477);
            this.G_Sharp_2.Name = "G_Sharp_2";
            this.G_Sharp_2.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp_2.TabIndex = 50;
            this.G_Sharp_2.UseVisualStyleBackColor = false;
            this.G_Sharp_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_2_MouseDown);
            this.G_Sharp_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_2_MouseUp);
            // 
            // A_2
            // 
            this.A_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.A_2.Location = new System.Drawing.Point(741, 477);
            this.A_2.Name = "A_2";
            this.A_2.Size = new System.Drawing.Size(75, 23);
            this.A_2.TabIndex = 51;
            this.A_2.UseVisualStyleBackColor = false;
            this.A_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_2_MouseDown);
            this.A_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_2_MouseUp);
            // 
            // A_Sharp_2
            // 
            this.A_Sharp_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.A_Sharp_2.Location = new System.Drawing.Point(822, 477);
            this.A_Sharp_2.Name = "A_Sharp_2";
            this.A_Sharp_2.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp_2.TabIndex = 52;
            this.A_Sharp_2.UseVisualStyleBackColor = false;
            this.A_Sharp_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_2_MouseDown);
            this.A_Sharp_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_2_MouseUp);
            // 
            // B_2
            // 
            this.B_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.B_2.Location = new System.Drawing.Point(903, 477);
            this.B_2.Name = "B_2";
            this.B_2.Size = new System.Drawing.Size(75, 23);
            this.B_2.TabIndex = 53;
            this.B_2.UseVisualStyleBackColor = false;
            this.B_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_2_MouseDown);
            this.B_2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_2_MouseUp);
            // 
            // C_Sharp_3
            // 
            this.C_Sharp_3.BackColor = System.Drawing.Color.LightGray;
            this.C_Sharp_3.Enabled = false;
            this.C_Sharp_3.Location = new System.Drawing.Point(93, 448);
            this.C_Sharp_3.Name = "C_Sharp_3";
            this.C_Sharp_3.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp_3.TabIndex = 54;
            this.C_Sharp_3.UseVisualStyleBackColor = false;
            this.C_Sharp_3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_3_MouseDown);
            this.C_Sharp_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_3_MouseUp);
            // 
            // D_3
            // 
            this.D_3.BackColor = System.Drawing.Color.LightGray;
            this.D_3.Enabled = false;
            this.D_3.Location = new System.Drawing.Point(174, 448);
            this.D_3.Name = "D_3";
            this.D_3.Size = new System.Drawing.Size(75, 23);
            this.D_3.TabIndex = 55;
            this.D_3.UseVisualStyleBackColor = false;
            this.D_3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_3_MouseDown);
            this.D_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_3_MouseUp);
            // 
            // D_Sharp_3
            // 
            this.D_Sharp_3.BackColor = System.Drawing.Color.LightGray;
            this.D_Sharp_3.Enabled = false;
            this.D_Sharp_3.Location = new System.Drawing.Point(256, 448);
            this.D_Sharp_3.Name = "D_Sharp_3";
            this.D_Sharp_3.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp_3.TabIndex = 56;
            this.D_Sharp_3.UseVisualStyleBackColor = false;
            this.D_Sharp_3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_3_MouseDown);
            this.D_Sharp_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_3_MouseUp);
            // 
            // E_3
            // 
            this.E_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(196)))), ((int)(((byte)(0)))));
            this.E_3.Location = new System.Drawing.Point(337, 448);
            this.E_3.Name = "E_3";
            this.E_3.Size = new System.Drawing.Size(75, 23);
            this.E_3.TabIndex = 57;
            this.E_3.UseVisualStyleBackColor = false;
            this.E_3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_3_MouseDown);
            this.E_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.E_3_MouseUp);
            // 
            // F_3
            // 
            this.F_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(196)))), ((int)(((byte)(0)))));
            this.F_3.Location = new System.Drawing.Point(418, 448);
            this.F_3.Name = "F_3";
            this.F_3.Size = new System.Drawing.Size(75, 23);
            this.F_3.TabIndex = 58;
            this.F_3.UseVisualStyleBackColor = false;
            this.F_3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_3_MouseDown);
            this.F_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_3_MouseUp);
            // 
            // F_Sharp_3
            // 
            this.F_Sharp_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(196)))), ((int)(((byte)(0)))));
            this.F_Sharp_3.Location = new System.Drawing.Point(499, 448);
            this.F_Sharp_3.Name = "F_Sharp_3";
            this.F_Sharp_3.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp_3.TabIndex = 59;
            this.F_Sharp_3.UseVisualStyleBackColor = false;
            this.F_Sharp_3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_3_MouseDown);
            this.F_Sharp_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_3_MouseUp);
            // 
            // G_3
            // 
            this.G_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(196)))), ((int)(((byte)(0)))));
            this.G_3.Location = new System.Drawing.Point(579, 448);
            this.G_3.Name = "G_3";
            this.G_3.Size = new System.Drawing.Size(75, 23);
            this.G_3.TabIndex = 60;
            this.G_3.UseVisualStyleBackColor = false;
            this.G_3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_3_MouseDown);
            this.G_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_3_MouseUp);
            // 
            // G_Sharp_3
            // 
            this.G_Sharp_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(196)))), ((int)(((byte)(0)))));
            this.G_Sharp_3.Location = new System.Drawing.Point(660, 448);
            this.G_Sharp_3.Name = "G_Sharp_3";
            this.G_Sharp_3.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp_3.TabIndex = 61;
            this.G_Sharp_3.UseVisualStyleBackColor = false;
            this.G_Sharp_3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_3_MouseDown);
            this.G_Sharp_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_3_MouseUp);
            // 
            // A_3
            // 
            this.A_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(196)))), ((int)(((byte)(0)))));
            this.A_3.Location = new System.Drawing.Point(741, 448);
            this.A_3.Name = "A_3";
            this.A_3.Size = new System.Drawing.Size(75, 23);
            this.A_3.TabIndex = 62;
            this.A_3.UseVisualStyleBackColor = false;
            this.A_3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_3_MouseDown);
            this.A_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_3_MouseUp);
            // 
            // A_Sharp_3
            // 
            this.A_Sharp_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(196)))), ((int)(((byte)(0)))));
            this.A_Sharp_3.Location = new System.Drawing.Point(822, 448);
            this.A_Sharp_3.Name = "A_Sharp_3";
            this.A_Sharp_3.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp_3.TabIndex = 63;
            this.A_Sharp_3.UseVisualStyleBackColor = false;
            this.A_Sharp_3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_3_MouseDown);
            this.A_Sharp_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_3_MouseUp);
            // 
            // B_3
            // 
            this.B_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(196)))), ((int)(((byte)(0)))));
            this.B_3.Location = new System.Drawing.Point(903, 448);
            this.B_3.Name = "B_3";
            this.B_3.Size = new System.Drawing.Size(75, 23);
            this.B_3.TabIndex = 64;
            this.B_3.UseVisualStyleBackColor = false;
            this.B_3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_3_MouseDown);
            this.B_3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_3_MouseUp);
            // 
            // C_Sharp_4
            // 
            this.C_Sharp_4.BackColor = System.Drawing.Color.LightGray;
            this.C_Sharp_4.Enabled = false;
            this.C_Sharp_4.Location = new System.Drawing.Point(93, 419);
            this.C_Sharp_4.Name = "C_Sharp_4";
            this.C_Sharp_4.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp_4.TabIndex = 65;
            this.C_Sharp_4.UseVisualStyleBackColor = false;
            this.C_Sharp_4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_4_MouseDown);
            this.C_Sharp_4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_4_MouseUp);
            // 
            // D_4
            // 
            this.D_4.BackColor = System.Drawing.Color.LightGray;
            this.D_4.Enabled = false;
            this.D_4.Location = new System.Drawing.Point(174, 419);
            this.D_4.Name = "D_4";
            this.D_4.Size = new System.Drawing.Size(75, 23);
            this.D_4.TabIndex = 66;
            this.D_4.UseVisualStyleBackColor = false;
            this.D_4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_4_MouseDown);
            this.D_4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_4_MouseUp);
            // 
            // D_Sharp_4
            // 
            this.D_Sharp_4.BackColor = System.Drawing.Color.LightGray;
            this.D_Sharp_4.Enabled = false;
            this.D_Sharp_4.Location = new System.Drawing.Point(256, 419);
            this.D_Sharp_4.Name = "D_Sharp_4";
            this.D_Sharp_4.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp_4.TabIndex = 67;
            this.D_Sharp_4.UseVisualStyleBackColor = false;
            this.D_Sharp_4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_4_MouseDown);
            this.D_Sharp_4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_4_MouseUp);
            // 
            // E_4
            // 
            this.E_4.BackColor = System.Drawing.Color.Yellow;
            this.E_4.Location = new System.Drawing.Point(336, 419);
            this.E_4.Name = "E_4";
            this.E_4.Size = new System.Drawing.Size(75, 23);
            this.E_4.TabIndex = 68;
            this.E_4.UseVisualStyleBackColor = false;
            this.E_4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_4_MouseDown);
            this.E_4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.E_4_MouseUp);
            // 
            // F_4
            // 
            this.F_4.BackColor = System.Drawing.Color.Yellow;
            this.F_4.Location = new System.Drawing.Point(418, 419);
            this.F_4.Name = "F_4";
            this.F_4.Size = new System.Drawing.Size(75, 23);
            this.F_4.TabIndex = 69;
            this.F_4.UseVisualStyleBackColor = false;
            this.F_4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_4_MouseDown);
            this.F_4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_4_MouseUp);
            // 
            // F_Sharp_4
            // 
            this.F_Sharp_4.BackColor = System.Drawing.Color.Yellow;
            this.F_Sharp_4.Location = new System.Drawing.Point(498, 419);
            this.F_Sharp_4.Name = "F_Sharp_4";
            this.F_Sharp_4.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp_4.TabIndex = 70;
            this.F_Sharp_4.UseVisualStyleBackColor = false;
            this.F_Sharp_4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_4_MouseDown);
            this.F_Sharp_4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_4_MouseUp);
            // 
            // G_4
            // 
            this.G_4.BackColor = System.Drawing.Color.Yellow;
            this.G_4.Location = new System.Drawing.Point(579, 419);
            this.G_4.Name = "G_4";
            this.G_4.Size = new System.Drawing.Size(75, 23);
            this.G_4.TabIndex = 71;
            this.G_4.UseVisualStyleBackColor = false;
            this.G_4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_4_MouseDown);
            this.G_4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_4_MouseUp);
            // 
            // G_Sharp_4
            // 
            this.G_Sharp_4.BackColor = System.Drawing.Color.Yellow;
            this.G_Sharp_4.Location = new System.Drawing.Point(660, 419);
            this.G_Sharp_4.Name = "G_Sharp_4";
            this.G_Sharp_4.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp_4.TabIndex = 72;
            this.G_Sharp_4.UseVisualStyleBackColor = false;
            this.G_Sharp_4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_4_MouseDown);
            this.G_Sharp_4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_4_MouseUp);
            // 
            // A_4
            // 
            this.A_4.BackColor = System.Drawing.Color.Yellow;
            this.A_4.Location = new System.Drawing.Point(741, 419);
            this.A_4.Name = "A_4";
            this.A_4.Size = new System.Drawing.Size(75, 23);
            this.A_4.TabIndex = 73;
            this.A_4.UseVisualStyleBackColor = false;
            this.A_4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_4_MouseDown);
            this.A_4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_4_MouseUp);
            // 
            // A_Sharp_4
            // 
            this.A_Sharp_4.BackColor = System.Drawing.Color.Yellow;
            this.A_Sharp_4.Location = new System.Drawing.Point(822, 419);
            this.A_Sharp_4.Name = "A_Sharp_4";
            this.A_Sharp_4.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp_4.TabIndex = 74;
            this.A_Sharp_4.UseVisualStyleBackColor = false;
            this.A_Sharp_4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_4_MouseDown);
            this.A_Sharp_4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_4_MouseUp);
            // 
            // B_4
            // 
            this.B_4.BackColor = System.Drawing.Color.Yellow;
            this.B_4.Location = new System.Drawing.Point(903, 419);
            this.B_4.Name = "B_4";
            this.B_4.Size = new System.Drawing.Size(75, 23);
            this.B_4.TabIndex = 75;
            this.B_4.UseVisualStyleBackColor = false;
            this.B_4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_4_MouseDown);
            this.B_4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_4_MouseUp);
            // 
            // C_Sharp_5
            // 
            this.C_Sharp_5.BackColor = System.Drawing.Color.LightGray;
            this.C_Sharp_5.Enabled = false;
            this.C_Sharp_5.Location = new System.Drawing.Point(93, 390);
            this.C_Sharp_5.Name = "C_Sharp_5";
            this.C_Sharp_5.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp_5.TabIndex = 76;
            this.C_Sharp_5.UseVisualStyleBackColor = false;
            this.C_Sharp_5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_5_MouseDown);
            this.C_Sharp_5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_5_MouseUp);
            // 
            // D_5
            // 
            this.D_5.BackColor = System.Drawing.Color.LightGray;
            this.D_5.Enabled = false;
            this.D_5.Location = new System.Drawing.Point(175, 390);
            this.D_5.Name = "D_5";
            this.D_5.Size = new System.Drawing.Size(75, 23);
            this.D_5.TabIndex = 77;
            this.D_5.UseVisualStyleBackColor = false;
            this.D_5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_5_MouseDown);
            this.D_5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_5_MouseUp);
            // 
            // D_Sharp_5
            // 
            this.D_Sharp_5.BackColor = System.Drawing.Color.LightGray;
            this.D_Sharp_5.Enabled = false;
            this.D_Sharp_5.Location = new System.Drawing.Point(256, 390);
            this.D_Sharp_5.Name = "D_Sharp_5";
            this.D_Sharp_5.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp_5.TabIndex = 78;
            this.D_Sharp_5.UseVisualStyleBackColor = false;
            this.D_Sharp_5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_5_MouseDown);
            this.D_Sharp_5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_5_MouseUp);
            // 
            // E_5
            // 
            this.E_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.E_5.Location = new System.Drawing.Point(337, 390);
            this.E_5.Name = "E_5";
            this.E_5.Size = new System.Drawing.Size(75, 23);
            this.E_5.TabIndex = 79;
            this.E_5.UseVisualStyleBackColor = false;
            this.E_5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_5_MouseDown);
            this.E_5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.E_5_MouseUp);
            // 
            // F_5
            // 
            this.F_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.F_5.Location = new System.Drawing.Point(418, 390);
            this.F_5.Name = "F_5";
            this.F_5.Size = new System.Drawing.Size(75, 23);
            this.F_5.TabIndex = 80;
            this.F_5.UseVisualStyleBackColor = false;
            this.F_5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_5_MouseDown);
            this.F_5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_5_MouseUp);
            // 
            // F_Sharp_5
            // 
            this.F_Sharp_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.F_Sharp_5.Location = new System.Drawing.Point(498, 390);
            this.F_Sharp_5.Name = "F_Sharp_5";
            this.F_Sharp_5.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp_5.TabIndex = 81;
            this.F_Sharp_5.UseVisualStyleBackColor = false;
            this.F_Sharp_5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_5_MouseDown);
            this.F_Sharp_5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_5_MouseUp);
            // 
            // G_5
            // 
            this.G_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.G_5.Location = new System.Drawing.Point(579, 390);
            this.G_5.Name = "G_5";
            this.G_5.Size = new System.Drawing.Size(75, 23);
            this.G_5.TabIndex = 82;
            this.G_5.UseVisualStyleBackColor = false;
            this.G_5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_5_MouseDown);
            this.G_5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_5_MouseUp);
            // 
            // G_Sharp_5
            // 
            this.G_Sharp_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.G_Sharp_5.Location = new System.Drawing.Point(660, 390);
            this.G_Sharp_5.Name = "G_Sharp_5";
            this.G_Sharp_5.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp_5.TabIndex = 83;
            this.G_Sharp_5.UseVisualStyleBackColor = false;
            this.G_Sharp_5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_5_MouseDown);
            this.G_Sharp_5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_5_MouseUp);
            // 
            // A_5
            // 
            this.A_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.A_5.Location = new System.Drawing.Point(741, 390);
            this.A_5.Name = "A_5";
            this.A_5.Size = new System.Drawing.Size(75, 23);
            this.A_5.TabIndex = 84;
            this.A_5.UseVisualStyleBackColor = false;
            this.A_5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_5_MouseDown);
            this.A_5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_5_MouseUp);
            // 
            // A_Sharp_5
            // 
            this.A_Sharp_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.A_Sharp_5.Location = new System.Drawing.Point(822, 390);
            this.A_Sharp_5.Name = "A_Sharp_5";
            this.A_Sharp_5.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp_5.TabIndex = 85;
            this.A_Sharp_5.UseVisualStyleBackColor = false;
            this.A_Sharp_5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_5_MouseDown);
            this.A_Sharp_5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_5_MouseUp);
            // 
            // B_5
            // 
            this.B_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
            this.B_5.Location = new System.Drawing.Point(903, 390);
            this.B_5.Name = "B_5";
            this.B_5.Size = new System.Drawing.Size(75, 23);
            this.B_5.TabIndex = 86;
            this.B_5.UseVisualStyleBackColor = false;
            this.B_5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_5_MouseDown);
            this.B_5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_5_MouseUp);
            // 
            // C_Sharp_6
            // 
            this.C_Sharp_6.BackColor = System.Drawing.Color.LightGray;
            this.C_Sharp_6.Enabled = false;
            this.C_Sharp_6.Location = new System.Drawing.Point(93, 362);
            this.C_Sharp_6.Name = "C_Sharp_6";
            this.C_Sharp_6.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp_6.TabIndex = 87;
            this.C_Sharp_6.UseVisualStyleBackColor = false;
            this.C_Sharp_6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_6_MouseDown);
            this.C_Sharp_6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_6_MouseUp);
            // 
            // D_6
            // 
            this.D_6.BackColor = System.Drawing.Color.LightGray;
            this.D_6.Enabled = false;
            this.D_6.Location = new System.Drawing.Point(175, 362);
            this.D_6.Name = "D_6";
            this.D_6.Size = new System.Drawing.Size(75, 23);
            this.D_6.TabIndex = 88;
            this.D_6.UseVisualStyleBackColor = false;
            this.D_6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_6_MouseDown);
            this.D_6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_6_MouseUp);
            // 
            // D_Sharp_6
            // 
            this.D_Sharp_6.BackColor = System.Drawing.Color.LightGray;
            this.D_Sharp_6.Enabled = false;
            this.D_Sharp_6.Location = new System.Drawing.Point(256, 362);
            this.D_Sharp_6.Name = "D_Sharp_6";
            this.D_Sharp_6.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp_6.TabIndex = 89;
            this.D_Sharp_6.UseVisualStyleBackColor = false;
            this.D_Sharp_6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_6_MouseDown);
            this.D_Sharp_6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_6_MouseUp);
            // 
            // E_6
            // 
            this.E_6.BackColor = System.Drawing.Color.Lime;
            this.E_6.Location = new System.Drawing.Point(337, 362);
            this.E_6.Name = "E_6";
            this.E_6.Size = new System.Drawing.Size(75, 23);
            this.E_6.TabIndex = 90;
            this.E_6.UseVisualStyleBackColor = false;
            this.E_6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_6_MouseDown);
            this.E_6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.E_6_MouseUp);
            // 
            // F_6
            // 
            this.F_6.BackColor = System.Drawing.Color.Lime;
            this.F_6.Location = new System.Drawing.Point(417, 362);
            this.F_6.Name = "F_6";
            this.F_6.Size = new System.Drawing.Size(75, 23);
            this.F_6.TabIndex = 91;
            this.F_6.UseVisualStyleBackColor = false;
            this.F_6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_6_MouseDown);
            this.F_6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_6_MouseUp);
            // 
            // B_6
            // 
            this.B_6.BackColor = System.Drawing.Color.Lime;
            this.B_6.Location = new System.Drawing.Point(903, 362);
            this.B_6.Name = "B_6";
            this.B_6.Size = new System.Drawing.Size(75, 23);
            this.B_6.TabIndex = 92;
            this.B_6.UseVisualStyleBackColor = false;
            this.B_6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_6_MouseDown);
            this.B_6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_6_MouseUp);
            // 
            // F_Sharp_6
            // 
            this.F_Sharp_6.BackColor = System.Drawing.Color.Lime;
            this.F_Sharp_6.Location = new System.Drawing.Point(498, 362);
            this.F_Sharp_6.Name = "F_Sharp_6";
            this.F_Sharp_6.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp_6.TabIndex = 93;
            this.F_Sharp_6.UseVisualStyleBackColor = false;
            this.F_Sharp_6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_6_MouseDown);
            this.F_Sharp_6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_6_MouseUp);
            // 
            // G_6
            // 
            this.G_6.BackColor = System.Drawing.Color.Lime;
            this.G_6.Location = new System.Drawing.Point(579, 362);
            this.G_6.Name = "G_6";
            this.G_6.Size = new System.Drawing.Size(75, 23);
            this.G_6.TabIndex = 94;
            this.G_6.UseVisualStyleBackColor = false;
            this.G_6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_6_MouseDown);
            this.G_6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_6_MouseUp);
            // 
            // G_Sharp_6
            // 
            this.G_Sharp_6.BackColor = System.Drawing.Color.Lime;
            this.G_Sharp_6.Location = new System.Drawing.Point(660, 362);
            this.G_Sharp_6.Name = "G_Sharp_6";
            this.G_Sharp_6.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp_6.TabIndex = 95;
            this.G_Sharp_6.UseVisualStyleBackColor = false;
            this.G_Sharp_6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_6_MouseDown);
            this.G_Sharp_6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_6_MouseUp);
            // 
            // A_6
            // 
            this.A_6.BackColor = System.Drawing.Color.Lime;
            this.A_6.Location = new System.Drawing.Point(741, 362);
            this.A_6.Name = "A_6";
            this.A_6.Size = new System.Drawing.Size(75, 23);
            this.A_6.TabIndex = 96;
            this.A_6.UseVisualStyleBackColor = false;
            this.A_6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_6_MouseDown);
            this.A_6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_6_MouseUp);
            // 
            // A_Sharp_6
            // 
            this.A_Sharp_6.BackColor = System.Drawing.Color.Lime;
            this.A_Sharp_6.Location = new System.Drawing.Point(822, 362);
            this.A_Sharp_6.Name = "A_Sharp_6";
            this.A_Sharp_6.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp_6.TabIndex = 97;
            this.A_Sharp_6.UseVisualStyleBackColor = false;
            this.A_Sharp_6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_6_MouseDown);
            this.A_Sharp_6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_6_MouseUp);
            // 
            // C_Sharp_7
            // 
            this.C_Sharp_7.BackColor = System.Drawing.Color.LightGray;
            this.C_Sharp_7.Enabled = false;
            this.C_Sharp_7.Location = new System.Drawing.Point(93, 333);
            this.C_Sharp_7.Name = "C_Sharp_7";
            this.C_Sharp_7.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp_7.TabIndex = 98;
            this.C_Sharp_7.UseVisualStyleBackColor = false;
            this.C_Sharp_7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_7_MouseDown);
            this.C_Sharp_7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_7_MouseUp);
            // 
            // D_7
            // 
            this.D_7.BackColor = System.Drawing.Color.LightGray;
            this.D_7.Enabled = false;
            this.D_7.Location = new System.Drawing.Point(175, 333);
            this.D_7.Name = "D_7";
            this.D_7.Size = new System.Drawing.Size(75, 23);
            this.D_7.TabIndex = 99;
            this.D_7.UseVisualStyleBackColor = false;
            this.D_7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_7_MouseDown);
            this.D_7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_7_MouseUp);
            // 
            // D_Sharp_7
            // 
            this.D_Sharp_7.BackColor = System.Drawing.Color.LightGray;
            this.D_Sharp_7.Enabled = false;
            this.D_Sharp_7.Location = new System.Drawing.Point(255, 333);
            this.D_Sharp_7.Name = "D_Sharp_7";
            this.D_Sharp_7.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp_7.TabIndex = 100;
            this.D_Sharp_7.UseVisualStyleBackColor = false;
            this.D_Sharp_7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_7_MouseDown);
            this.D_Sharp_7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_7_MouseUp);
            // 
            // E_7
            // 
            this.E_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(196)))));
            this.E_7.Location = new System.Drawing.Point(336, 333);
            this.E_7.Name = "E_7";
            this.E_7.Size = new System.Drawing.Size(75, 23);
            this.E_7.TabIndex = 101;
            this.E_7.UseVisualStyleBackColor = false;
            this.E_7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_7_MouseDown);
            this.E_7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.E_7_MouseUp);
            // 
            // F_7
            // 
            this.F_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(196)))));
            this.F_7.Location = new System.Drawing.Point(418, 333);
            this.F_7.Name = "F_7";
            this.F_7.Size = new System.Drawing.Size(75, 23);
            this.F_7.TabIndex = 102;
            this.F_7.UseVisualStyleBackColor = false;
            this.F_7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_7_MouseDown);
            this.F_7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_7_MouseUp);
            // 
            // F_Sharp_7
            // 
            this.F_Sharp_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(196)))));
            this.F_Sharp_7.Location = new System.Drawing.Point(498, 333);
            this.F_Sharp_7.Name = "F_Sharp_7";
            this.F_Sharp_7.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp_7.TabIndex = 103;
            this.F_Sharp_7.UseVisualStyleBackColor = false;
            this.F_Sharp_7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_7_MouseDown);
            this.F_Sharp_7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_7_MouseUp);
            // 
            // G_7
            // 
            this.G_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(196)))));
            this.G_7.Location = new System.Drawing.Point(579, 333);
            this.G_7.Name = "G_7";
            this.G_7.Size = new System.Drawing.Size(75, 23);
            this.G_7.TabIndex = 104;
            this.G_7.UseVisualStyleBackColor = false;
            this.G_7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_7_MouseDown);
            this.G_7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_7_MouseUp);
            // 
            // G_Sharp_7
            // 
            this.G_Sharp_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(196)))));
            this.G_Sharp_7.Location = new System.Drawing.Point(660, 333);
            this.G_Sharp_7.Name = "G_Sharp_7";
            this.G_Sharp_7.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp_7.TabIndex = 105;
            this.G_Sharp_7.UseVisualStyleBackColor = false;
            this.G_Sharp_7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_7_MouseDown);
            this.G_Sharp_7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_7_MouseUp);
            // 
            // A_7
            // 
            this.A_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(196)))));
            this.A_7.Location = new System.Drawing.Point(741, 333);
            this.A_7.Name = "A_7";
            this.A_7.Size = new System.Drawing.Size(75, 23);
            this.A_7.TabIndex = 106;
            this.A_7.UseVisualStyleBackColor = false;
            this.A_7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_7_MouseDown);
            this.A_7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_7_MouseUp);
            // 
            // A_Sharp_7
            // 
            this.A_Sharp_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(196)))));
            this.A_Sharp_7.Location = new System.Drawing.Point(822, 333);
            this.A_Sharp_7.Name = "A_Sharp_7";
            this.A_Sharp_7.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp_7.TabIndex = 107;
            this.A_Sharp_7.UseVisualStyleBackColor = false;
            this.A_Sharp_7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_7_MouseDown);
            this.A_Sharp_7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_7_MouseUp);
            // 
            // B_7
            // 
            this.B_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(196)))));
            this.B_7.Location = new System.Drawing.Point(903, 333);
            this.B_7.Name = "B_7";
            this.B_7.Size = new System.Drawing.Size(75, 23);
            this.B_7.TabIndex = 108;
            this.B_7.UseVisualStyleBackColor = false;
            this.B_7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_7_MouseDown);
            this.B_7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_7_MouseUp);
            // 
            // C_Sharp_8
            // 
            this.C_Sharp_8.BackColor = System.Drawing.Color.LightGray;
            this.C_Sharp_8.Enabled = false;
            this.C_Sharp_8.Location = new System.Drawing.Point(93, 303);
            this.C_Sharp_8.Name = "C_Sharp_8";
            this.C_Sharp_8.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp_8.TabIndex = 109;
            this.C_Sharp_8.UseVisualStyleBackColor = false;
            this.C_Sharp_8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_8_MouseDown);
            this.C_Sharp_8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_8_MouseUp);
            // 
            // D_8
            // 
            this.D_8.BackColor = System.Drawing.Color.LightGray;
            this.D_8.Enabled = false;
            this.D_8.Location = new System.Drawing.Point(174, 303);
            this.D_8.Name = "D_8";
            this.D_8.Size = new System.Drawing.Size(75, 23);
            this.D_8.TabIndex = 110;
            this.D_8.UseVisualStyleBackColor = false;
            this.D_8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_8_MouseDown);
            this.D_8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_8_MouseUp);
            // 
            // D_Sharp_8
            // 
            this.D_Sharp_8.BackColor = System.Drawing.Color.LightGray;
            this.D_Sharp_8.Enabled = false;
            this.D_Sharp_8.Location = new System.Drawing.Point(255, 303);
            this.D_Sharp_8.Name = "D_Sharp_8";
            this.D_Sharp_8.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp_8.TabIndex = 111;
            this.D_Sharp_8.UseVisualStyleBackColor = false;
            this.D_Sharp_8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_8_MouseDown);
            this.D_Sharp_8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_8_MouseUp);
            // 
            // E_8
            // 
            this.E_8.BackColor = System.Drawing.Color.Cyan;
            this.E_8.Location = new System.Drawing.Point(336, 303);
            this.E_8.Name = "E_8";
            this.E_8.Size = new System.Drawing.Size(75, 23);
            this.E_8.TabIndex = 112;
            this.E_8.UseVisualStyleBackColor = false;
            this.E_8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_8_MouseDown);
            this.E_8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.E_8_MouseUp);
            // 
            // F_8
            // 
            this.F_8.BackColor = System.Drawing.Color.Cyan;
            this.F_8.Location = new System.Drawing.Point(417, 303);
            this.F_8.Name = "F_8";
            this.F_8.Size = new System.Drawing.Size(75, 23);
            this.F_8.TabIndex = 113;
            this.F_8.UseVisualStyleBackColor = false;
            this.F_8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_8_MouseDown);
            this.F_8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_8_MouseUp);
            // 
            // F_Sharp_8
            // 
            this.F_Sharp_8.BackColor = System.Drawing.Color.Cyan;
            this.F_Sharp_8.Location = new System.Drawing.Point(498, 303);
            this.F_Sharp_8.Name = "F_Sharp_8";
            this.F_Sharp_8.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp_8.TabIndex = 114;
            this.F_Sharp_8.UseVisualStyleBackColor = false;
            this.F_Sharp_8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_8_MouseDown);
            this.F_Sharp_8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_8_MouseUp);
            // 
            // G_8
            // 
            this.G_8.BackColor = System.Drawing.Color.Cyan;
            this.G_8.Location = new System.Drawing.Point(579, 303);
            this.G_8.Name = "G_8";
            this.G_8.Size = new System.Drawing.Size(75, 23);
            this.G_8.TabIndex = 115;
            this.G_8.UseVisualStyleBackColor = false;
            this.G_8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_8_MouseDown);
            this.G_8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_8_MouseUp);
            // 
            // G_Sharp_8
            // 
            this.G_Sharp_8.BackColor = System.Drawing.Color.Cyan;
            this.G_Sharp_8.Location = new System.Drawing.Point(660, 303);
            this.G_Sharp_8.Name = "G_Sharp_8";
            this.G_Sharp_8.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp_8.TabIndex = 116;
            this.G_Sharp_8.UseVisualStyleBackColor = false;
            this.G_Sharp_8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_8_MouseDown);
            this.G_Sharp_8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_8_MouseUp);
            // 
            // A_8
            // 
            this.A_8.BackColor = System.Drawing.Color.Cyan;
            this.A_8.Location = new System.Drawing.Point(741, 303);
            this.A_8.Name = "A_8";
            this.A_8.Size = new System.Drawing.Size(75, 23);
            this.A_8.TabIndex = 117;
            this.A_8.UseVisualStyleBackColor = false;
            this.A_8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_8_MouseDown);
            this.A_8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_8_MouseUp);
            // 
            // A_Sharp_8
            // 
            this.A_Sharp_8.BackColor = System.Drawing.Color.Cyan;
            this.A_Sharp_8.Location = new System.Drawing.Point(822, 303);
            this.A_Sharp_8.Name = "A_Sharp_8";
            this.A_Sharp_8.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp_8.TabIndex = 118;
            this.A_Sharp_8.UseVisualStyleBackColor = false;
            this.A_Sharp_8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_8_MouseDown);
            this.A_Sharp_8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_8_MouseUp);
            // 
            // B_8
            // 
            this.B_8.BackColor = System.Drawing.Color.Cyan;
            this.B_8.Location = new System.Drawing.Point(903, 303);
            this.B_8.Name = "B_8";
            this.B_8.Size = new System.Drawing.Size(75, 23);
            this.B_8.TabIndex = 119;
            this.B_8.UseVisualStyleBackColor = false;
            this.B_8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_8_MouseDown);
            this.B_8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_8_MouseUp);
            // 
            // C_Sharp_9
            // 
            this.C_Sharp_9.BackColor = System.Drawing.Color.LightGray;
            this.C_Sharp_9.Enabled = false;
            this.C_Sharp_9.Location = new System.Drawing.Point(93, 274);
            this.C_Sharp_9.Name = "C_Sharp_9";
            this.C_Sharp_9.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp_9.TabIndex = 120;
            this.C_Sharp_9.UseVisualStyleBackColor = false;
            this.C_Sharp_9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_9_MouseDown);
            this.C_Sharp_9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_9_MouseUp);
            // 
            // D_9
            // 
            this.D_9.BackColor = System.Drawing.Color.LightGray;
            this.D_9.Enabled = false;
            this.D_9.Location = new System.Drawing.Point(175, 274);
            this.D_9.Name = "D_9";
            this.D_9.Size = new System.Drawing.Size(75, 23);
            this.D_9.TabIndex = 121;
            this.D_9.UseVisualStyleBackColor = false;
            this.D_9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_9_MouseDown);
            this.D_9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_9_MouseUp);
            // 
            // D_Sharp_9
            // 
            this.D_Sharp_9.BackColor = System.Drawing.Color.LightGray;
            this.D_Sharp_9.Enabled = false;
            this.D_Sharp_9.Location = new System.Drawing.Point(255, 274);
            this.D_Sharp_9.Name = "D_Sharp_9";
            this.D_Sharp_9.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp_9.TabIndex = 122;
            this.D_Sharp_9.UseVisualStyleBackColor = false;
            this.D_Sharp_9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_9_MouseDown);
            this.D_Sharp_9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_9_MouseUp);
            // 
            // E_9
            // 
            this.E_9.BackColor = System.Drawing.Color.Blue;
            this.E_9.Location = new System.Drawing.Point(336, 274);
            this.E_9.Name = "E_9";
            this.E_9.Size = new System.Drawing.Size(75, 23);
            this.E_9.TabIndex = 123;
            this.E_9.UseVisualStyleBackColor = false;
            this.E_9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_9_MouseDown);
            this.E_9.MouseMove += new System.Windows.Forms.MouseEventHandler(this.E_9_MouseMove);
            // 
            // F_9
            // 
            this.F_9.BackColor = System.Drawing.Color.Blue;
            this.F_9.Location = new System.Drawing.Point(417, 274);
            this.F_9.Name = "F_9";
            this.F_9.Size = new System.Drawing.Size(75, 23);
            this.F_9.TabIndex = 124;
            this.F_9.UseVisualStyleBackColor = false;
            this.F_9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_9_MouseDown);
            this.F_9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_9_MouseUp);
            // 
            // F_Sharp_9
            // 
            this.F_Sharp_9.BackColor = System.Drawing.Color.Blue;
            this.F_Sharp_9.Location = new System.Drawing.Point(498, 274);
            this.F_Sharp_9.Name = "F_Sharp_9";
            this.F_Sharp_9.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp_9.TabIndex = 125;
            this.F_Sharp_9.UseVisualStyleBackColor = false;
            this.F_Sharp_9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_9_MouseDown);
            this.F_Sharp_9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_9_MouseUp);
            // 
            // G_9
            // 
            this.G_9.BackColor = System.Drawing.Color.Blue;
            this.G_9.Location = new System.Drawing.Point(579, 274);
            this.G_9.Name = "G_9";
            this.G_9.Size = new System.Drawing.Size(75, 23);
            this.G_9.TabIndex = 126;
            this.G_9.UseVisualStyleBackColor = false;
            this.G_9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_9_MouseDown);
            this.G_9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_9_MouseUp);
            // 
            // G_Sharp_9
            // 
            this.G_Sharp_9.BackColor = System.Drawing.Color.Blue;
            this.G_Sharp_9.Location = new System.Drawing.Point(660, 274);
            this.G_Sharp_9.Name = "G_Sharp_9";
            this.G_Sharp_9.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp_9.TabIndex = 127;
            this.G_Sharp_9.UseVisualStyleBackColor = false;
            this.G_Sharp_9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_9_MouseDown);
            this.G_Sharp_9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_9_MouseUp);
            // 
            // A_9
            // 
            this.A_9.BackColor = System.Drawing.Color.Blue;
            this.A_9.Location = new System.Drawing.Point(741, 274);
            this.A_9.Name = "A_9";
            this.A_9.Size = new System.Drawing.Size(75, 23);
            this.A_9.TabIndex = 128;
            this.A_9.UseVisualStyleBackColor = false;
            this.A_9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_9_MouseDown);
            this.A_9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_9_MouseUp);
            // 
            // A_Sharp_9
            // 
            this.A_Sharp_9.BackColor = System.Drawing.Color.Blue;
            this.A_Sharp_9.Location = new System.Drawing.Point(822, 274);
            this.A_Sharp_9.Name = "A_Sharp_9";
            this.A_Sharp_9.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp_9.TabIndex = 129;
            this.A_Sharp_9.UseVisualStyleBackColor = false;
            this.A_Sharp_9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_9_MouseDown);
            this.A_Sharp_9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_9_MouseUp);
            // 
            // B_9
            // 
            this.B_9.BackColor = System.Drawing.Color.Blue;
            this.B_9.Location = new System.Drawing.Point(903, 274);
            this.B_9.Name = "B_9";
            this.B_9.Size = new System.Drawing.Size(75, 23);
            this.B_9.TabIndex = 130;
            this.B_9.UseVisualStyleBackColor = false;
            this.B_9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_9_MouseDown);
            this.B_9.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_9_MouseUp);
            // 
            // C_Sharp_10
            // 
            this.C_Sharp_10.BackColor = System.Drawing.Color.LightGray;
            this.C_Sharp_10.Enabled = false;
            this.C_Sharp_10.Location = new System.Drawing.Point(93, 245);
            this.C_Sharp_10.Name = "C_Sharp_10";
            this.C_Sharp_10.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp_10.TabIndex = 131;
            this.C_Sharp_10.UseVisualStyleBackColor = false;
            this.C_Sharp_10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_10_MouseDown);
            this.C_Sharp_10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_10_MouseUp);
            // 
            // D_10
            // 
            this.D_10.BackColor = System.Drawing.Color.LightGray;
            this.D_10.Enabled = false;
            this.D_10.Location = new System.Drawing.Point(175, 245);
            this.D_10.Name = "D_10";
            this.D_10.Size = new System.Drawing.Size(75, 23);
            this.D_10.TabIndex = 132;
            this.D_10.UseVisualStyleBackColor = false;
            this.D_10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_10_MouseDown);
            this.D_10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_10_MouseUp);
            // 
            // D_Sharp_10
            // 
            this.D_Sharp_10.BackColor = System.Drawing.Color.LightGray;
            this.D_Sharp_10.Enabled = false;
            this.D_Sharp_10.Location = new System.Drawing.Point(256, 245);
            this.D_Sharp_10.Name = "D_Sharp_10";
            this.D_Sharp_10.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp_10.TabIndex = 133;
            this.D_Sharp_10.UseVisualStyleBackColor = false;
            this.D_Sharp_10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_10_MouseDown);
            this.D_Sharp_10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_10_MouseUp);
            // 
            // E_10
            // 
            this.E_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.E_10.Location = new System.Drawing.Point(337, 245);
            this.E_10.Name = "E_10";
            this.E_10.Size = new System.Drawing.Size(75, 23);
            this.E_10.TabIndex = 134;
            this.E_10.UseVisualStyleBackColor = false;
            this.E_10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_10_MouseDown);
            this.E_10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.E_10_MouseUp);
            // 
            // F_10
            // 
            this.F_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.F_10.Location = new System.Drawing.Point(417, 245);
            this.F_10.Name = "F_10";
            this.F_10.Size = new System.Drawing.Size(75, 23);
            this.F_10.TabIndex = 135;
            this.F_10.UseVisualStyleBackColor = false;
            this.F_10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_10_MouseDown);
            this.F_10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_10_MouseUp);
            // 
            // F_Sharp_10
            // 
            this.F_Sharp_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.F_Sharp_10.Location = new System.Drawing.Point(499, 245);
            this.F_Sharp_10.Name = "F_Sharp_10";
            this.F_Sharp_10.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp_10.TabIndex = 136;
            this.F_Sharp_10.UseVisualStyleBackColor = false;
            this.F_Sharp_10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_10_MouseDown);
            this.F_Sharp_10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_10_MouseUp);
            // 
            // G_10
            // 
            this.G_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.G_10.Location = new System.Drawing.Point(579, 245);
            this.G_10.Name = "G_10";
            this.G_10.Size = new System.Drawing.Size(75, 23);
            this.G_10.TabIndex = 137;
            this.G_10.UseVisualStyleBackColor = false;
            this.G_10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_10_MouseDown);
            this.G_10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_10_MouseUp);
            // 
            // G_Sharp_10
            // 
            this.G_Sharp_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.G_Sharp_10.Location = new System.Drawing.Point(660, 245);
            this.G_Sharp_10.Name = "G_Sharp_10";
            this.G_Sharp_10.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp_10.TabIndex = 138;
            this.G_Sharp_10.UseVisualStyleBackColor = false;
            this.G_Sharp_10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_10_MouseDown);
            this.G_Sharp_10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_10_MouseUp);
            // 
            // A_10
            // 
            this.A_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.A_10.Location = new System.Drawing.Point(741, 245);
            this.A_10.Name = "A_10";
            this.A_10.Size = new System.Drawing.Size(75, 23);
            this.A_10.TabIndex = 139;
            this.A_10.UseVisualStyleBackColor = false;
            this.A_10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_10_MouseDown);
            this.A_10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_10_MouseUp);
            // 
            // A_Sharp_10
            // 
            this.A_Sharp_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.A_Sharp_10.Location = new System.Drawing.Point(822, 245);
            this.A_Sharp_10.Name = "A_Sharp_10";
            this.A_Sharp_10.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp_10.TabIndex = 140;
            this.A_Sharp_10.UseVisualStyleBackColor = false;
            this.A_Sharp_10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_10_MouseDown);
            this.A_Sharp_10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_10_MouseUp);
            // 
            // B_10
            // 
            this.B_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.B_10.Location = new System.Drawing.Point(903, 245);
            this.B_10.Name = "B_10";
            this.B_10.Size = new System.Drawing.Size(75, 23);
            this.B_10.TabIndex = 141;
            this.B_10.UseVisualStyleBackColor = false;
            this.B_10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_10_MouseDown);
            this.B_10.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_10_MouseUp);
            // 
            // C_Sharp_11
            // 
            this.C_Sharp_11.BackColor = System.Drawing.Color.LightGray;
            this.C_Sharp_11.Enabled = false;
            this.C_Sharp_11.Location = new System.Drawing.Point(93, 216);
            this.C_Sharp_11.Name = "C_Sharp_11";
            this.C_Sharp_11.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp_11.TabIndex = 142;
            this.C_Sharp_11.UseVisualStyleBackColor = false;
            this.C_Sharp_11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_11_MouseDown);
            this.C_Sharp_11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_11_MouseUp);
            // 
            // D_11
            // 
            this.D_11.BackColor = System.Drawing.Color.LightGray;
            this.D_11.Enabled = false;
            this.D_11.Location = new System.Drawing.Point(175, 216);
            this.D_11.Name = "D_11";
            this.D_11.Size = new System.Drawing.Size(75, 23);
            this.D_11.TabIndex = 143;
            this.D_11.UseVisualStyleBackColor = false;
            this.D_11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_11_MouseDown);
            this.D_11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_11_MouseUp);
            // 
            // D_Sharp_11
            // 
            this.D_Sharp_11.BackColor = System.Drawing.Color.LightGray;
            this.D_Sharp_11.Enabled = false;
            this.D_Sharp_11.Location = new System.Drawing.Point(256, 216);
            this.D_Sharp_11.Name = "D_Sharp_11";
            this.D_Sharp_11.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp_11.TabIndex = 144;
            this.D_Sharp_11.UseVisualStyleBackColor = false;
            this.D_Sharp_11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_11_MouseDown);
            this.D_Sharp_11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_11_MouseUp);
            // 
            // E_11
            // 
            this.E_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.E_11.Location = new System.Drawing.Point(337, 216);
            this.E_11.Name = "E_11";
            this.E_11.Size = new System.Drawing.Size(75, 23);
            this.E_11.TabIndex = 145;
            this.E_11.UseVisualStyleBackColor = false;
            this.E_11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_11_MouseDown);
            this.E_11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.E_11_MouseUp);
            // 
            // F_11
            // 
            this.F_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.F_11.Location = new System.Drawing.Point(418, 216);
            this.F_11.Name = "F_11";
            this.F_11.Size = new System.Drawing.Size(75, 23);
            this.F_11.TabIndex = 146;
            this.F_11.UseVisualStyleBackColor = false;
            this.F_11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_11_MouseDown);
            this.F_11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_11_MouseUp);
            // 
            // F_Sharp_11
            // 
            this.F_Sharp_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.F_Sharp_11.Location = new System.Drawing.Point(499, 216);
            this.F_Sharp_11.Name = "F_Sharp_11";
            this.F_Sharp_11.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp_11.TabIndex = 147;
            this.F_Sharp_11.UseVisualStyleBackColor = false;
            this.F_Sharp_11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_11_MouseDown);
            this.F_Sharp_11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_11_MouseUp);
            // 
            // G_11
            // 
            this.G_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.G_11.Location = new System.Drawing.Point(579, 216);
            this.G_11.Name = "G_11";
            this.G_11.Size = new System.Drawing.Size(75, 23);
            this.G_11.TabIndex = 148;
            this.G_11.UseVisualStyleBackColor = false;
            this.G_11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_11_MouseDown);
            this.G_11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_11_MouseUp);
            // 
            // G_Sharp_11
            // 
            this.G_Sharp_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.G_Sharp_11.Location = new System.Drawing.Point(660, 216);
            this.G_Sharp_11.Name = "G_Sharp_11";
            this.G_Sharp_11.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp_11.TabIndex = 149;
            this.G_Sharp_11.UseVisualStyleBackColor = false;
            this.G_Sharp_11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_11_MouseDown);
            this.G_Sharp_11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_11_MouseUp);
            // 
            // A_11
            // 
            this.A_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.A_11.Location = new System.Drawing.Point(741, 216);
            this.A_11.Name = "A_11";
            this.A_11.Size = new System.Drawing.Size(75, 23);
            this.A_11.TabIndex = 150;
            this.A_11.UseVisualStyleBackColor = false;
            this.A_11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_11_MouseDown);
            this.A_11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_11_MouseUp);
            // 
            // A_Sharp_11
            // 
            this.A_Sharp_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.A_Sharp_11.Location = new System.Drawing.Point(822, 216);
            this.A_Sharp_11.Name = "A_Sharp_11";
            this.A_Sharp_11.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp_11.TabIndex = 151;
            this.A_Sharp_11.UseVisualStyleBackColor = false;
            this.A_Sharp_11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_11_MouseDown);
            this.A_Sharp_11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_11_MouseUp);
            // 
            // B_11
            // 
            this.B_11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.B_11.Location = new System.Drawing.Point(903, 216);
            this.B_11.Name = "B_11";
            this.B_11.Size = new System.Drawing.Size(75, 23);
            this.B_11.TabIndex = 152;
            this.B_11.UseVisualStyleBackColor = false;
            this.B_11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_11_MouseDown);
            this.B_11.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_11_MouseUp);
            // 
            // C_Sharp_12
            // 
            this.C_Sharp_12.BackColor = System.Drawing.Color.LightGray;
            this.C_Sharp_12.Enabled = false;
            this.C_Sharp_12.Location = new System.Drawing.Point(93, 187);
            this.C_Sharp_12.Name = "C_Sharp_12";
            this.C_Sharp_12.Size = new System.Drawing.Size(75, 23);
            this.C_Sharp_12.TabIndex = 153;
            this.C_Sharp_12.UseVisualStyleBackColor = false;
            this.C_Sharp_12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_12_MouseDown);
            this.C_Sharp_12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.C_Sharp_12_MouseUp);
            // 
            // D_12
            // 
            this.D_12.BackColor = System.Drawing.Color.LightGray;
            this.D_12.Enabled = false;
            this.D_12.Location = new System.Drawing.Point(175, 187);
            this.D_12.Name = "D_12";
            this.D_12.Size = new System.Drawing.Size(75, 23);
            this.D_12.TabIndex = 154;
            this.D_12.UseVisualStyleBackColor = false;
            this.D_12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_12_MouseDown);
            this.D_12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_12_MouseUp);
            // 
            // D_Sharp_12
            // 
            this.D_Sharp_12.BackColor = System.Drawing.Color.LightGray;
            this.D_Sharp_12.Enabled = false;
            this.D_Sharp_12.Location = new System.Drawing.Point(255, 187);
            this.D_Sharp_12.Name = "D_Sharp_12";
            this.D_Sharp_12.Size = new System.Drawing.Size(75, 23);
            this.D_Sharp_12.TabIndex = 155;
            this.D_Sharp_12.UseVisualStyleBackColor = false;
            this.D_Sharp_12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_12_MouseDown);
            this.D_Sharp_12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.D_Sharp_12_MouseUp);
            // 
            // E_12
            // 
            this.E_12.BackColor = System.Drawing.Color.Magenta;
            this.E_12.Location = new System.Drawing.Point(337, 187);
            this.E_12.Name = "E_12";
            this.E_12.Size = new System.Drawing.Size(75, 23);
            this.E_12.TabIndex = 156;
            this.E_12.UseVisualStyleBackColor = false;
            this.E_12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.E_12_MouseDown);
            this.E_12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.E_12_MouseUp);
            // 
            // F_12
            // 
            this.F_12.BackColor = System.Drawing.Color.Magenta;
            this.F_12.Location = new System.Drawing.Point(418, 187);
            this.F_12.Name = "F_12";
            this.F_12.Size = new System.Drawing.Size(75, 23);
            this.F_12.TabIndex = 157;
            this.F_12.UseVisualStyleBackColor = false;
            this.F_12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_12_MouseDown);
            this.F_12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_12_MouseUp);
            // 
            // F_Sharp_12
            // 
            this.F_Sharp_12.BackColor = System.Drawing.Color.Magenta;
            this.F_Sharp_12.Location = new System.Drawing.Point(499, 187);
            this.F_Sharp_12.Name = "F_Sharp_12";
            this.F_Sharp_12.Size = new System.Drawing.Size(75, 23);
            this.F_Sharp_12.TabIndex = 158;
            this.F_Sharp_12.UseVisualStyleBackColor = false;
            this.F_Sharp_12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_12_MouseDown);
            this.F_Sharp_12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.F_Sharp_12_MouseUp);
            // 
            // G_12
            // 
            this.G_12.BackColor = System.Drawing.Color.Magenta;
            this.G_12.Location = new System.Drawing.Point(579, 187);
            this.G_12.Name = "G_12";
            this.G_12.Size = new System.Drawing.Size(75, 23);
            this.G_12.TabIndex = 159;
            this.G_12.UseVisualStyleBackColor = false;
            this.G_12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_12_MouseDown);
            this.G_12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_12_MouseUp);
            // 
            // G_Sharp_12
            // 
            this.G_Sharp_12.BackColor = System.Drawing.Color.Magenta;
            this.G_Sharp_12.Location = new System.Drawing.Point(660, 187);
            this.G_Sharp_12.Name = "G_Sharp_12";
            this.G_Sharp_12.Size = new System.Drawing.Size(75, 23);
            this.G_Sharp_12.TabIndex = 160;
            this.G_Sharp_12.UseVisualStyleBackColor = false;
            this.G_Sharp_12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_12_MouseDown);
            this.G_Sharp_12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.G_Sharp_12_MouseUp);
            // 
            // A_12
            // 
            this.A_12.BackColor = System.Drawing.Color.Magenta;
            this.A_12.Location = new System.Drawing.Point(741, 187);
            this.A_12.Name = "A_12";
            this.A_12.Size = new System.Drawing.Size(75, 23);
            this.A_12.TabIndex = 161;
            this.A_12.UseVisualStyleBackColor = false;
            this.A_12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_12_MouseDown);
            this.A_12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_12_MouseUp);
            // 
            // A_Sharp_12
            // 
            this.A_Sharp_12.BackColor = System.Drawing.Color.Magenta;
            this.A_Sharp_12.Location = new System.Drawing.Point(822, 187);
            this.A_Sharp_12.Name = "A_Sharp_12";
            this.A_Sharp_12.Size = new System.Drawing.Size(75, 23);
            this.A_Sharp_12.TabIndex = 162;
            this.A_Sharp_12.UseVisualStyleBackColor = false;
            this.A_Sharp_12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_12_MouseDown);
            this.A_Sharp_12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.A_Sharp_12_MouseUp);
            // 
            // B_12
            // 
            this.B_12.BackColor = System.Drawing.Color.Magenta;
            this.B_12.Location = new System.Drawing.Point(903, 187);
            this.B_12.Name = "B_12";
            this.B_12.Size = new System.Drawing.Size(75, 23);
            this.B_12.TabIndex = 163;
            this.B_12.UseVisualStyleBackColor = false;
            this.B_12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.B_12_MouseDown);
            this.B_12.MouseUp += new System.Windows.Forms.MouseEventHandler(this.B_12_MouseUp);
            // 
            // Octave
            // 
            this.Octave.Location = new System.Drawing.Point(430, 10);
            this.Octave.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.Octave.Name = "Octave";
            this.Octave.Size = new System.Drawing.Size(120, 20);
            this.Octave.TabIndex = 164;
            this.Octave.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.Octave.ValueChanged += new System.EventHandler(this.Octave_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(382, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 165;
            this.label4.Text = "Octave";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(382, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 166;
            this.label5.Text = "Volume";
            // 
            // Amplitude
            // 
            this.Amplitude.Location = new System.Drawing.Point(430, 37);
            this.Amplitude.Name = "Amplitude";
            this.Amplitude.Size = new System.Drawing.Size(120, 20);
            this.Amplitude.TabIndex = 167;
            this.Amplitude.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.Amplitude.ValueChanged += new System.EventHandler(this.Amplitude_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(556, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 13);
            this.label6.TabIndex = 168;
            this.label6.Text = "Current Color (Relative to C)";
            // 
            // Color_Disp
            // 
            this.Color_Disp.BackColor = System.Drawing.Color.Red;
            this.Color_Disp.Location = new System.Drawing.Point(700, 9);
            this.Color_Disp.Name = "Color_Disp";
            this.Color_Disp.Size = new System.Drawing.Size(75, 23);
            this.Color_Disp.TabIndex = 169;
            this.Color_Disp.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(994, 570);
            this.Controls.Add(this.Color_Disp);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Amplitude);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Octave);
            this.Controls.Add(this.B_12);
            this.Controls.Add(this.A_Sharp_12);
            this.Controls.Add(this.A_12);
            this.Controls.Add(this.G_Sharp_12);
            this.Controls.Add(this.G_12);
            this.Controls.Add(this.F_Sharp_12);
            this.Controls.Add(this.F_12);
            this.Controls.Add(this.E_12);
            this.Controls.Add(this.D_Sharp_12);
            this.Controls.Add(this.D_12);
            this.Controls.Add(this.C_Sharp_12);
            this.Controls.Add(this.B_11);
            this.Controls.Add(this.A_Sharp_11);
            this.Controls.Add(this.A_11);
            this.Controls.Add(this.G_Sharp_11);
            this.Controls.Add(this.G_11);
            this.Controls.Add(this.F_Sharp_11);
            this.Controls.Add(this.F_11);
            this.Controls.Add(this.E_11);
            this.Controls.Add(this.D_Sharp_11);
            this.Controls.Add(this.D_11);
            this.Controls.Add(this.C_Sharp_11);
            this.Controls.Add(this.B_10);
            this.Controls.Add(this.A_Sharp_10);
            this.Controls.Add(this.A_10);
            this.Controls.Add(this.G_Sharp_10);
            this.Controls.Add(this.G_10);
            this.Controls.Add(this.F_Sharp_10);
            this.Controls.Add(this.F_10);
            this.Controls.Add(this.E_10);
            this.Controls.Add(this.D_Sharp_10);
            this.Controls.Add(this.D_10);
            this.Controls.Add(this.C_Sharp_10);
            this.Controls.Add(this.B_9);
            this.Controls.Add(this.A_Sharp_9);
            this.Controls.Add(this.A_9);
            this.Controls.Add(this.G_Sharp_9);
            this.Controls.Add(this.G_9);
            this.Controls.Add(this.F_Sharp_9);
            this.Controls.Add(this.F_9);
            this.Controls.Add(this.E_9);
            this.Controls.Add(this.D_Sharp_9);
            this.Controls.Add(this.D_9);
            this.Controls.Add(this.C_Sharp_9);
            this.Controls.Add(this.B_8);
            this.Controls.Add(this.A_Sharp_8);
            this.Controls.Add(this.A_8);
            this.Controls.Add(this.G_Sharp_8);
            this.Controls.Add(this.G_8);
            this.Controls.Add(this.F_Sharp_8);
            this.Controls.Add(this.F_8);
            this.Controls.Add(this.E_8);
            this.Controls.Add(this.D_Sharp_8);
            this.Controls.Add(this.D_8);
            this.Controls.Add(this.C_Sharp_8);
            this.Controls.Add(this.B_7);
            this.Controls.Add(this.A_Sharp_7);
            this.Controls.Add(this.A_7);
            this.Controls.Add(this.G_Sharp_7);
            this.Controls.Add(this.G_7);
            this.Controls.Add(this.F_Sharp_7);
            this.Controls.Add(this.F_7);
            this.Controls.Add(this.E_7);
            this.Controls.Add(this.D_Sharp_7);
            this.Controls.Add(this.D_7);
            this.Controls.Add(this.C_Sharp_7);
            this.Controls.Add(this.A_Sharp_6);
            this.Controls.Add(this.A_6);
            this.Controls.Add(this.G_Sharp_6);
            this.Controls.Add(this.G_6);
            this.Controls.Add(this.F_Sharp_6);
            this.Controls.Add(this.B_6);
            this.Controls.Add(this.F_6);
            this.Controls.Add(this.E_6);
            this.Controls.Add(this.D_Sharp_6);
            this.Controls.Add(this.D_6);
            this.Controls.Add(this.C_Sharp_6);
            this.Controls.Add(this.B_5);
            this.Controls.Add(this.A_Sharp_5);
            this.Controls.Add(this.A_5);
            this.Controls.Add(this.G_Sharp_5);
            this.Controls.Add(this.G_5);
            this.Controls.Add(this.F_Sharp_5);
            this.Controls.Add(this.F_5);
            this.Controls.Add(this.E_5);
            this.Controls.Add(this.D_Sharp_5);
            this.Controls.Add(this.D_5);
            this.Controls.Add(this.C_Sharp_5);
            this.Controls.Add(this.B_4);
            this.Controls.Add(this.A_Sharp_4);
            this.Controls.Add(this.A_4);
            this.Controls.Add(this.G_Sharp_4);
            this.Controls.Add(this.G_4);
            this.Controls.Add(this.F_Sharp_4);
            this.Controls.Add(this.F_4);
            this.Controls.Add(this.E_4);
            this.Controls.Add(this.D_Sharp_4);
            this.Controls.Add(this.D_4);
            this.Controls.Add(this.C_Sharp_4);
            this.Controls.Add(this.B_3);
            this.Controls.Add(this.A_Sharp_3);
            this.Controls.Add(this.A_3);
            this.Controls.Add(this.G_Sharp_3);
            this.Controls.Add(this.G_3);
            this.Controls.Add(this.F_Sharp_3);
            this.Controls.Add(this.F_3);
            this.Controls.Add(this.E_3);
            this.Controls.Add(this.D_Sharp_3);
            this.Controls.Add(this.D_3);
            this.Controls.Add(this.C_Sharp_3);
            this.Controls.Add(this.B_2);
            this.Controls.Add(this.A_Sharp_2);
            this.Controls.Add(this.A_2);
            this.Controls.Add(this.G_Sharp_2);
            this.Controls.Add(this.G_2);
            this.Controls.Add(this.F_Sharp_2);
            this.Controls.Add(this.F_2);
            this.Controls.Add(this.E_2);
            this.Controls.Add(this.D_Sharp_2);
            this.Controls.Add(this.D_2);
            this.Controls.Add(this.C_Sharp_2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.D_Cycle);
            this.Controls.Add(this.B_1);
            this.Controls.Add(this.A_Sharp_1);
            this.Controls.Add(this.A_1);
            this.Controls.Add(this.G_Sharp_1);
            this.Controls.Add(this.G_1);
            this.Controls.Add(this.F_Sharp_1);
            this.Controls.Add(this.F_1);
            this.Controls.Add(this.E_1);
            this.Controls.Add(this.D_Sharp_1);
            this.Controls.Add(this.D_1);
            this.Controls.Add(this.C_Sharp_1);
            this.Controls.Add(this.C_12);
            this.Controls.Add(this.C_11);
            this.Controls.Add(this.C_10);
            this.Controls.Add(this.C_9);
            this.Controls.Add(this.C_8);
            this.Controls.Add(this.C_7);
            this.Controls.Add(this.C_6);
            this.Controls.Add(this.C_5);
            this.Controls.Add(this.C_4);
            this.Controls.Add(this.C_3);
            this.Controls.Add(this.C_2);
            this.Controls.Add(this.C_1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.B);
            this.Controls.Add(this.A_Sharp);
            this.Controls.Add(this.A);
            this.Controls.Add(this.G_Sharp);
            this.Controls.Add(this.G);
            this.Controls.Add(this.F_Sharp);
            this.Controls.Add(this.F);
            this.Controls.Add(this.E);
            this.Controls.Add(this.D_Sharp);
            this.Controls.Add(this.D);
            this.Controls.Add(this.C_Sharp);
            this.Controls.Add(this.wave_type);
            this.Controls.Add(this.C);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.retune);
            this.Controls.Add(this.notes_per_octave);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "TeT Microtonal Keyboard";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.notes_per_octave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.D_Cycle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Octave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Amplitude)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown notes_per_octave;
        private System.Windows.Forms.Button retune;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button C;
        private System.Windows.Forms.ComboBox wave_type;
        private System.Windows.Forms.Button C_Sharp;
        private System.Windows.Forms.Button D;
        private System.Windows.Forms.Button D_Sharp;
        private System.Windows.Forms.Button E;
        private System.Windows.Forms.Button F;
        private System.Windows.Forms.Button F_Sharp;
        private System.Windows.Forms.Button G;
        private System.Windows.Forms.Button G_Sharp;
        private System.Windows.Forms.Button A;
        private System.Windows.Forms.Button A_Sharp;
        private System.Windows.Forms.Button B;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button C_1;
        private System.Windows.Forms.Button C_2;
        private System.Windows.Forms.Button C_3;
        private System.Windows.Forms.Button C_4;
        private System.Windows.Forms.Button C_5;
        private System.Windows.Forms.Button C_6;
        private System.Windows.Forms.Button C_7;
        private System.Windows.Forms.Button C_8;
        private System.Windows.Forms.Button C_9;
        private System.Windows.Forms.Button C_10;
        private System.Windows.Forms.Button C_11;
        private System.Windows.Forms.Button C_12;
        private System.Windows.Forms.Button C_Sharp_1;
        private System.Windows.Forms.Button D_1;
        private System.Windows.Forms.Button D_Sharp_1;
        private System.Windows.Forms.Button E_1;
        private System.Windows.Forms.Button F_1;
        private System.Windows.Forms.Button F_Sharp_1;
        private System.Windows.Forms.Button G_1;
        private System.Windows.Forms.Button G_Sharp_1;
        private System.Windows.Forms.Button A_1;
        private System.Windows.Forms.Button A_Sharp_1;
        private System.Windows.Forms.Button B_1;
        private System.Windows.Forms.NumericUpDown D_Cycle;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button C_Sharp_2;
        private System.Windows.Forms.Button D_2;
        private System.Windows.Forms.Button D_Sharp_2;
        private System.Windows.Forms.Button E_2;
        private System.Windows.Forms.Button F_2;
        private System.Windows.Forms.Button F_Sharp_2;
        private System.Windows.Forms.Button G_2;
        private System.Windows.Forms.Button G_Sharp_2;
        private System.Windows.Forms.Button A_2;
        private System.Windows.Forms.Button A_Sharp_2;
        private System.Windows.Forms.Button B_2;
        private System.Windows.Forms.Button C_Sharp_3;
        private System.Windows.Forms.Button D_3;
        private System.Windows.Forms.Button D_Sharp_3;
        private System.Windows.Forms.Button E_3;
        private System.Windows.Forms.Button F_3;
        private System.Windows.Forms.Button F_Sharp_3;
        private System.Windows.Forms.Button G_3;
        private System.Windows.Forms.Button G_Sharp_3;
        private System.Windows.Forms.Button A_3;
        private System.Windows.Forms.Button A_Sharp_3;
        private System.Windows.Forms.Button B_3;
        private System.Windows.Forms.Button C_Sharp_4;
        private System.Windows.Forms.Button D_4;
        private System.Windows.Forms.Button D_Sharp_4;
        private System.Windows.Forms.Button E_4;
        private System.Windows.Forms.Button F_4;
        private System.Windows.Forms.Button F_Sharp_4;
        private System.Windows.Forms.Button G_4;
        private System.Windows.Forms.Button G_Sharp_4;
        private System.Windows.Forms.Button A_4;
        private System.Windows.Forms.Button A_Sharp_4;
        private System.Windows.Forms.Button B_4;
        private System.Windows.Forms.Button C_Sharp_5;
        private System.Windows.Forms.Button D_5;
        private System.Windows.Forms.Button D_Sharp_5;
        private System.Windows.Forms.Button E_5;
        private System.Windows.Forms.Button F_5;
        private System.Windows.Forms.Button F_Sharp_5;
        private System.Windows.Forms.Button G_5;
        private System.Windows.Forms.Button G_Sharp_5;
        private System.Windows.Forms.Button A_5;
        private System.Windows.Forms.Button A_Sharp_5;
        private System.Windows.Forms.Button B_5;
        private System.Windows.Forms.Button C_Sharp_6;
        private System.Windows.Forms.Button D_6;
        private System.Windows.Forms.Button D_Sharp_6;
        private System.Windows.Forms.Button E_6;
        private System.Windows.Forms.Button F_6;
        private System.Windows.Forms.Button B_6;
        private System.Windows.Forms.Button F_Sharp_6;
        private System.Windows.Forms.Button G_6;
        private System.Windows.Forms.Button G_Sharp_6;
        private System.Windows.Forms.Button A_6;
        private System.Windows.Forms.Button A_Sharp_6;
        private System.Windows.Forms.Button C_Sharp_7;
        private System.Windows.Forms.Button D_7;
        private System.Windows.Forms.Button D_Sharp_7;
        private System.Windows.Forms.Button E_7;
        private System.Windows.Forms.Button F_7;
        private System.Windows.Forms.Button F_Sharp_7;
        private System.Windows.Forms.Button G_7;
        private System.Windows.Forms.Button G_Sharp_7;
        private System.Windows.Forms.Button A_7;
        private System.Windows.Forms.Button A_Sharp_7;
        private System.Windows.Forms.Button B_7;
        private System.Windows.Forms.Button C_Sharp_8;
        private System.Windows.Forms.Button D_8;
        private System.Windows.Forms.Button D_Sharp_8;
        private System.Windows.Forms.Button E_8;
        private System.Windows.Forms.Button F_8;
        private System.Windows.Forms.Button F_Sharp_8;
        private System.Windows.Forms.Button G_8;
        private System.Windows.Forms.Button G_Sharp_8;
        private System.Windows.Forms.Button A_8;
        private System.Windows.Forms.Button A_Sharp_8;
        private System.Windows.Forms.Button B_8;
        private System.Windows.Forms.Button C_Sharp_9;
        private System.Windows.Forms.Button D_9;
        private System.Windows.Forms.Button D_Sharp_9;
        private System.Windows.Forms.Button E_9;
        private System.Windows.Forms.Button F_9;
        private System.Windows.Forms.Button F_Sharp_9;
        private System.Windows.Forms.Button G_9;
        private System.Windows.Forms.Button G_Sharp_9;
        private System.Windows.Forms.Button A_9;
        private System.Windows.Forms.Button A_Sharp_9;
        private System.Windows.Forms.Button B_9;
        private System.Windows.Forms.Button C_Sharp_10;
        private System.Windows.Forms.Button D_10;
        private System.Windows.Forms.Button D_Sharp_10;
        private System.Windows.Forms.Button E_10;
        private System.Windows.Forms.Button F_10;
        private System.Windows.Forms.Button F_Sharp_10;
        private System.Windows.Forms.Button G_10;
        private System.Windows.Forms.Button G_Sharp_10;
        private System.Windows.Forms.Button A_10;
        private System.Windows.Forms.Button A_Sharp_10;
        private System.Windows.Forms.Button B_10;
        private System.Windows.Forms.Button C_Sharp_11;
        private System.Windows.Forms.Button D_11;
        private System.Windows.Forms.Button D_Sharp_11;
        private System.Windows.Forms.Button E_11;
        private System.Windows.Forms.Button F_11;
        private System.Windows.Forms.Button F_Sharp_11;
        private System.Windows.Forms.Button G_11;
        private System.Windows.Forms.Button G_Sharp_11;
        private System.Windows.Forms.Button A_11;
        private System.Windows.Forms.Button A_Sharp_11;
        private System.Windows.Forms.Button B_11;
        private System.Windows.Forms.Button C_Sharp_12;
        private System.Windows.Forms.Button D_12;
        private System.Windows.Forms.Button D_Sharp_12;
        private System.Windows.Forms.Button E_12;
        private System.Windows.Forms.Button F_12;
        private System.Windows.Forms.Button F_Sharp_12;
        private System.Windows.Forms.Button G_12;
        private System.Windows.Forms.Button G_Sharp_12;
        private System.Windows.Forms.Button A_12;
        private System.Windows.Forms.Button A_Sharp_12;
        private System.Windows.Forms.Button B_12;
        private System.Windows.Forms.NumericUpDown Octave;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown Amplitude;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Color_Disp;
    }
}

