﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NAudio.Wave;

namespace WindowsFormsApp1
{
    class WaveSample : NAudio.Wave.WaveStream
    {

        private WaveType type;
        private double freq;
        private double vol;
        private double time;
        private double duty;

        public WaveSample(double frequency, double volume, WaveType kind, double dt)
        {
            this.time = 0;
            this.freq = frequency;
            this.vol = volume;
            this.type = kind;
            this.duty = dt;
        }

        public override long Position
        {
            get;
            set;
        }

        public override long Length
        {
            get { return long.MaxValue; }
        }

        public override WaveFormat WaveFormat
        {
            get { return new WaveFormat(44100, 16, 1); }
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            int samp = count / 2;
            double t;
            switch (type)
            {

                case WaveType.Sine:
                    for (int i = 0; i < samp; i++)
                    {
                        double Sine = vol * Math.Sin(Math.PI * 2 * time * freq);
                        time += 1.0 / 44100;
                        double tr = Math.Truncate(Sine * (Math.Pow(2, 15) - 1));
                        short trunc = Convert.ToInt16(tr);
                        buffer[i * 2] = (byte)(trunc & 0x00ff);
                        buffer[i * 2 + 1] = (byte)((trunc & 0xff00) >> 8);
                    }
                    break;

                case WaveType.Triangle:
                    double Triang = 0;
                    for (int i = 0; i < samp; i++)
                    {
                        t = time * freq - Math.Truncate(time * freq);
                        if (t < 0.25)
                        {
                            Triang = t * vol * 4;
                        }
                        if (t > 0.25 && t < 0.5)
                        {
                            Triang = vol * (0.5 - t) * 4;
                        }
                        if (t > 0.5 && t < 0.75)
                        {
                            Triang = (0.5 - t) * vol * 4;
                        }
                        if (t > 0.75)
                        {
                            Triang = vol * (t - 1) * 4;
                        }
                        time += 1.0 / 44100;
                        double tr = Math.Truncate(Triang * (Math.Pow(2, 15) - 1));
                        short trunc = Convert.ToInt16(tr);
                        buffer[i * 2] = (byte)(trunc & 0x00ff);
                        buffer[i * 2 + 1] = (byte)((trunc & 0xff00) >> 8);
                    }
                    break;

                case WaveType.Pulse:
                    double Pulse = 0; ;
                    for (int i = 0; i < samp; i++)
                    {
                        t = time * freq - Math.Truncate(time * freq);
                        if (t < duty)
                        {
                            Pulse = vol;
                        }
                        if (t > duty)
                        {
                            Pulse = 0;
                        }
                        time += 1.0 / 44100;
                        double tr = Math.Truncate(Pulse * (Math.Pow(2, 15) - 1));
                        short trunc = Convert.ToInt16(tr);
                        buffer[i * 2] = (byte)(trunc & 0x00ff);
                        buffer[i * 2 + 1] = (byte)((trunc & 0xff00) >> 8);
                    }
                    break;

                case WaveType.Sawtooth:
                    double Saw = 0;
                    for (int i = 0; i < samp; i++)
                    {
                        t = time * freq - Math.Truncate(time * freq);
                        Saw = vol * 2 * (t - 0.5);
                        time += 1.0 / 44100;
                        double tr = Math.Truncate(Saw * (Math.Pow(2, 15) - 1));
                        short trunc = Convert.ToInt16(tr);
                        buffer[i * 2] = (byte)(trunc & 0x00ff);
                        buffer[i * 2 + 1] = (byte)((trunc & 0xff00) >> 8);
                    }


                    break;
            }
            return count;
        }

    }
}
