﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class KeySound
    {
        public NAudio.Wave.DirectSoundOut[] snds;
        public bool[] isPlaying;

        public KeySound()
        {
            snds = new NAudio.Wave.DirectSoundOut[32];
            isPlaying = new bool[32];
            for(int i = 0; i < 32; i++)
            {
                isPlaying[i] = false;
            }
        }


    }
}
