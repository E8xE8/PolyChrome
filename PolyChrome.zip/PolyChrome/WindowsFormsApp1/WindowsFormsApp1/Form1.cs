﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NAudio.Wave;

namespace WindowsFormsApp1
{
    enum WaveType { Sine, Triangle, Pulse, Sawtooth};
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private NAudio.Wave.DirectSoundOut sound = null;
        private List<NAudio.Wave.DirectSoundOut> sounds = null;
        private double multiplier;
        private int[] numcol = new int[12];
        private int nonotes;
        private WaveType wvtp;
        private double volume;
        private double duty;
        private bool hold;
        private double base_freq;
        private int color;
        private int tot_cols;
        private KeySound ksounds;


        public double power(double x, int y)
        {
            double accume = x;
            if(y <= 0)
            {
                return 1;
            }
            if(y == 1)
            {
                return x;
            }
            for (int i = 0; i < (y - 1); i++)
            {
                accume = accume * x;
            }
            return accume;
        }

        private void retune_Click(object sender, EventArgs e)
        {
            double t_mult = Math.Exp(Math.Log(2) / 12);
            double t_freq = 262;
            nonotes = Convert.ToInt16(notes_per_octave.Value);
            multiplier = Math.Exp(Math.Log(2) / nonotes);
            for(int i = 0; i < 12; i++)
            {
                numcol[i] = 0;

                while(Math.Round(t_freq, 4) < Math.Round(262 * (power(t_mult, i + 1)), 4))
                {
                    t_freq = t_freq * multiplier;
                    numcol[i] = numcol[i] + 1;
                    double a = 262 * power(t_mult, i + 1);
                }
            }
            tot_cols = numcol.Max();
            buttonEnabler(numcol);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (short i = 0; i < 12; i++)
            {
                numcol[i] = 1;
            }
            multiplier = Math.Exp(Math.Log(2) / 12);
            nonotes = 12;
            wvtp = WaveType.Sawtooth;
            volume = 0.1;
            duty = 0.5;
            hold = false;
            base_freq = 262;
            color = 1;
            tot_cols = 1;
            sound = new DirectSoundOut();
            sounds = new List<DirectSoundOut>();
            ksounds = new KeySound();
            retune.PerformClick();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(sound != null)
                sound.Dispose();
        }

        private void retune_MouseDown(object sender, MouseEventArgs e)
        {
            
        }

        private void C_MouseDown(object sender, MouseEventArgs e)
        {
            WaveSample wv = new WaveSample(262, volume, wvtp, duty);
            sound = new NAudio.Wave.DirectSoundOut();
            sounds.Add(sound);
            sound.Init(wv);
            sound.Play();
        }

        private void C_MouseUp(object sender, MouseEventArgs e)
        {
            if (!hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_MouseDown(object sender, MouseEventArgs e)
        {
            WaveSample wv = new WaveSample(262 * power(Math.Exp(Math.Log(2) / 12), 1), volume, wvtp, duty);
            sound = new NAudio.Wave.DirectSoundOut();
            sounds.Add(sound);
            sound.Init(wv);
            sound.Play();
        }

        private void C_Sharp_MouseUp(object sender, MouseEventArgs e)
        {
            if (!hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_MouseDown(object sender, MouseEventArgs e)
        {
            WaveSample wv = new WaveSample(262 * power(Math.Exp(Math.Log(2) / 12), 2), volume, wvtp, duty);
            sound = new NAudio.Wave.DirectSoundOut();
            sounds.Add(sound);
            sound.Init(wv);
            sound.Play();
        }

        private void D_MouseUp(object sender, MouseEventArgs e)
        {
            if (!hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_MouseDown(object sender, MouseEventArgs e)
        {
            WaveSample wv = new WaveSample(262 * power(Math.Exp(Math.Log(2) / 12), 3), volume, wvtp, duty);
            sound = new NAudio.Wave.DirectSoundOut();
            sounds.Add(sound);
            sound.Init(wv);
            sound.Play();
        }

        private void D_Sharp_MouseUp(object sender, MouseEventArgs e)
        {
            if (!hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_MouseDown(object sender, MouseEventArgs e)
        {
            WaveSample wv = new WaveSample(262 * power(Math.Exp(Math.Log(2) / 12), 4), volume, wvtp, duty);
            sound = new NAudio.Wave.DirectSoundOut();
            sounds.Add(sound);
            sound.Init(wv);
            sound.Play();
        }

        private void E_MouseUp(object sender, MouseEventArgs e)
        {
            if (!hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_MouseDown(object sender, MouseEventArgs e)
        {
            WaveSample wv = new WaveSample(262 * power(Math.Exp(Math.Log(2) / 12), 5), volume, wvtp, duty);
            sound = new NAudio.Wave.DirectSoundOut();
            sounds.Add(sound);
            sound.Init(wv);
            sound.Play();
        }

        private void F_MouseUp(object sender, MouseEventArgs e)
        {
            if (!hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_MouseDown(object sender, MouseEventArgs e)
        {
            WaveSample wv = new WaveSample(262 * power(Math.Exp(Math.Log(2) / 12), 6), volume, wvtp, duty);
            sound = new NAudio.Wave.DirectSoundOut();
            sounds.Add(sound);
            sound.Init(wv);
            sound.Play();
        }

        private void F_Sharp_MouseUp(object sender, MouseEventArgs e)
        {
            if (!hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_MouseDown(object sender, MouseEventArgs e)
        {
            WaveSample wv = new WaveSample(262 * power(Math.Exp(Math.Log(2) / 12), 7), volume, wvtp, duty);
            sound = new NAudio.Wave.DirectSoundOut();
            sounds.Add(sound);
            sound.Init(wv);
            sound.Play();
        }

        private void G_MouseUp(object sender, MouseEventArgs e)
        {
            if (!hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_MouseDown(object sender, MouseEventArgs e)
        {
            WaveSample wv = new WaveSample(262 * power(Math.Exp(Math.Log(2) / 12), 8), volume, wvtp, duty);
            sound = new NAudio.Wave.DirectSoundOut();
            sounds.Add(sound);
            sound.Init(wv);
            sound.Play();
        }

        private void G_Sharp_MouseUp(object sender, MouseEventArgs e)
        {
            if (!hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_MouseDown(object sender, MouseEventArgs e)
        {
            WaveSample wv = new WaveSample(262 * power(Math.Exp(Math.Log(2) / 12), 9), volume, wvtp, duty);
            sound = new NAudio.Wave.DirectSoundOut();
            sounds.Add(sound);
            sound.Init(wv);
            sound.Play();
        }

        private void A_MouseUp(object sender, MouseEventArgs e)
        {
            if (!hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_MouseDown(object sender, MouseEventArgs e)
        {
            WaveSample wv = new WaveSample(262 * power(Math.Exp(Math.Log(2) / 12), 10), volume, wvtp, duty);
            sound = new NAudio.Wave.DirectSoundOut();
            sounds.Add(sound);
            sound.Init(wv);
            sound.Play();
        }

        private void A_Sharp_MouseUp(object sender, MouseEventArgs e)
        {
            if (!hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }

        }

        private void B_MouseDown(object sender, MouseEventArgs e)
        {
            WaveSample wv = new WaveSample(262 * power(Math.Exp(Math.Log(2) / 12), 11), volume, wvtp, duty);
            sound = new NAudio.Wave.DirectSoundOut();
            sounds.Add(sound);
            sound.Init(wv);
            sound.Play();
        }

        private void B_MouseUp(object sender, MouseEventArgs e)
        {
            if (!hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void wave_type_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(wave_type.SelectedIndex)
            {
                case (3):
                    wvtp = WaveType.Sawtooth;
                    break;
                case (1):
                    wvtp = WaveType.Triangle;
                    break;
                case (0):
                    wvtp = WaveType.Sine;
                    break;
                case (2):
                    wvtp = WaveType.Pulse;
                    break;
                default:
                    wvtp = WaveType.Sawtooth;
                    break;
            }
        }

        private void D_Cycle_ValueChanged(object sender, EventArgs e)
        {
            duty = (double)D_Cycle.Value / 100;
        }

        void buttonEnabler(int[] ncol)
        {
            switch (ncol[0])
            {
                case (0):
                    C_1.Enabled = false;
                    C_1.BackColor = Color.LightGray;
                    C_2.Enabled = false;
                    C_2.BackColor = Color.LightGray;
                    C_3.Enabled = false;
                    C_3.BackColor = Color.LightGray;
                    C_4.Enabled = false;
                    C_4.BackColor = Color.LightGray;
                    C_5.Enabled = false;
                    C_5.BackColor = Color.LightGray;
                    C_6.Enabled = false;
                    C_6.BackColor = Color.LightGray;
                    C_7.Enabled = false;
                    C_7.BackColor = Color.LightGray;
                    C_8.Enabled = false;
                    C_8.BackColor = Color.LightGray;
                    C_9.Enabled = false;
                    C_9.BackColor = Color.LightGray;
                    C_10.Enabled = false;
                    C_10.BackColor = Color.LightGray;
                    C_11.Enabled = false;
                    C_11.BackColor = Color.LightGray;
                    C_12.Enabled = false;
                    C_12.BackColor = Color.LightGray;
                    break;
                case (1):
                    C_1.Enabled = true;
                    C_1.BackColor = Color.Red;
                    C_2.Enabled = false;
                    C_2.BackColor = Color.LightGray;
                    C_3.Enabled = false;
                    C_3.BackColor = Color.LightGray;
                    C_4.Enabled = false;
                    C_4.BackColor = Color.LightGray;
                    C_5.Enabled = false;
                    C_5.BackColor = Color.LightGray;
                    C_6.Enabled = false;
                    C_6.BackColor = Color.LightGray;
                    C_7.Enabled = false;
                    C_7.BackColor = Color.LightGray;
                    C_8.Enabled = false;
                    C_8.BackColor = Color.LightGray;
                    C_9.Enabled = false;
                    C_9.BackColor = Color.LightGray;
                    C_10.Enabled = false;
                    C_10.BackColor = Color.LightGray;
                    C_11.Enabled = false;
                    C_11.BackColor = Color.LightGray;
                    C_12.Enabled = false;
                    C_12.BackColor = Color.LightGray;
                    break;
                case (2):
                    C_1.Enabled = true;
                    C_1.BackColor = Color.Red;
                    C_2.Enabled = true;
                    C_2.BackColor = Color.Blue;
                    C_3.Enabled = false;
                    C_3.BackColor = Color.LightGray;
                    C_4.Enabled = false;
                    C_4.BackColor = Color.LightGray;
                    C_5.Enabled = false;
                    C_5.BackColor = Color.LightGray;
                    C_6.Enabled = false;
                    C_6.BackColor = Color.LightGray;
                    C_7.Enabled = false;
                    C_7.BackColor = Color.LightGray;
                    C_8.Enabled = false;
                    C_8.BackColor = Color.LightGray;
                    C_9.Enabled = false;
                    C_9.BackColor = Color.LightGray;
                    C_10.Enabled = false;
                    C_10.BackColor = Color.LightGray;
                    C_11.Enabled = false;
                    C_11.BackColor = Color.LightGray;
                    C_12.Enabled = false;
                    C_12.BackColor = Color.LightGray;
                    break;
                case (3):
                    C_1.Enabled = true;
                    C_1.BackColor = Color.Red;
                    C_2.Enabled = true;
                    C_2.BackColor = Color.Lime;
                    C_3.Enabled = true;
                    C_3.BackColor = Color.Blue;
                    C_4.Enabled = false;
                    C_4.BackColor = Color.LightGray;
                    C_5.Enabled = false;
                    C_5.BackColor = Color.LightGray;
                    C_6.Enabled = false;
                    C_6.BackColor = Color.LightGray;
                    C_7.Enabled = false;
                    C_7.BackColor = Color.LightGray;
                    C_8.Enabled = false;
                    C_8.BackColor = Color.LightGray;
                    C_9.Enabled = false;
                    C_9.BackColor = Color.LightGray;
                    C_10.Enabled = false;
                    C_10.BackColor = Color.LightGray;
                    C_11.Enabled = false;
                    C_11.BackColor = Color.LightGray;
                    C_12.Enabled = false;
                    C_12.BackColor = Color.LightGray;
                    break;
                case (4):
                    C_1.Enabled = true;
                    C_1.BackColor = Color.Red;
                    C_2.Enabled = true;
                    C_2.BackColor = Color.Yellow;
                    C_3.Enabled = true;
                    C_3.BackColor = Color.Lime;
                    C_4.Enabled = true;
                    C_4.BackColor = Color.Blue;
                    C_5.Enabled = false;
                    C_5.BackColor = Color.LightGray;
                    C_6.Enabled = false;
                    C_6.BackColor = Color.LightGray;
                    C_7.Enabled = false;
                    C_7.BackColor = Color.LightGray;
                    C_8.Enabled = false;
                    C_8.BackColor = Color.LightGray;
                    C_9.Enabled = false;
                    C_9.BackColor = Color.LightGray;
                    C_10.Enabled = false;
                    C_10.BackColor = Color.LightGray;
                    C_11.Enabled = false;
                    C_11.BackColor = Color.LightGray;
                    C_12.Enabled = false;
                    C_12.BackColor = Color.LightGray;
                    break;
                case (5):
                    C_1.Enabled = true;
                    C_1.BackColor = Color.Red;
                    C_2.Enabled = true;
                    C_2.BackColor = Color.Yellow;
                    C_3.Enabled = true;
                    C_3.BackColor = Color.Lime;
                    C_4.Enabled = true;
                    C_4.BackColor = Color.Cyan;
                    C_5.Enabled = true;
                    C_5.BackColor = Color.Blue;
                    C_6.Enabled = false;
                    C_6.BackColor = Color.LightGray;
                    C_7.Enabled = false;
                    C_7.BackColor = Color.LightGray;
                    C_8.Enabled = false;
                    C_8.BackColor = Color.LightGray;
                    C_9.Enabled = false;
                    C_9.BackColor = Color.LightGray;
                    C_10.Enabled = false;
                    C_10.BackColor = Color.LightGray;
                    C_11.Enabled = false;
                    C_11.BackColor = Color.LightGray;
                    C_12.Enabled = false;
                    C_12.BackColor = Color.LightGray;
                    break;
                case (6):
                    C_1.Enabled = true;
                    C_1.BackColor = Color.Red;
                    C_2.Enabled = true;
                    C_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_3.Enabled = true;
                    C_3.BackColor = Color.Yellow;
                    C_4.Enabled = true;
                    C_4.BackColor = Color.Lime;
                    C_5.Enabled = true;
                    C_5.BackColor = Color.Cyan;
                    C_6.Enabled = true;
                    C_6.BackColor = Color.Blue;
                    C_7.Enabled = false;
                    C_7.BackColor = Color.LightGray;
                    C_8.Enabled = false;
                    C_8.BackColor = Color.LightGray;
                    C_9.Enabled = false;
                    C_9.BackColor = Color.LightGray;
                    C_10.Enabled = false;
                    C_10.BackColor = Color.LightGray;
                    C_11.Enabled = false;
                    C_11.BackColor = Color.LightGray;
                    C_12.Enabled = false;
                    C_12.BackColor = Color.LightGray;
                    break;
                case (7):
                    C_1.Enabled = true;
                    C_1.BackColor = Color.Red;
                    C_2.Enabled = true;
                    C_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_3.Enabled = true;
                    C_3.BackColor = Color.Yellow;
                    C_4.Enabled = true;
                    C_4.BackColor = Color.Lime;
                    C_5.Enabled = true;
                    C_5.BackColor = Color.Cyan;
                    C_6.Enabled = true;
                    C_6.BackColor = Color.Blue;
                    C_7.Enabled = true;
                    C_7.BackColor = Color.FromArgb(128, 0, 255);
                    C_8.Enabled = false;
                    C_8.BackColor = Color.LightGray;
                    C_9.Enabled = false;
                    C_9.BackColor = Color.LightGray;
                    C_10.Enabled = false;
                    C_10.BackColor = Color.LightGray;
                    C_11.Enabled = false;
                    C_11.BackColor = Color.LightGray;
                    C_12.Enabled = false;
                    C_12.BackColor = Color.LightGray;
                    break;
                case (8):
                    C_1.Enabled = true;
                    C_1.BackColor = Color.Red;
                    C_2.Enabled = true;
                    C_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_3.Enabled = true;
                    C_3.BackColor = Color.Yellow;
                    C_4.Enabled = true;
                    C_4.BackColor = Color.Lime;
                    C_5.Enabled = true;
                    C_5.BackColor = Color.Cyan;
                    C_6.Enabled = true;
                    C_6.BackColor = Color.Blue;
                    C_7.Enabled = true;
                    C_7.BackColor = Color.FromArgb(128, 0, 255);
                    C_8.Enabled = true;
                    C_8.BackColor = Color.Magenta;
                    C_9.Enabled = false;
                    C_9.BackColor = Color.LightGray;
                    C_10.Enabled = false;
                    C_10.BackColor = Color.LightGray;
                    C_11.Enabled = false;
                    C_11.BackColor = Color.LightGray;
                    C_12.Enabled = false;
                    C_12.BackColor = Color.LightGray;
                    break;
                case (9):
                    C_1.Enabled = true;
                    C_1.BackColor = Color.Red;
                    C_2.Enabled = true;
                    C_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_3.Enabled = true;
                    C_3.BackColor = Color.Yellow;
                    C_4.Enabled = true;
                    C_4.BackColor = Color.FromArgb(196, 255, 0);
                    C_5.Enabled = true;
                    C_5.BackColor = Color.Lime;
                    C_6.Enabled = true;
                    C_6.BackColor = Color.Cyan;
                    C_7.Enabled = true;
                    C_7.BackColor = Color.Blue;
                    C_8.Enabled = true;
                    C_8.BackColor = Color.FromArgb(128, 0, 255);
                    C_9.Enabled = true;
                    C_9.BackColor = Color.Magenta;
                    C_10.Enabled = false;
                    C_10.BackColor = Color.LightGray;
                    C_11.Enabled = false;
                    C_11.BackColor = Color.LightGray;
                    C_12.Enabled = false;
                    C_12.BackColor = Color.LightGray;
                    break;
                case (10):
                    C_1.Enabled = true;
                    C_1.BackColor = Color.Red;
                    C_2.Enabled = true;
                    C_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_3.Enabled = true;
                    C_3.BackColor = Color.FromArgb(255, 196, 0);
                    C_4.Enabled = true;
                    C_4.BackColor = Color.Yellow;
                    C_5.Enabled = true;
                    C_5.BackColor = Color.FromArgb(196, 255, 0);
                    C_6.Enabled = true;
                    C_6.BackColor = Color.Lime;
                    C_7.Enabled = true;
                    C_7.BackColor = Color.Cyan;
                    C_8.Enabled = true;
                    C_8.BackColor = Color.Blue;
                    C_9.Enabled = true;
                    C_9.BackColor = Color.FromArgb(128, 0, 255);
                    C_10.Enabled = true;
                    C_10.BackColor = Color.Magenta;
                    C_11.Enabled = false;
                    C_11.BackColor = Color.LightGray;
                    C_12.Enabled = false;
                    C_12.BackColor = Color.LightGray;
                    break;
                case (11):
                    C_1.Enabled = true;
                    C_1.BackColor = Color.Red;
                    C_2.Enabled = true;
                    C_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_3.Enabled = true;
                    C_3.BackColor = Color.FromArgb(255, 196, 0);
                    C_4.Enabled = true;
                    C_4.BackColor = Color.Yellow;
                    C_5.Enabled = true;
                    C_5.BackColor = Color.FromArgb(196, 255, 0);
                    C_6.Enabled = true;
                    C_6.BackColor = Color.Lime;
                    C_7.Enabled = true;
                    C_7.BackColor = Color.FromArgb(0, 255, 196);
                    C_8.Enabled = true;
                    C_8.BackColor = Color.Cyan;
                    C_9.Enabled = true;
                    C_9.BackColor = Color.Blue;
                    C_10.Enabled = true;
                    C_10.BackColor = Color.FromArgb(128, 0, 255);
                    C_11.Enabled = true;
                    C_11.BackColor = Color.Magenta;
                    C_12.Enabled = false;
                    C_12.BackColor = Color.LightGray;
                    break;
                case (12):
                    C_1.Enabled = true;
                    C_1.BackColor = Color.Red;
                    C_2.Enabled = true;
                    C_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_3.Enabled = true;
                    C_3.BackColor = Color.FromArgb(255, 196, 0);
                    C_4.Enabled = true;
                    C_4.BackColor = Color.Yellow;
                    C_5.Enabled = true;
                    C_5.BackColor = Color.FromArgb(196, 255, 0);
                    C_6.Enabled = true;
                    C_6.BackColor = Color.Lime;
                    C_7.Enabled = true;
                    C_7.BackColor = Color.FromArgb(0, 255, 196);
                    C_8.Enabled = true;
                    C_8.BackColor = Color.Cyan;
                    C_9.Enabled = true;
                    C_9.BackColor = Color.Blue;
                    C_10.Enabled = true;
                    C_10.BackColor = Color.FromArgb(128, 0, 255);
                    C_11.Enabled = true;
                    C_11.BackColor = Color.FromArgb(196, 0, 255);
                    C_12.Enabled = true;
                    C_12.BackColor = Color.Magenta;
                    break;
            }
            switch (ncol[1])
            {
                case (0):
                    C_Sharp_1.Enabled = false;
                    C_Sharp_1.BackColor = Color.LightGray;
                    C_Sharp_2.Enabled = false;
                    C_Sharp_2.BackColor = Color.LightGray;
                    C_Sharp_3.Enabled = false;
                    C_Sharp_3.BackColor = Color.LightGray;
                    C_Sharp_4.Enabled = false;
                    C_Sharp_4.BackColor = Color.LightGray;
                    C_Sharp_5.Enabled = false;
                    C_Sharp_5.BackColor = Color.LightGray;
                    C_Sharp_6.Enabled = false;
                    C_Sharp_6.BackColor = Color.LightGray;
                    C_Sharp_7.Enabled = false;
                    C_Sharp_7.BackColor = Color.LightGray;
                    C_Sharp_8.Enabled = false;
                    C_Sharp_8.BackColor = Color.LightGray;
                    C_Sharp_9.Enabled = false;
                    C_Sharp_9.BackColor = Color.LightGray;
                    C_Sharp_10.Enabled = false;
                    C_Sharp_10.BackColor = Color.LightGray;
                    C_Sharp_11.Enabled = false;
                    C_Sharp_11.BackColor = Color.LightGray;
                    C_Sharp_12.Enabled = false;
                    C_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (1):
                    C_Sharp_1.Enabled = true;
                    C_Sharp_1.BackColor = Color.Red;
                    C_Sharp_2.Enabled = false;
                    C_Sharp_2.BackColor = Color.LightGray;
                    C_Sharp_3.Enabled = false;
                    C_Sharp_3.BackColor = Color.LightGray;
                    C_Sharp_4.Enabled = false;
                    C_Sharp_4.BackColor = Color.LightGray;
                    C_Sharp_5.Enabled = false;
                    C_Sharp_5.BackColor = Color.LightGray;
                    C_Sharp_6.Enabled = false;
                    C_Sharp_6.BackColor = Color.LightGray;
                    C_Sharp_7.Enabled = false;
                    C_Sharp_7.BackColor = Color.LightGray;
                    C_Sharp_8.Enabled = false;
                    C_Sharp_8.BackColor = Color.LightGray;
                    C_Sharp_9.Enabled = false;
                    C_Sharp_9.BackColor = Color.LightGray;
                    C_Sharp_10.Enabled = false;
                    C_Sharp_10.BackColor = Color.LightGray;
                    C_Sharp_11.Enabled = false;
                    C_Sharp_11.BackColor = Color.LightGray;
                    C_Sharp_12.Enabled = false;
                    C_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (2):
                    C_Sharp_1.Enabled = true;
                    C_Sharp_1.BackColor = Color.Red;
                    C_Sharp_2.Enabled = true;
                    C_Sharp_2.BackColor = Color.Blue;
                    C_Sharp_3.Enabled = false;
                    C_Sharp_3.BackColor = Color.LightGray;
                    C_Sharp_4.Enabled = false;
                    C_Sharp_4.BackColor = Color.LightGray;
                    C_Sharp_5.Enabled = false;
                    C_Sharp_5.BackColor = Color.LightGray;
                    C_Sharp_6.Enabled = false;
                    C_Sharp_6.BackColor = Color.LightGray;
                    C_Sharp_7.Enabled = false;
                    C_Sharp_7.BackColor = Color.LightGray;
                    C_Sharp_8.Enabled = false;
                    C_Sharp_8.BackColor = Color.LightGray;
                    C_Sharp_9.Enabled = false;
                    C_Sharp_9.BackColor = Color.LightGray;
                    C_Sharp_10.Enabled = false;
                    C_Sharp_10.BackColor = Color.LightGray;
                    C_Sharp_11.Enabled = false;
                    C_Sharp_11.BackColor = Color.LightGray;
                    C_Sharp_12.Enabled = false;
                    C_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (3):
                    C_Sharp_1.Enabled = true;
                    C_Sharp_1.BackColor = Color.Red;
                    C_Sharp_2.Enabled = true;
                    C_Sharp_2.BackColor = Color.Lime;
                    C_Sharp_3.Enabled = true;
                    C_Sharp_3.BackColor = Color.Blue;
                    C_Sharp_4.Enabled = false;
                    C_Sharp_4.BackColor = Color.LightGray;
                    C_Sharp_5.Enabled = false;
                    C_Sharp_5.BackColor = Color.LightGray;
                    C_Sharp_6.Enabled = false;
                    C_Sharp_6.BackColor = Color.LightGray;
                    C_Sharp_7.Enabled = false;
                    C_Sharp_7.BackColor = Color.LightGray;
                    C_Sharp_8.Enabled = false;
                    C_Sharp_8.BackColor = Color.LightGray;
                    C_Sharp_9.Enabled = false;
                    C_Sharp_9.BackColor = Color.LightGray;
                    C_Sharp_10.Enabled = false;
                    C_Sharp_10.BackColor = Color.LightGray;
                    C_Sharp_11.Enabled = false;
                    C_Sharp_11.BackColor = Color.LightGray;
                    C_Sharp_12.Enabled = false;
                    C_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (4):
                    C_Sharp_1.Enabled = true;
                    C_Sharp_1.BackColor = Color.Red;
                    C_Sharp_2.Enabled = true;
                    C_Sharp_2.BackColor = Color.Yellow;
                    C_Sharp_3.Enabled = true;
                    C_Sharp_3.BackColor = Color.Lime;
                    C_Sharp_4.Enabled = true;
                    C_Sharp_4.BackColor = Color.Blue;
                    C_Sharp_5.Enabled = false;
                    C_Sharp_5.BackColor = Color.LightGray;
                    C_Sharp_6.Enabled = false;
                    C_Sharp_6.BackColor = Color.LightGray;
                    C_Sharp_7.Enabled = false;
                    C_Sharp_7.BackColor = Color.LightGray;
                    C_Sharp_8.Enabled = false;
                    C_Sharp_8.BackColor = Color.LightGray;
                    C_Sharp_9.Enabled = false;
                    C_Sharp_9.BackColor = Color.LightGray;
                    C_Sharp_10.Enabled = false;
                    C_Sharp_10.BackColor = Color.LightGray;
                    C_Sharp_11.Enabled = false;
                    C_Sharp_11.BackColor = Color.LightGray;
                    C_Sharp_12.Enabled = false;
                    C_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (5):
                    C_Sharp_1.Enabled = true;
                    C_Sharp_1.BackColor = Color.Red;
                    C_Sharp_2.Enabled = true;
                    C_Sharp_2.BackColor = Color.Yellow;
                    C_Sharp_3.Enabled = true;
                    C_Sharp_3.BackColor = Color.Lime;
                    C_Sharp_4.Enabled = true;
                    C_Sharp_4.BackColor = Color.Cyan;
                    C_Sharp_5.Enabled = true;
                    C_Sharp_5.BackColor = Color.Blue;
                    C_Sharp_6.Enabled = false;
                    C_Sharp_6.BackColor = Color.LightGray;
                    C_Sharp_7.Enabled = false;
                    C_Sharp_7.BackColor = Color.LightGray;
                    C_Sharp_8.Enabled = false;
                    C_Sharp_8.BackColor = Color.LightGray;
                    C_Sharp_9.Enabled = false;
                    C_Sharp_9.BackColor = Color.LightGray;
                    C_Sharp_10.Enabled = false;
                    C_Sharp_10.BackColor = Color.LightGray;
                    C_Sharp_11.Enabled = false;
                    C_Sharp_11.BackColor = Color.LightGray;
                    C_Sharp_12.Enabled = false;
                    C_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (6):
                    C_Sharp_1.Enabled = true;
                    C_Sharp_1.BackColor = Color.Red;
                    C_Sharp_2.Enabled = true;
                    C_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_Sharp_3.Enabled = true;
                    C_Sharp_3.BackColor = Color.Yellow;
                    C_Sharp_4.Enabled = true;
                    C_Sharp_4.BackColor = Color.Lime;
                    C_Sharp_5.Enabled = true;
                    C_Sharp_5.BackColor = Color.Cyan;
                    C_Sharp_6.Enabled = true;
                    C_Sharp_6.BackColor = Color.Blue;
                    C_Sharp_7.Enabled = false;
                    C_Sharp_7.BackColor = Color.LightGray;
                    C_Sharp_8.Enabled = false;
                    C_Sharp_8.BackColor = Color.LightGray;
                    C_Sharp_9.Enabled = false;
                    C_Sharp_9.BackColor = Color.LightGray;
                    C_Sharp_10.Enabled = false;
                    C_Sharp_10.BackColor = Color.LightGray;
                    C_Sharp_11.Enabled = false;
                    C_Sharp_11.BackColor = Color.LightGray;
                    C_Sharp_12.Enabled = false;
                    C_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (7):
                    C_Sharp_1.Enabled = true;
                    C_Sharp_1.BackColor = Color.Red;
                    C_Sharp_2.Enabled = true;
                    C_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_Sharp_3.Enabled = true;
                    C_Sharp_3.BackColor = Color.Yellow;
                    C_Sharp_4.Enabled = true;
                    C_Sharp_4.BackColor = Color.Lime;
                    C_Sharp_5.Enabled = true;
                    C_Sharp_5.BackColor = Color.Cyan;
                    C_Sharp_6.Enabled = true;
                    C_Sharp_6.BackColor = Color.Blue;
                    C_Sharp_7.Enabled = true;
                    C_Sharp_7.BackColor = Color.FromArgb(128, 0, 255);
                    C_Sharp_8.Enabled = false;
                    C_Sharp_8.BackColor = Color.LightGray;
                    C_Sharp_9.Enabled = false;
                    C_Sharp_9.BackColor = Color.LightGray;
                    C_Sharp_10.Enabled = false;
                    C_Sharp_10.BackColor = Color.LightGray;
                    C_Sharp_11.Enabled = false;
                    C_Sharp_11.BackColor = Color.LightGray;
                    C_Sharp_12.Enabled = false;
                    C_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (8):
                    C_Sharp_1.Enabled = true;
                    C_Sharp_1.BackColor = Color.Red;
                    C_Sharp_2.Enabled = true;
                    C_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_Sharp_3.Enabled = true;
                    C_Sharp_3.BackColor = Color.Yellow;
                    C_Sharp_4.Enabled = true;
                    C_Sharp_4.BackColor = Color.Lime;
                    C_Sharp_5.Enabled = true;
                    C_Sharp_5.BackColor = Color.Cyan;
                    C_Sharp_6.Enabled = true;
                    C_Sharp_6.BackColor = Color.Blue;
                    C_Sharp_7.Enabled = true;
                    C_Sharp_7.BackColor = Color.FromArgb(128, 0, 255);
                    C_Sharp_8.Enabled = true;
                    C_Sharp_8.BackColor = Color.Magenta;
                    C_Sharp_9.Enabled = false;
                    C_Sharp_9.BackColor = Color.LightGray;
                    C_Sharp_10.Enabled = false;
                    C_Sharp_10.BackColor = Color.LightGray;
                    C_Sharp_11.Enabled = false;
                    C_Sharp_11.BackColor = Color.LightGray;
                    C_Sharp_12.Enabled = false;
                    C_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (9):
                    C_Sharp_1.Enabled = true;
                    C_Sharp_1.BackColor = Color.Red;
                    C_Sharp_2.Enabled = true;
                    C_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_Sharp_3.Enabled = true;
                    C_Sharp_3.BackColor = Color.Yellow;
                    C_Sharp_4.Enabled = true;
                    C_Sharp_4.BackColor = Color.FromArgb(196, 255, 0);
                    C_Sharp_5.Enabled = true;
                    C_Sharp_5.BackColor = Color.Lime;
                    C_Sharp_6.Enabled = true;
                    C_Sharp_6.BackColor = Color.Cyan;
                    C_Sharp_7.Enabled = true;
                    C_Sharp_7.BackColor = Color.Blue;
                    C_Sharp_8.Enabled = true;
                    C_Sharp_8.BackColor = Color.FromArgb(128, 0, 255);
                    C_Sharp_9.Enabled = true;
                    C_Sharp_9.BackColor = Color.Magenta;
                    C_Sharp_10.Enabled = false;
                    C_Sharp_10.BackColor = Color.LightGray;
                    C_Sharp_11.Enabled = false;
                    C_Sharp_11.BackColor = Color.LightGray;
                    C_Sharp_12.Enabled = false;
                    C_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (10):
                    C_Sharp_1.Enabled = true;
                    C_Sharp_1.BackColor = Color.Red;
                    C_Sharp_2.Enabled = true;
                    C_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_Sharp_3.Enabled = true;
                    C_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    C_Sharp_4.Enabled = true;
                    C_Sharp_4.BackColor = Color.Yellow;
                    C_Sharp_5.Enabled = true;
                    C_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    C_Sharp_6.Enabled = true;
                    C_Sharp_6.BackColor = Color.Lime;
                    C_Sharp_7.Enabled = true;
                    C_Sharp_7.BackColor = Color.Cyan;
                    C_Sharp_8.Enabled = true;
                    C_Sharp_8.BackColor = Color.Blue;
                    C_Sharp_9.Enabled = true;
                    C_Sharp_9.BackColor = Color.FromArgb(128, 0, 255);
                    C_Sharp_10.Enabled = true;
                    C_Sharp_10.BackColor = Color.Magenta;
                    C_Sharp_11.Enabled = false;
                    C_Sharp_11.BackColor = Color.LightGray;
                    C_Sharp_12.Enabled = false;
                    C_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (11):
                    C_Sharp_1.Enabled = true;
                    C_Sharp_1.BackColor = Color.Red;
                    C_Sharp_2.Enabled = true;
                    C_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_Sharp_3.Enabled = true;
                    C_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    C_Sharp_4.Enabled = true;
                    C_Sharp_4.BackColor = Color.Yellow;
                    C_Sharp_5.Enabled = true;
                    C_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    C_Sharp_6.Enabled = true;
                    C_Sharp_6.BackColor = Color.Lime;
                    C_Sharp_7.Enabled = true;
                    C_Sharp_7.BackColor = Color.FromArgb(0, 255, 196);
                    C_Sharp_8.Enabled = true;
                    C_Sharp_8.BackColor = Color.Cyan;
                    C_Sharp_9.Enabled = true;
                    C_Sharp_9.BackColor = Color.Blue;
                    C_Sharp_10.Enabled = true;
                    C_Sharp_10.BackColor = Color.FromArgb(128, 0, 255);
                    C_Sharp_11.Enabled = true;
                    C_Sharp_11.BackColor = Color.Magenta;
                    C_Sharp_12.Enabled = false;
                    C_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (12):
                    C_Sharp_1.Enabled = true;
                    C_Sharp_1.BackColor = Color.Red;
                    C_Sharp_2.Enabled = true;
                    C_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    C_Sharp_3.Enabled = true;
                    C_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    C_Sharp_4.Enabled = true;
                    C_Sharp_4.BackColor = Color.Yellow;
                    C_Sharp_5.Enabled = true;
                    C_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    C_Sharp_6.Enabled = true;
                    C_Sharp_6.BackColor = Color.Lime;
                    C_Sharp_7.Enabled = true;
                    C_Sharp_7.BackColor = Color.FromArgb(0, 255, 196);
                    C_Sharp_8.Enabled = true;
                    C_Sharp_8.BackColor = Color.Cyan;
                    C_Sharp_9.Enabled = true;
                    C_Sharp_9.BackColor = Color.Blue;
                    C_Sharp_10.Enabled = true;
                    C_Sharp_10.BackColor = Color.FromArgb(128, 0, 255);
                    C_Sharp_11.Enabled = true;
                    C_Sharp_11.BackColor = Color.FromArgb(196, 0, 255);
                    C_Sharp_12.Enabled = true;
                    C_Sharp_12.BackColor = Color.Magenta;
                    break;
            }
            switch (ncol[2])
            {
                case (0):
                    D_1.Enabled = false;
                    D_1.BackColor = Color.LightGray;
                    D_2.Enabled = false;
                    D_2.BackColor = Color.LightGray;
                    D_3.Enabled = false;
                    D_3.BackColor = Color.LightGray;
                    D_4.Enabled = false;
                    D_4.BackColor = Color.LightGray;
                    D_5.Enabled = false;
                    D_5.BackColor = Color.LightGray;
                    D_6.Enabled = false;
                    D_6.BackColor = Color.LightGray;
                    D_7.Enabled = false;
                    D_7.BackColor = Color.LightGray;
                    D_8.Enabled = false;
                    D_8.BackColor = Color.LightGray;
                    D_9.Enabled = false;
                    D_9.BackColor = Color.LightGray;
                    D_10.Enabled = false;
                    D_10.BackColor = Color.LightGray;
                    D_11.Enabled = false;
                    D_11.BackColor = Color.LightGray;
                    D_12.Enabled = false;
                    D_12.BackColor = Color.LightGray;
                    break;
                case (1):
                    D_1.Enabled = true;
                    D_1.BackColor = Color.Red;
                    D_2.Enabled = false;
                    D_2.BackColor = Color.LightGray;
                    D_3.Enabled = false;
                    D_3.BackColor = Color.LightGray;
                    D_4.Enabled = false;
                    D_4.BackColor = Color.LightGray;
                    D_5.Enabled = false;
                    D_5.BackColor = Color.LightGray;
                    D_6.Enabled = false;
                    D_6.BackColor = Color.LightGray;
                    D_7.Enabled = false;
                    D_7.BackColor = Color.LightGray;
                    D_8.Enabled = false;
                    D_8.BackColor = Color.LightGray;
                    D_9.Enabled = false;
                    D_9.BackColor = Color.LightGray;
                    D_10.Enabled = false;
                    D_10.BackColor = Color.LightGray;
                    D_11.Enabled = false;
                    D_11.BackColor = Color.LightGray;
                    D_12.Enabled = false;
                    D_12.BackColor = Color.LightGray;
                    break;
                case (2):
                    D_1.Enabled = true;
                    D_1.BackColor = Color.Red;
                    D_2.Enabled = true;
                    D_2.BackColor = Color.Blue;
                    D_3.Enabled = false;
                    D_3.BackColor = Color.LightGray;
                    D_4.Enabled = false;
                    D_4.BackColor = Color.LightGray;
                    D_5.Enabled = false;
                    D_5.BackColor = Color.LightGray;
                    D_6.Enabled = false;
                    D_6.BackColor = Color.LightGray;
                    D_7.Enabled = false;
                    D_7.BackColor = Color.LightGray;
                    D_8.Enabled = false;
                    D_8.BackColor = Color.LightGray;
                    D_9.Enabled = false;
                    D_9.BackColor = Color.LightGray;
                    D_10.Enabled = false;
                    D_10.BackColor = Color.LightGray;
                    D_11.Enabled = false;
                    D_11.BackColor = Color.LightGray;
                    D_12.Enabled = false;
                    D_12.BackColor = Color.LightGray;
                    break;
                case (3):
                    D_1.Enabled = true;
                    D_1.BackColor = Color.Red;
                    D_2.Enabled = true;
                    D_2.BackColor = Color.Lime;
                    D_3.Enabled = true;
                    D_3.BackColor = Color.Blue;
                    D_4.Enabled = false;
                    D_4.BackColor = Color.LightGray;
                    D_5.Enabled = false;
                    D_5.BackColor = Color.LightGray;
                    D_6.Enabled = false;
                    D_6.BackColor = Color.LightGray;
                    D_7.Enabled = false;
                    D_7.BackColor = Color.LightGray;
                    D_8.Enabled = false;
                    D_8.BackColor = Color.LightGray;
                    D_9.Enabled = false;
                    D_9.BackColor = Color.LightGray;
                    D_10.Enabled = false;
                    D_10.BackColor = Color.LightGray;
                    D_11.Enabled = false;
                    D_11.BackColor = Color.LightGray;
                    D_12.Enabled = false;
                    D_12.BackColor = Color.LightGray;
                    break;
                case (4):
                    D_1.Enabled = true;
                    D_1.BackColor = Color.Red;
                    D_2.Enabled = true;
                    D_2.BackColor = Color.Yellow;
                    D_3.Enabled = true;
                    D_3.BackColor = Color.Lime;
                    D_4.Enabled = true;
                    D_4.BackColor = Color.Blue;
                    D_5.Enabled = false;
                    D_5.BackColor = Color.LightGray;
                    D_6.Enabled = false;
                    D_6.BackColor = Color.LightGray;
                    D_7.Enabled = false;
                    D_7.BackColor = Color.LightGray;
                    D_8.Enabled = false;
                    D_8.BackColor = Color.LightGray;
                    D_9.Enabled = false;
                    D_9.BackColor = Color.LightGray;
                    D_10.Enabled = false;
                    D_10.BackColor = Color.LightGray;
                    D_11.Enabled = false;
                    D_11.BackColor = Color.LightGray;
                    D_12.Enabled = false;
                    D_12.BackColor = Color.LightGray;
                    break;
                case (5):
                    D_1.Enabled = true;
                    D_1.BackColor = Color.Red;
                    D_2.Enabled = true;
                    D_2.BackColor = Color.Yellow;
                    D_3.Enabled = true;
                    D_3.BackColor = Color.Lime;
                    D_4.Enabled = true;
                    D_4.BackColor = Color.Cyan;
                    D_5.Enabled = true;
                    D_5.BackColor = Color.Blue;
                    D_6.Enabled = false;
                    D_6.BackColor = Color.LightGray;
                    D_7.Enabled = false;
                    D_7.BackColor = Color.LightGray;
                    D_8.Enabled = false;
                    D_8.BackColor = Color.LightGray;
                    D_9.Enabled = false;
                    D_9.BackColor = Color.LightGray;
                    D_10.Enabled = false;
                    D_10.BackColor = Color.LightGray;
                    D_11.Enabled = false;
                    D_11.BackColor = Color.LightGray;
                    D_12.Enabled = false;
                    D_12.BackColor = Color.LightGray;
                    break;
                case (6):
                    D_1.Enabled = true;
                    D_1.BackColor = Color.Red;
                    D_2.Enabled = true;
                    D_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_3.Enabled = true;
                    D_3.BackColor = Color.Yellow;
                    D_4.Enabled = true;
                    D_4.BackColor = Color.Lime;
                    D_5.Enabled = true;
                    D_5.BackColor = Color.Cyan;
                    D_6.Enabled = true;
                    D_6.BackColor = Color.Blue;
                    D_7.Enabled = false;
                    D_7.BackColor = Color.LightGray;
                    D_8.Enabled = false;
                    D_8.BackColor = Color.LightGray;
                    D_9.Enabled = false;
                    D_9.BackColor = Color.LightGray;
                    D_10.Enabled = false;
                    D_10.BackColor = Color.LightGray;
                    D_11.Enabled = false;
                    D_11.BackColor = Color.LightGray;
                    D_12.Enabled = false;
                    D_12.BackColor = Color.LightGray;
                    break;
                case (7):
                    D_1.Enabled = true;
                    D_1.BackColor = Color.Red;
                    D_2.Enabled = true;
                    D_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_3.Enabled = true;
                    D_3.BackColor = Color.Yellow;
                    D_4.Enabled = true;
                    D_4.BackColor = Color.Lime;
                    D_5.Enabled = true;
                    D_5.BackColor = Color.Cyan;
                    D_6.Enabled = true;
                    D_6.BackColor = Color.Blue;
                    D_7.Enabled = true;
                    D_7.BackColor = Color.FromArgb(128, 0, 255);
                    D_8.Enabled = false;
                    D_8.BackColor = Color.LightGray;
                    D_9.Enabled = false;
                    D_9.BackColor = Color.LightGray;
                    D_10.Enabled = false;
                    D_10.BackColor = Color.LightGray;
                    D_11.Enabled = false;
                    D_11.BackColor = Color.LightGray;
                    D_12.Enabled = false;
                    D_12.BackColor = Color.LightGray;
                    break;
                case (8):
                    D_1.Enabled = true;
                    D_1.BackColor = Color.Red;
                    D_2.Enabled = true;
                    D_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_3.Enabled = true;
                    D_3.BackColor = Color.Yellow;
                    D_4.Enabled = true;
                    D_4.BackColor = Color.Lime;
                    D_5.Enabled = true;
                    D_5.BackColor = Color.Cyan;
                    D_6.Enabled = true;
                    D_6.BackColor = Color.Blue;
                    D_7.Enabled = true;
                    D_7.BackColor = Color.FromArgb(128, 0, 255);
                    D_8.Enabled = true;
                    D_8.BackColor = Color.Magenta;
                    D_9.Enabled = false;
                    D_9.BackColor = Color.LightGray;
                    D_10.Enabled = false;
                    D_10.BackColor = Color.LightGray;
                    D_11.Enabled = false;
                    D_11.BackColor = Color.LightGray;
                    D_12.Enabled = false;
                    D_12.BackColor = Color.LightGray;
                    break;
                case (9):
                    D_1.Enabled = true;
                    D_1.BackColor = Color.Red;
                    D_2.Enabled = true;
                    D_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_3.Enabled = true;
                    D_3.BackColor = Color.Yellow;
                    D_4.Enabled = true;
                    D_4.BackColor = Color.FromArgb(196, 255, 0);
                    D_5.Enabled = true;
                    D_5.BackColor = Color.Lime;
                    D_6.Enabled = true;
                    D_6.BackColor = Color.Cyan;
                    D_7.Enabled = true;
                    D_7.BackColor = Color.Blue;
                    D_8.Enabled = true;
                    D_8.BackColor = Color.FromArgb(128, 0, 255);
                    D_9.Enabled = true;
                    D_9.BackColor = Color.Magenta;
                    D_10.Enabled = false;
                    D_10.BackColor = Color.LightGray;
                    D_11.Enabled = false;
                    D_11.BackColor = Color.LightGray;
                    D_12.Enabled = false;
                    D_12.BackColor = Color.LightGray;
                    break;
                case (10):
                    D_1.Enabled = true;
                    D_1.BackColor = Color.Red;
                    D_2.Enabled = true;
                    D_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_3.Enabled = true;
                    D_3.BackColor = Color.FromArgb(255, 196, 0);
                    D_4.Enabled = true;
                    D_4.BackColor = Color.Yellow;
                    D_5.Enabled = true;
                    D_5.BackColor = Color.FromArgb(196, 255, 0);
                    D_6.Enabled = true;
                    D_6.BackColor = Color.Lime;
                    D_7.Enabled = true;
                    D_7.BackColor = Color.Cyan;
                    D_8.Enabled = true;
                    D_8.BackColor = Color.Blue;
                    D_9.Enabled = true;
                    D_9.BackColor = Color.FromArgb(128, 0, 255);
                    D_10.Enabled = true;
                    D_10.BackColor = Color.Magenta;
                    D_11.Enabled = false;
                    D_11.BackColor = Color.LightGray;
                    D_12.Enabled = false;
                    D_12.BackColor = Color.LightGray;
                    break;
                case (11):
                    D_1.Enabled = true;
                    D_1.BackColor = Color.Red;
                    D_2.Enabled = true;
                    D_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_3.Enabled = true;
                    D_3.BackColor = Color.FromArgb(255, 196, 0);
                    D_4.Enabled = true;
                    D_4.BackColor = Color.Yellow;
                    D_5.Enabled = true;
                    D_5.BackColor = Color.FromArgb(196, 255, 0);
                    D_6.Enabled = true;
                    D_6.BackColor = Color.Lime;
                    D_7.Enabled = true;
                    D_7.BackColor = Color.FromArgb(0, 255, 196);
                    D_8.Enabled = true;
                    D_8.BackColor = Color.Cyan;
                    D_9.Enabled = true;
                    D_9.BackColor = Color.Blue;
                    D_10.Enabled = true;
                    D_10.BackColor = Color.FromArgb(128, 0, 255);
                    D_11.Enabled = true;
                    D_11.BackColor = Color.Magenta;
                    D_12.Enabled = false;
                    D_12.BackColor = Color.LightGray;
                    break;
                case (12):
                    D_1.Enabled = true;
                    D_1.BackColor = Color.Red;
                    D_2.Enabled = true;
                    D_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_3.Enabled = true;
                    D_3.BackColor = Color.FromArgb(255, 196, 0);
                    D_4.Enabled = true;
                    D_4.BackColor = Color.Yellow;
                    D_5.Enabled = true;
                    D_5.BackColor = Color.FromArgb(196, 255, 0);
                    D_6.Enabled = true;
                    D_6.BackColor = Color.Lime;
                    D_7.Enabled = true;
                    D_7.BackColor = Color.FromArgb(0, 255, 196);
                    D_8.Enabled = true;
                    D_8.BackColor = Color.Cyan;
                    D_9.Enabled = true;
                    D_9.BackColor = Color.Blue;
                    D_10.Enabled = true;
                    D_10.BackColor = Color.FromArgb(128, 0, 255);
                    D_11.Enabled = true;
                    D_11.BackColor = Color.FromArgb(196, 0, 255);
                    D_12.Enabled = true;
                    D_12.BackColor = Color.Magenta;
                    break;
            }
            switch (ncol[3])
            {
                case (0):
                    D_Sharp_1.Enabled = false;
                    D_Sharp_1.BackColor = Color.LightGray;
                    D_Sharp_2.Enabled = false;
                    D_Sharp_2.BackColor = Color.LightGray;
                    D_Sharp_3.Enabled = false;
                    D_Sharp_3.BackColor = Color.LightGray;
                    D_Sharp_4.Enabled = false;
                    D_Sharp_4.BackColor = Color.LightGray;
                    D_Sharp_5.Enabled = false;
                    D_Sharp_5.BackColor = Color.LightGray;
                    D_Sharp_6.Enabled = false;
                    D_Sharp_6.BackColor = Color.LightGray;
                    D_Sharp_7.Enabled = false;
                    D_Sharp_7.BackColor = Color.LightGray;
                    D_Sharp_8.Enabled = false;
                    D_Sharp_8.BackColor = Color.LightGray;
                    D_Sharp_9.Enabled = false;
                    D_Sharp_9.BackColor = Color.LightGray;
                    D_Sharp_10.Enabled = false;
                    D_Sharp_10.BackColor = Color.LightGray;
                    D_Sharp_11.Enabled = false;
                    D_Sharp_11.BackColor = Color.LightGray;
                    D_Sharp_12.Enabled = false;
                    D_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (1):
                    D_Sharp_1.Enabled = true;
                    D_Sharp_1.BackColor = Color.Red;
                    D_Sharp_2.Enabled = false;
                    D_Sharp_2.BackColor = Color.LightGray;
                    D_Sharp_3.Enabled = false;
                    D_Sharp_3.BackColor = Color.LightGray;
                    D_Sharp_4.Enabled = false;
                    D_Sharp_4.BackColor = Color.LightGray;
                    D_Sharp_5.Enabled = false;
                    D_Sharp_5.BackColor = Color.LightGray;
                    D_Sharp_6.Enabled = false;
                    D_Sharp_6.BackColor = Color.LightGray;
                    D_Sharp_7.Enabled = false;
                    D_Sharp_7.BackColor = Color.LightGray;
                    D_Sharp_8.Enabled = false;
                    D_Sharp_8.BackColor = Color.LightGray;
                    D_Sharp_9.Enabled = false;
                    D_Sharp_9.BackColor = Color.LightGray;
                    D_Sharp_10.Enabled = false;
                    D_Sharp_10.BackColor = Color.LightGray;
                    D_Sharp_11.Enabled = false;
                    D_Sharp_11.BackColor = Color.LightGray;
                    D_Sharp_12.Enabled = false;
                    D_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (2):
                    D_Sharp_1.Enabled = true;
                    D_Sharp_1.BackColor = Color.Red;
                    D_Sharp_2.Enabled = true;
                    D_Sharp_2.BackColor = Color.Blue;
                    D_Sharp_3.Enabled = false;
                    D_Sharp_3.BackColor = Color.LightGray;
                    D_Sharp_4.Enabled = false;
                    D_Sharp_4.BackColor = Color.LightGray;
                    D_Sharp_5.Enabled = false;
                    D_Sharp_5.BackColor = Color.LightGray;
                    D_Sharp_6.Enabled = false;
                    D_Sharp_6.BackColor = Color.LightGray;
                    D_Sharp_7.Enabled = false;
                    D_Sharp_7.BackColor = Color.LightGray;
                    D_Sharp_8.Enabled = false;
                    D_Sharp_8.BackColor = Color.LightGray;
                    D_Sharp_9.Enabled = false;
                    D_Sharp_9.BackColor = Color.LightGray;
                    D_Sharp_10.Enabled = false;
                    D_Sharp_10.BackColor = Color.LightGray;
                    D_Sharp_11.Enabled = false;
                    D_Sharp_11.BackColor = Color.LightGray;
                    D_Sharp_12.Enabled = false;
                    D_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (3):
                    D_Sharp_1.Enabled = true;
                    D_Sharp_1.BackColor = Color.Red;
                    D_Sharp_2.Enabled = true;
                    D_Sharp_2.BackColor = Color.Lime;
                    D_Sharp_3.Enabled = true;
                    D_Sharp_3.BackColor = Color.Blue;
                    D_Sharp_4.Enabled = false;
                    D_Sharp_4.BackColor = Color.LightGray;
                    D_Sharp_5.Enabled = false;
                    D_Sharp_5.BackColor = Color.LightGray;
                    D_Sharp_6.Enabled = false;
                    D_Sharp_6.BackColor = Color.LightGray;
                    D_Sharp_7.Enabled = false;
                    D_Sharp_7.BackColor = Color.LightGray;
                    D_Sharp_8.Enabled = false;
                    D_Sharp_8.BackColor = Color.LightGray;
                    D_Sharp_9.Enabled = false;
                    D_Sharp_9.BackColor = Color.LightGray;
                    D_Sharp_10.Enabled = false;
                    D_Sharp_10.BackColor = Color.LightGray;
                    D_Sharp_11.Enabled = false;
                    D_Sharp_11.BackColor = Color.LightGray;
                    D_Sharp_12.Enabled = false;
                    D_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (4):
                    D_Sharp_1.Enabled = true;
                    D_Sharp_1.BackColor = Color.Red;
                    D_Sharp_2.Enabled = true;
                    D_Sharp_2.BackColor = Color.Yellow;
                    D_Sharp_3.Enabled = true;
                    D_Sharp_3.BackColor = Color.Lime;
                    D_Sharp_4.Enabled = true;
                    D_Sharp_4.BackColor = Color.Blue;
                    D_Sharp_5.Enabled = false;
                    D_Sharp_5.BackColor = Color.LightGray;
                    D_Sharp_6.Enabled = false;
                    D_Sharp_6.BackColor = Color.LightGray;
                    D_Sharp_7.Enabled = false;
                    D_Sharp_7.BackColor = Color.LightGray;
                    D_Sharp_8.Enabled = false;
                    D_Sharp_8.BackColor = Color.LightGray;
                    D_Sharp_9.Enabled = false;
                    D_Sharp_9.BackColor = Color.LightGray;
                    D_Sharp_10.Enabled = false;
                    D_Sharp_10.BackColor = Color.LightGray;
                    D_Sharp_11.Enabled = false;
                    D_Sharp_11.BackColor = Color.LightGray;
                    D_Sharp_12.Enabled = false;
                    D_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (5):
                    D_Sharp_1.Enabled = true;
                    D_Sharp_1.BackColor = Color.Red;
                    D_Sharp_2.Enabled = true;
                    D_Sharp_2.BackColor = Color.Yellow;
                    D_Sharp_3.Enabled = true;
                    D_Sharp_3.BackColor = Color.Lime;
                    D_Sharp_4.Enabled = true;
                    D_Sharp_4.BackColor = Color.Cyan;
                    D_Sharp_5.Enabled = true;
                    D_Sharp_5.BackColor = Color.Blue;
                    D_Sharp_6.Enabled = false;
                    D_Sharp_6.BackColor = Color.LightGray;
                    D_Sharp_7.Enabled = false;
                    D_Sharp_7.BackColor = Color.LightGray;
                    D_Sharp_8.Enabled = false;
                    D_Sharp_8.BackColor = Color.LightGray;
                    D_Sharp_9.Enabled = false;
                    D_Sharp_9.BackColor = Color.LightGray;
                    D_Sharp_10.Enabled = false;
                    D_Sharp_10.BackColor = Color.LightGray;
                    D_Sharp_11.Enabled = false;
                    D_Sharp_11.BackColor = Color.LightGray;
                    D_Sharp_12.Enabled = false;
                    D_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (6):
                    D_Sharp_1.Enabled = true;
                    D_Sharp_1.BackColor = Color.Red;
                    D_Sharp_2.Enabled = true;
                    D_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_Sharp_3.Enabled = true;
                    D_Sharp_3.BackColor = Color.Yellow;
                    D_Sharp_4.Enabled = true;
                    D_Sharp_4.BackColor = Color.Lime;
                    D_Sharp_5.Enabled = true;
                    D_Sharp_5.BackColor = Color.Cyan;
                    D_Sharp_6.Enabled = true;
                    D_Sharp_6.BackColor = Color.Blue;
                    D_Sharp_7.Enabled = false;
                    D_Sharp_7.BackColor = Color.LightGray;
                    D_Sharp_8.Enabled = false;
                    D_Sharp_8.BackColor = Color.LightGray;
                    D_Sharp_9.Enabled = false;
                    D_Sharp_9.BackColor = Color.LightGray;
                    D_Sharp_10.Enabled = false;
                    D_Sharp_10.BackColor = Color.LightGray;
                    D_Sharp_11.Enabled = false;
                    D_Sharp_11.BackColor = Color.LightGray;
                    D_Sharp_12.Enabled = false;
                    D_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (7):
                    D_Sharp_1.Enabled = true;
                    D_Sharp_1.BackColor = Color.Red;
                    D_Sharp_2.Enabled = true;
                    D_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_Sharp_3.Enabled = true;
                    D_Sharp_3.BackColor = Color.Yellow;
                    D_Sharp_4.Enabled = true;
                    D_Sharp_4.BackColor = Color.Lime;
                    D_Sharp_5.Enabled = true;
                    D_Sharp_5.BackColor = Color.Cyan;
                    D_Sharp_6.Enabled = true;
                    D_Sharp_6.BackColor = Color.Blue;
                    D_Sharp_7.Enabled = true;
                    D_Sharp_7.BackColor = Color.FromArgb(128, 0, 255);
                    D_Sharp_8.Enabled = false;
                    D_Sharp_8.BackColor = Color.LightGray;
                    D_Sharp_9.Enabled = false;
                    D_Sharp_9.BackColor = Color.LightGray;
                    D_Sharp_10.Enabled = false;
                    D_Sharp_10.BackColor = Color.LightGray;
                    D_Sharp_11.Enabled = false;
                    D_Sharp_11.BackColor = Color.LightGray;
                    D_Sharp_12.Enabled = false;
                    D_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (8):
                    D_Sharp_1.Enabled = true;
                    D_Sharp_1.BackColor = Color.Red;
                    D_Sharp_2.Enabled = true;
                    D_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_Sharp_3.Enabled = true;
                    D_Sharp_3.BackColor = Color.Yellow;
                    D_Sharp_4.Enabled = true;
                    D_Sharp_4.BackColor = Color.Lime;
                    D_Sharp_5.Enabled = true;
                    D_Sharp_5.BackColor = Color.Cyan;
                    D_Sharp_6.Enabled = true;
                    D_Sharp_6.BackColor = Color.Blue;
                    D_Sharp_7.Enabled = true;
                    D_Sharp_7.BackColor = Color.FromArgb(128, 0, 255);
                    D_Sharp_8.Enabled = true;
                    D_Sharp_8.BackColor = Color.Magenta;
                    D_Sharp_9.Enabled = false;
                    D_Sharp_9.BackColor = Color.LightGray;
                    D_Sharp_10.Enabled = false;
                    D_Sharp_10.BackColor = Color.LightGray;
                    D_Sharp_11.Enabled = false;
                    D_Sharp_11.BackColor = Color.LightGray;
                    D_Sharp_12.Enabled = false;
                    D_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (9):
                    D_Sharp_1.Enabled = true;
                    D_Sharp_1.BackColor = Color.Red;
                    D_Sharp_2.Enabled = true;
                    D_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_Sharp_3.Enabled = true;
                    D_Sharp_3.BackColor = Color.Yellow;
                    D_Sharp_4.Enabled = true;
                    D_Sharp_4.BackColor = Color.FromArgb(196, 255, 0);
                    D_Sharp_5.Enabled = true;
                    D_Sharp_5.BackColor = Color.Lime;
                    D_Sharp_6.Enabled = true;
                    D_Sharp_6.BackColor = Color.Cyan;
                    D_Sharp_7.Enabled = true;
                    D_Sharp_7.BackColor = Color.Blue;
                    D_Sharp_8.Enabled = true;
                    D_Sharp_8.BackColor = Color.FromArgb(128, 0, 255);
                    D_Sharp_9.Enabled = true;
                    D_Sharp_9.BackColor = Color.Magenta;
                    D_Sharp_10.Enabled = false;
                    D_Sharp_10.BackColor = Color.LightGray;
                    D_Sharp_11.Enabled = false;
                    D_Sharp_11.BackColor = Color.LightGray;
                    D_Sharp_12.Enabled = false;
                    D_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (10):
                    D_Sharp_1.Enabled = true;
                    D_Sharp_1.BackColor = Color.Red;
                    D_Sharp_2.Enabled = true;
                    D_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_Sharp_3.Enabled = true;
                    D_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    D_Sharp_4.Enabled = true;
                    D_Sharp_4.BackColor = Color.Yellow;
                    D_Sharp_5.Enabled = true;
                    D_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    D_Sharp_6.Enabled = true;
                    D_Sharp_6.BackColor = Color.Lime;
                    D_Sharp_7.Enabled = true;
                    D_Sharp_7.BackColor = Color.Cyan;
                    D_Sharp_8.Enabled = true;
                    D_Sharp_8.BackColor = Color.Blue;
                    D_Sharp_9.Enabled = true;
                    D_Sharp_9.BackColor = Color.FromArgb(128, 0, 255);
                    D_Sharp_10.Enabled = true;
                    D_Sharp_10.BackColor = Color.Magenta;
                    D_Sharp_11.Enabled = false;
                    D_Sharp_11.BackColor = Color.LightGray;
                    D_Sharp_12.Enabled = false;
                    D_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (11):
                    D_Sharp_1.Enabled = true;
                    D_Sharp_1.BackColor = Color.Red;
                    D_Sharp_2.Enabled = true;
                    D_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_Sharp_3.Enabled = true;
                    D_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    D_Sharp_4.Enabled = true;
                    D_Sharp_4.BackColor = Color.Yellow;
                    D_Sharp_5.Enabled = true;
                    D_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    D_Sharp_6.Enabled = true;
                    D_Sharp_6.BackColor = Color.Lime;
                    D_Sharp_7.Enabled = true;
                    D_Sharp_7.BackColor = Color.FromArgb(0, 255, 196);
                    D_Sharp_8.Enabled = true;
                    D_Sharp_8.BackColor = Color.Cyan;
                    D_Sharp_9.Enabled = true;
                    D_Sharp_9.BackColor = Color.Blue;
                    D_Sharp_10.Enabled = true;
                    D_Sharp_10.BackColor = Color.FromArgb(128, 0, 255);
                    D_Sharp_11.Enabled = true;
                    D_Sharp_11.BackColor = Color.Magenta;
                    D_Sharp_12.Enabled = false;
                    D_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (12):
                    D_Sharp_1.Enabled = true;
                    D_Sharp_1.BackColor = Color.Red;
                    D_Sharp_2.Enabled = true;
                    D_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    D_Sharp_3.Enabled = true;
                    D_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    D_Sharp_4.Enabled = true;
                    D_Sharp_4.BackColor = Color.Yellow;
                    D_Sharp_5.Enabled = true;
                    D_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    D_Sharp_6.Enabled = true;
                    D_Sharp_6.BackColor = Color.Lime;
                    D_Sharp_7.Enabled = true;
                    D_Sharp_7.BackColor = Color.FromArgb(0, 255, 196);
                    D_Sharp_8.Enabled = true;
                    D_Sharp_8.BackColor = Color.Cyan;
                    D_Sharp_9.Enabled = true;
                    D_Sharp_9.BackColor = Color.Blue;
                    D_Sharp_10.Enabled = true;
                    D_Sharp_10.BackColor = Color.FromArgb(128, 0, 255);
                    D_Sharp_11.Enabled = true;
                    D_Sharp_11.BackColor = Color.FromArgb(196, 0, 255);
                    D_Sharp_12.Enabled = true;
                    D_Sharp_12.BackColor = Color.Magenta;
                    break;
            }
            switch (ncol[4])
            {
                case (0):
                    E_1.Enabled = false;
                    E_1.BackColor = Color.LightGray;
                    E_2.Enabled = false;
                    E_2.BackColor = Color.LightGray;
                    E_3.Enabled = false;
                    E_3.BackColor = Color.LightGray;
                    E_4.Enabled = false;
                    E_4.BackColor = Color.LightGray;
                    E_5.Enabled = false;
                    E_5.BackColor = Color.LightGray;
                    E_6.Enabled = false;
                    E_6.BackColor = Color.LightGray;
                    E_7.Enabled = false;
                    E_7.BackColor = Color.LightGray;
                    E_8.Enabled = false;
                    E_8.BackColor = Color.LightGray;
                    E_9.Enabled = false;
                    E_9.BackColor = Color.LightGray;
                    E_10.Enabled = false;
                    E_10.BackColor = Color.LightGray;
                    E_11.Enabled = false;
                    E_11.BackColor = Color.LightGray;
                    E_12.Enabled = false;
                    E_12.BackColor = Color.LightGray;
                    break;
                case (1):
                    E_1.Enabled = true;
                    E_1.BackColor = Color.Red;
                    E_2.Enabled = false;
                    E_2.BackColor = Color.LightGray;
                    E_3.Enabled = false;
                    E_3.BackColor = Color.LightGray;
                    E_4.Enabled = false;
                    E_4.BackColor = Color.LightGray;
                    E_5.Enabled = false;
                    E_5.BackColor = Color.LightGray;
                    E_6.Enabled = false;
                    E_6.BackColor = Color.LightGray;
                    E_7.Enabled = false;
                    E_7.BackColor = Color.LightGray;
                    E_8.Enabled = false;
                    E_8.BackColor = Color.LightGray;
                    E_9.Enabled = false;
                    E_9.BackColor = Color.LightGray;
                    E_10.Enabled = false;
                    E_10.BackColor = Color.LightGray;
                    E_11.Enabled = false;
                    E_11.BackColor = Color.LightGray;
                    E_12.Enabled = false;
                    E_12.BackColor = Color.LightGray;
                    break;
                case (2):
                    E_1.Enabled = true;
                    E_1.BackColor = Color.Red;
                    E_2.Enabled = true;
                    E_2.BackColor = Color.Blue;
                    E_3.Enabled = false;
                    E_3.BackColor = Color.LightGray;
                    E_4.Enabled = false;
                    E_4.BackColor = Color.LightGray;
                    E_5.Enabled = false;
                    E_5.BackColor = Color.LightGray;
                    E_6.Enabled = false;
                    E_6.BackColor = Color.LightGray;
                    E_7.Enabled = false;
                    E_7.BackColor = Color.LightGray;
                    E_8.Enabled = false;
                    E_8.BackColor = Color.LightGray;
                    E_9.Enabled = false;
                    E_9.BackColor = Color.LightGray;
                    E_10.Enabled = false;
                    E_10.BackColor = Color.LightGray;
                    E_11.Enabled = false;
                    E_11.BackColor = Color.LightGray;
                    E_12.Enabled = false;
                    E_12.BackColor = Color.LightGray;
                    break;
                case (3):
                    E_1.Enabled = true;
                    E_1.BackColor = Color.Red;
                    E_2.Enabled = true;
                    E_2.BackColor = Color.Lime;
                    E_3.Enabled = true;
                    E_3.BackColor = Color.Blue;
                    E_4.Enabled = false;
                    E_4.BackColor = Color.LightGray;
                    E_5.Enabled = false;
                    E_5.BackColor = Color.LightGray;
                    E_6.Enabled = false;
                    E_6.BackColor = Color.LightGray;
                    E_7.Enabled = false;
                    E_7.BackColor = Color.LightGray;
                    E_8.Enabled = false;
                    E_8.BackColor = Color.LightGray;
                    E_9.Enabled = false;
                    E_9.BackColor = Color.LightGray;
                    E_10.Enabled = false;
                    E_10.BackColor = Color.LightGray;
                    E_11.Enabled = false;
                    E_11.BackColor = Color.LightGray;
                    E_12.Enabled = false;
                    E_12.BackColor = Color.LightGray;
                    break;
                case (4):
                    E_1.Enabled = true;
                    E_1.BackColor = Color.Red;
                    E_2.Enabled = true;
                    E_2.BackColor = Color.Yellow;
                    E_3.Enabled = true;
                    E_3.BackColor = Color.Lime;
                    E_4.Enabled = true;
                    E_4.BackColor = Color.Blue;
                    E_5.Enabled = false;
                    E_5.BackColor = Color.LightGray;
                    E_6.Enabled = false;
                    E_6.BackColor = Color.LightGray;
                    E_7.Enabled = false;
                    E_7.BackColor = Color.LightGray;
                    E_8.Enabled = false;
                    E_8.BackColor = Color.LightGray;
                    E_9.Enabled = false;
                    E_9.BackColor = Color.LightGray;
                    E_10.Enabled = false;
                    E_10.BackColor = Color.LightGray;
                    E_11.Enabled = false;
                    E_11.BackColor = Color.LightGray;
                    E_12.Enabled = false;
                    E_12.BackColor = Color.LightGray;
                    break;
                case (5):
                    E_1.Enabled = true;
                    E_1.BackColor = Color.Red;
                    E_2.Enabled = true;
                    E_2.BackColor = Color.Yellow;
                    E_3.Enabled = true;
                    E_3.BackColor = Color.Lime;
                    E_4.Enabled = true;
                    E_4.BackColor = Color.Cyan;
                    E_5.Enabled = true;
                    E_5.BackColor = Color.Blue;
                    E_6.Enabled = false;
                    E_6.BackColor = Color.LightGray;
                    E_7.Enabled = false;
                    E_7.BackColor = Color.LightGray;
                    E_8.Enabled = false;
                    E_8.BackColor = Color.LightGray;
                    E_9.Enabled = false;
                    E_9.BackColor = Color.LightGray;
                    E_10.Enabled = false;
                    E_10.BackColor = Color.LightGray;
                    E_11.Enabled = false;
                    E_11.BackColor = Color.LightGray;
                    E_12.Enabled = false;
                    E_12.BackColor = Color.LightGray;
                    break;
                case (6):
                    E_1.Enabled = true;
                    E_1.BackColor = Color.Red;
                    E_2.Enabled = true;
                    E_2.BackColor = Color.FromArgb(255, 128, 0);
                    E_3.Enabled = true;
                    E_3.BackColor = Color.Yellow;
                    E_4.Enabled = true;
                    E_4.BackColor = Color.Lime;
                    E_5.Enabled = true;
                    E_5.BackColor = Color.Cyan;
                    E_6.Enabled = true;
                    E_6.BackColor = Color.Blue;
                    E_7.Enabled = false;
                    E_7.BackColor = Color.LightGray;
                    E_8.Enabled = false;
                    E_8.BackColor = Color.LightGray;
                    E_9.Enabled = false;
                    E_9.BackColor = Color.LightGray;
                    E_10.Enabled = false;
                    E_10.BackColor = Color.LightGray;
                    E_11.Enabled = false;
                    E_11.BackColor = Color.LightGray;
                    E_12.Enabled = false;
                    E_12.BackColor = Color.LightGray;
                    break;
                case (7):
                    E_1.Enabled = true;
                    E_1.BackColor = Color.Red;
                    E_2.Enabled = true;
                    E_2.BackColor = Color.FromArgb(255, 128, 0);
                    E_3.Enabled = true;
                    E_3.BackColor = Color.Yellow;
                    E_4.Enabled = true;
                    E_4.BackColor = Color.Lime;
                    E_5.Enabled = true;
                    E_5.BackColor = Color.Cyan;
                    E_6.Enabled = true;
                    E_6.BackColor = Color.Blue;
                    E_7.Enabled = true;
                    E_7.BackColor = Color.FromArgb(128, 0, 255);
                    E_8.Enabled = false;
                    E_8.BackColor = Color.LightGray;
                    E_9.Enabled = false;
                    E_9.BackColor = Color.LightGray;
                    E_10.Enabled = false;
                    E_10.BackColor = Color.LightGray;
                    E_11.Enabled = false;
                    E_11.BackColor = Color.LightGray;
                    E_12.Enabled = false;
                    E_12.BackColor = Color.LightGray;
                    break;
                case (8):
                    E_1.Enabled = true;
                    E_1.BackColor = Color.Red;
                    E_2.Enabled = true;
                    E_2.BackColor = Color.FromArgb(255, 128, 0);
                    E_3.Enabled = true;
                    E_3.BackColor = Color.Yellow;
                    E_4.Enabled = true;
                    E_4.BackColor = Color.Lime;
                    E_5.Enabled = true;
                    E_5.BackColor = Color.Cyan;
                    E_6.Enabled = true;
                    E_6.BackColor = Color.Blue;
                    E_7.Enabled = true;
                    E_7.BackColor = Color.FromArgb(128, 0, 255);
                    E_8.Enabled = true;
                    E_8.BackColor = Color.Magenta;
                    E_9.Enabled = false;
                    E_9.BackColor = Color.LightGray;
                    E_10.Enabled = false;
                    E_10.BackColor = Color.LightGray;
                    E_11.Enabled = false;
                    E_11.BackColor = Color.LightGray;
                    E_12.Enabled = false;
                    E_12.BackColor = Color.LightGray;
                    break;
                case (9):
                    E_1.Enabled = true;
                    E_1.BackColor = Color.Red;
                    E_2.Enabled = true;
                    E_2.BackColor = Color.FromArgb(255, 128, 0);
                    E_3.Enabled = true;
                    E_3.BackColor = Color.Yellow;
                    E_4.Enabled = true;
                    E_4.BackColor = Color.FromArgb(196, 255, 0);
                    E_5.Enabled = true;
                    E_5.BackColor = Color.Lime;
                    E_6.Enabled = true;
                    E_6.BackColor = Color.Cyan;
                    E_7.Enabled = true;
                    E_7.BackColor = Color.Blue;
                    E_8.Enabled = true;
                    E_8.BackColor = Color.FromArgb(128, 0, 255);
                    E_9.Enabled = true;
                    E_9.BackColor = Color.Magenta;
                    E_10.Enabled = false;
                    E_10.BackColor = Color.LightGray;
                    E_11.Enabled = false;
                    E_11.BackColor = Color.LightGray;
                    E_12.Enabled = false;
                    E_12.BackColor = Color.LightGray;
                    break;
                case (10):
                    E_1.Enabled = true;
                    E_1.BackColor = Color.Red;
                    E_2.Enabled = true;
                    E_2.BackColor = Color.FromArgb(255, 128, 0);
                    E_3.Enabled = true;
                    E_3.BackColor = Color.FromArgb(255, 196, 0);
                    E_4.Enabled = true;
                    E_4.BackColor = Color.Yellow;
                    E_5.Enabled = true;
                    E_5.BackColor = Color.FromArgb(196, 255, 0);
                    E_6.Enabled = true;
                    E_6.BackColor = Color.Lime;
                    E_7.Enabled = true;
                    E_7.BackColor = Color.Cyan;
                    E_8.Enabled = true;
                    E_8.BackColor = Color.Blue;
                    E_9.Enabled = true;
                    E_9.BackColor = Color.FromArgb(128, 0, 255);
                    E_10.Enabled = true;
                    E_10.BackColor = Color.Magenta;
                    E_11.Enabled = false;
                    E_11.BackColor = Color.LightGray;
                    E_12.Enabled = false;
                    E_12.BackColor = Color.LightGray;
                    break;
                case (11):
                    E_1.Enabled = true;
                    E_1.BackColor = Color.Red;
                    E_2.Enabled = true;
                    E_2.BackColor = Color.FromArgb(255, 128, 0);
                    E_3.Enabled = true;
                    E_3.BackColor = Color.FromArgb(255, 196, 0);
                    E_4.Enabled = true;
                    E_4.BackColor = Color.Yellow;
                    E_5.Enabled = true;
                    E_5.BackColor = Color.FromArgb(196, 255, 0);
                    E_6.Enabled = true;
                    E_6.BackColor = Color.Lime;
                    E_7.Enabled = true;
                    E_7.BackColor = Color.FromArgb(0, 255, 196);
                    E_8.Enabled = true;
                    E_8.BackColor = Color.Cyan;
                    E_9.Enabled = true;
                    E_9.BackColor = Color.Blue;
                    E_10.Enabled = true;
                    E_10.BackColor = Color.FromArgb(128, 0, 255);
                    E_11.Enabled = true;
                    E_11.BackColor = Color.Magenta;
                    E_12.Enabled = false;
                    E_12.BackColor = Color.LightGray;
                    break;
                case (12):
                    E_1.Enabled = true;
                    E_1.BackColor = Color.Red;
                    E_2.Enabled = true;
                    E_2.BackColor = Color.FromArgb(255, 128, 0);
                    E_3.Enabled = true;
                    E_3.BackColor = Color.FromArgb(255, 196, 0);
                    E_4.Enabled = true;
                    E_4.BackColor = Color.Yellow;
                    E_5.Enabled = true;
                    E_5.BackColor = Color.FromArgb(196, 255, 0);
                    E_6.Enabled = true;
                    E_6.BackColor = Color.Lime;
                    E_7.Enabled = true;
                    E_7.BackColor = Color.FromArgb(0, 255, 196);
                    E_8.Enabled = true;
                    E_8.BackColor = Color.Cyan;
                    E_9.Enabled = true;
                    E_9.BackColor = Color.Blue;
                    E_10.Enabled = true;
                    E_10.BackColor = Color.FromArgb(128, 0, 255);
                    E_11.Enabled = true;
                    E_11.BackColor = Color.FromArgb(196, 0, 255);
                    E_12.Enabled = true;
                    E_12.BackColor = Color.Magenta;
                    break;
            }
            switch (ncol[5])
            {
                case (0):
                    F_1.Enabled = false;
                    F_1.BackColor = Color.LightGray;
                    F_2.Enabled = false;
                    F_2.BackColor = Color.LightGray;
                    F_3.Enabled = false;
                    F_3.BackColor = Color.LightGray;
                    F_4.Enabled = false;
                    F_4.BackColor = Color.LightGray;
                    F_5.Enabled = false;
                    F_5.BackColor = Color.LightGray;
                    F_6.Enabled = false;
                    F_6.BackColor = Color.LightGray;
                    F_7.Enabled = false;
                    F_7.BackColor = Color.LightGray;
                    F_8.Enabled = false;
                    F_8.BackColor = Color.LightGray;
                    F_9.Enabled = false;
                    F_9.BackColor = Color.LightGray;
                    F_10.Enabled = false;
                    F_10.BackColor = Color.LightGray;
                    F_11.Enabled = false;
                    F_11.BackColor = Color.LightGray;
                    F_12.Enabled = false;
                    F_12.BackColor = Color.LightGray;
                    break;
                case (1):
                    F_1.Enabled = true;
                    F_1.BackColor = Color.Red;
                    F_2.Enabled = false;
                    F_2.BackColor = Color.LightGray;
                    F_3.Enabled = false;
                    F_3.BackColor = Color.LightGray;
                    F_4.Enabled = false;
                    F_4.BackColor = Color.LightGray;
                    F_5.Enabled = false;
                    F_5.BackColor = Color.LightGray;
                    F_6.Enabled = false;
                    F_6.BackColor = Color.LightGray;
                    F_7.Enabled = false;
                    F_7.BackColor = Color.LightGray;
                    F_8.Enabled = false;
                    F_8.BackColor = Color.LightGray;
                    F_9.Enabled = false;
                    F_9.BackColor = Color.LightGray;
                    F_10.Enabled = false;
                    F_10.BackColor = Color.LightGray;
                    F_11.Enabled = false;
                    F_11.BackColor = Color.LightGray;
                    F_12.Enabled = false;
                    F_12.BackColor = Color.LightGray;
                    break;
                case (2):
                    F_1.Enabled = true;
                    F_1.BackColor = Color.Red;
                    F_2.Enabled = true;
                    F_2.BackColor = Color.Blue;
                    F_3.Enabled = false;
                    F_3.BackColor = Color.LightGray;
                    F_4.Enabled = false;
                    F_4.BackColor = Color.LightGray;
                    F_5.Enabled = false;
                    F_5.BackColor = Color.LightGray;
                    F_6.Enabled = false;
                    F_6.BackColor = Color.LightGray;
                    F_7.Enabled = false;
                    F_7.BackColor = Color.LightGray;
                    F_8.Enabled = false;
                    F_8.BackColor = Color.LightGray;
                    F_9.Enabled = false;
                    F_9.BackColor = Color.LightGray;
                    F_10.Enabled = false;
                    F_10.BackColor = Color.LightGray;
                    F_11.Enabled = false;
                    F_11.BackColor = Color.LightGray;
                    F_12.Enabled = false;
                    F_12.BackColor = Color.LightGray;
                    break;
                case (3):
                    F_1.Enabled = true;
                    F_1.BackColor = Color.Red;
                    F_2.Enabled = true;
                    F_2.BackColor = Color.Lime;
                    F_3.Enabled = true;
                    F_3.BackColor = Color.Blue;
                    F_4.Enabled = false;
                    F_4.BackColor = Color.LightGray;
                    F_5.Enabled = false;
                    F_5.BackColor = Color.LightGray;
                    F_6.Enabled = false;
                    F_6.BackColor = Color.LightGray;
                    F_7.Enabled = false;
                    F_7.BackColor = Color.LightGray;
                    F_8.Enabled = false;
                    F_8.BackColor = Color.LightGray;
                    F_9.Enabled = false;
                    F_9.BackColor = Color.LightGray;
                    F_10.Enabled = false;
                    F_10.BackColor = Color.LightGray;
                    F_11.Enabled = false;
                    F_11.BackColor = Color.LightGray;
                    F_12.Enabled = false;
                    F_12.BackColor = Color.LightGray;
                    break;
                case (4):
                    F_1.Enabled = true;
                    F_1.BackColor = Color.Red;
                    F_2.Enabled = true;
                    F_2.BackColor = Color.Yellow;
                    F_3.Enabled = true;
                    F_3.BackColor = Color.Lime;
                    F_4.Enabled = true;
                    F_4.BackColor = Color.Blue;
                    F_5.Enabled = false;
                    F_5.BackColor = Color.LightGray;
                    F_6.Enabled = false;
                    F_6.BackColor = Color.LightGray;
                    F_7.Enabled = false;
                    F_7.BackColor = Color.LightGray;
                    F_8.Enabled = false;
                    F_8.BackColor = Color.LightGray;
                    F_9.Enabled = false;
                    F_9.BackColor = Color.LightGray;
                    F_10.Enabled = false;
                    F_10.BackColor = Color.LightGray;
                    F_11.Enabled = false;
                    F_11.BackColor = Color.LightGray;
                    F_12.Enabled = false;
                    F_12.BackColor = Color.LightGray;
                    break;
                case (5):
                    F_1.Enabled = true;
                    F_1.BackColor = Color.Red;
                    F_2.Enabled = true;
                    F_2.BackColor = Color.Yellow;
                    F_3.Enabled = true;
                    F_3.BackColor = Color.Lime;
                    F_4.Enabled = true;
                    F_4.BackColor = Color.Cyan;
                    F_5.Enabled = true;
                    F_5.BackColor = Color.Blue;
                    F_6.Enabled = false;
                    F_6.BackColor = Color.LightGray;
                    F_7.Enabled = false;
                    F_7.BackColor = Color.LightGray;
                    F_8.Enabled = false;
                    F_8.BackColor = Color.LightGray;
                    F_9.Enabled = false;
                    F_9.BackColor = Color.LightGray;
                    F_10.Enabled = false;
                    F_10.BackColor = Color.LightGray;
                    F_11.Enabled = false;
                    F_11.BackColor = Color.LightGray;
                    F_12.Enabled = false;
                    F_12.BackColor = Color.LightGray;
                    break;
                case (6):
                    F_1.Enabled = true;
                    F_1.BackColor = Color.Red;
                    F_2.Enabled = true;
                    F_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_3.Enabled = true;
                    F_3.BackColor = Color.Yellow;
                    F_4.Enabled = true;
                    F_4.BackColor = Color.Lime;
                    F_5.Enabled = true;
                    F_5.BackColor = Color.Cyan;
                    F_6.Enabled = true;
                    F_6.BackColor = Color.Blue;
                    F_7.Enabled = false;
                    F_7.BackColor = Color.LightGray;
                    F_8.Enabled = false;
                    F_8.BackColor = Color.LightGray;
                    F_9.Enabled = false;
                    F_9.BackColor = Color.LightGray;
                    F_10.Enabled = false;
                    F_10.BackColor = Color.LightGray;
                    F_11.Enabled = false;
                    F_11.BackColor = Color.LightGray;
                    F_12.Enabled = false;
                    F_12.BackColor = Color.LightGray;
                    break;
                case (7):
                    F_1.Enabled = true;
                    F_1.BackColor = Color.Red;
                    F_2.Enabled = true;
                    F_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_3.Enabled = true;
                    F_3.BackColor = Color.Yellow;
                    F_4.Enabled = true;
                    F_4.BackColor = Color.Lime;
                    F_5.Enabled = true;
                    F_5.BackColor = Color.Cyan;
                    F_6.Enabled = true;
                    F_6.BackColor = Color.Blue;
                    F_7.Enabled = true;
                    F_7.BackColor = Color.FromArgb(128, 0, 255);
                    F_8.Enabled = false;
                    F_8.BackColor = Color.LightGray;
                    F_9.Enabled = false;
                    F_9.BackColor = Color.LightGray;
                    F_10.Enabled = false;
                    F_10.BackColor = Color.LightGray;
                    F_11.Enabled = false;
                    F_11.BackColor = Color.LightGray;
                    F_12.Enabled = false;
                    F_12.BackColor = Color.LightGray;
                    break;
                case (8):
                    F_1.Enabled = true;
                    F_1.BackColor = Color.Red;
                    F_2.Enabled = true;
                    F_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_3.Enabled = true;
                    F_3.BackColor = Color.Yellow;
                    F_4.Enabled = true;
                    F_4.BackColor = Color.Lime;
                    F_5.Enabled = true;
                    F_5.BackColor = Color.Cyan;
                    F_6.Enabled = true;
                    F_6.BackColor = Color.Blue;
                    F_7.Enabled = true;
                    F_7.BackColor = Color.FromArgb(128, 0, 255);
                    F_8.Enabled = true;
                    F_8.BackColor = Color.Magenta;
                    F_9.Enabled = false;
                    F_9.BackColor = Color.LightGray;
                    F_10.Enabled = false;
                    F_10.BackColor = Color.LightGray;
                    F_11.Enabled = false;
                    F_11.BackColor = Color.LightGray;
                    F_12.Enabled = false;
                    F_12.BackColor = Color.LightGray;
                    break;
                case (9):
                    F_1.Enabled = true;
                    F_1.BackColor = Color.Red;
                    F_2.Enabled = true;
                    F_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_3.Enabled = true;
                    F_3.BackColor = Color.Yellow;
                    F_4.Enabled = true;
                    F_4.BackColor = Color.FromArgb(196, 255, 0);
                    F_5.Enabled = true;
                    F_5.BackColor = Color.Lime;
                    F_6.Enabled = true;
                    F_6.BackColor = Color.Cyan;
                    F_7.Enabled = true;
                    F_7.BackColor = Color.Blue;
                    F_8.Enabled = true;
                    F_8.BackColor = Color.FromArgb(128, 0, 255);
                    F_9.Enabled = true;
                    F_9.BackColor = Color.Magenta;
                    F_10.Enabled = false;
                    F_10.BackColor = Color.LightGray;
                    F_11.Enabled = false;
                    F_11.BackColor = Color.LightGray;
                    F_12.Enabled = false;
                    F_12.BackColor = Color.LightGray;
                    break;
                case (10):
                    F_1.Enabled = true;
                    F_1.BackColor = Color.Red;
                    F_2.Enabled = true;
                    F_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_3.Enabled = true;
                    F_3.BackColor = Color.FromArgb(255, 196, 0);
                    F_4.Enabled = true;
                    F_4.BackColor = Color.Yellow;
                    F_5.Enabled = true;
                    F_5.BackColor = Color.FromArgb(196, 255, 0);
                    F_6.Enabled = true;
                    F_6.BackColor = Color.Lime;
                    F_7.Enabled = true;
                    F_7.BackColor = Color.Cyan;
                    F_8.Enabled = true;
                    F_8.BackColor = Color.Blue;
                    F_9.Enabled = true;
                    F_9.BackColor = Color.FromArgb(128, 0, 255);
                    F_10.Enabled = true;
                    F_10.BackColor = Color.Magenta;
                    F_11.Enabled = false;
                    F_11.BackColor = Color.LightGray;
                    F_12.Enabled = false;
                    F_12.BackColor = Color.LightGray;
                    break;
                case (11):
                    F_1.Enabled = true;
                    F_1.BackColor = Color.Red;
                    F_2.Enabled = true;
                    F_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_3.Enabled = true;
                    F_3.BackColor = Color.FromArgb(255, 196, 0);
                    F_4.Enabled = true;
                    F_4.BackColor = Color.Yellow;
                    F_5.Enabled = true;
                    F_5.BackColor = Color.FromArgb(196, 255, 0);
                    F_6.Enabled = true;
                    F_6.BackColor = Color.Lime;
                    F_7.Enabled = true;
                    F_7.BackColor = Color.FromArgb(0, 255, 196);
                    F_8.Enabled = true;
                    F_8.BackColor = Color.Cyan;
                    F_9.Enabled = true;
                    F_9.BackColor = Color.Blue;
                    F_10.Enabled = true;
                    F_10.BackColor = Color.FromArgb(128, 0, 255);
                    F_11.Enabled = true;
                    F_11.BackColor = Color.Magenta;
                    F_12.Enabled = false;
                    F_12.BackColor = Color.LightGray;
                    break;
                case (12):
                    F_1.Enabled = true;
                    F_1.BackColor = Color.Red;
                    F_2.Enabled = true;
                    F_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_3.Enabled = true;
                    F_3.BackColor = Color.FromArgb(255, 196, 0);
                    F_4.Enabled = true;
                    F_4.BackColor = Color.Yellow;
                    F_5.Enabled = true;
                    F_5.BackColor = Color.FromArgb(196, 255, 0);
                    F_6.Enabled = true;
                    F_6.BackColor = Color.Lime;
                    F_7.Enabled = true;
                    F_7.BackColor = Color.FromArgb(0, 255, 196);
                    F_8.Enabled = true;
                    F_8.BackColor = Color.Cyan;
                    F_9.Enabled = true;
                    F_9.BackColor = Color.Blue;
                    F_10.Enabled = true;
                    F_10.BackColor = Color.FromArgb(128, 0, 255);
                    F_11.Enabled = true;
                    F_11.BackColor = Color.FromArgb(196, 0, 255);
                    F_12.Enabled = true;
                    F_12.BackColor = Color.Magenta;
                    break;
            }
            switch (ncol[6])
            {
                case (0):
                    F_Sharp_1.Enabled = false;
                    F_Sharp_1.BackColor = Color.LightGray;
                    F_Sharp_2.Enabled = false;
                    F_Sharp_2.BackColor = Color.LightGray;
                    F_Sharp_3.Enabled = false;
                    F_Sharp_3.BackColor = Color.LightGray;
                    F_Sharp_4.Enabled = false;
                    F_Sharp_4.BackColor = Color.LightGray;
                    F_Sharp_5.Enabled = false;
                    F_Sharp_5.BackColor = Color.LightGray;
                    F_Sharp_6.Enabled = false;
                    F_Sharp_6.BackColor = Color.LightGray;
                    F_Sharp_7.Enabled = false;
                    F_Sharp_7.BackColor = Color.LightGray;
                    F_Sharp_8.Enabled = false;
                    F_Sharp_8.BackColor = Color.LightGray;
                    F_Sharp_9.Enabled = false;
                    F_Sharp_9.BackColor = Color.LightGray;
                    F_Sharp_10.Enabled = false;
                    F_Sharp_10.BackColor = Color.LightGray;
                    F_Sharp_11.Enabled = false;
                    F_Sharp_11.BackColor = Color.LightGray;
                    F_Sharp_12.Enabled = false;
                    F_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (1):
                    F_Sharp_1.Enabled = true;
                    F_Sharp_1.BackColor = Color.Red;
                    F_Sharp_2.Enabled = false;
                    F_Sharp_2.BackColor = Color.LightGray;
                    F_Sharp_3.Enabled = false;
                    F_Sharp_3.BackColor = Color.LightGray;
                    F_Sharp_4.Enabled = false;
                    F_Sharp_4.BackColor = Color.LightGray;
                    F_Sharp_5.Enabled = false;
                    F_Sharp_5.BackColor = Color.LightGray;
                    F_Sharp_6.Enabled = false;
                    F_Sharp_6.BackColor = Color.LightGray;
                    F_Sharp_7.Enabled = false;
                    F_Sharp_7.BackColor = Color.LightGray;
                    F_Sharp_8.Enabled = false;
                    F_Sharp_8.BackColor = Color.LightGray;
                    F_Sharp_9.Enabled = false;
                    F_Sharp_9.BackColor = Color.LightGray;
                    F_Sharp_10.Enabled = false;
                    F_Sharp_10.BackColor = Color.LightGray;
                    F_Sharp_11.Enabled = false;
                    F_Sharp_11.BackColor = Color.LightGray;
                    F_Sharp_12.Enabled = false;
                    F_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (2):
                    F_Sharp_1.Enabled = true;
                    F_Sharp_1.BackColor = Color.Red;
                    F_Sharp_2.Enabled = true;
                    F_Sharp_2.BackColor = Color.Blue;
                    F_Sharp_3.Enabled = false;
                    F_Sharp_3.BackColor = Color.LightGray;
                    F_Sharp_4.Enabled = false;
                    F_Sharp_4.BackColor = Color.LightGray;
                    F_Sharp_5.Enabled = false;
                    F_Sharp_5.BackColor = Color.LightGray;
                    F_Sharp_6.Enabled = false;
                    F_Sharp_6.BackColor = Color.LightGray;
                    F_Sharp_7.Enabled = false;
                    F_Sharp_7.BackColor = Color.LightGray;
                    F_Sharp_8.Enabled = false;
                    F_Sharp_8.BackColor = Color.LightGray;
                    F_Sharp_9.Enabled = false;
                    F_Sharp_9.BackColor = Color.LightGray;
                    F_Sharp_10.Enabled = false;
                    F_Sharp_10.BackColor = Color.LightGray;
                    F_Sharp_11.Enabled = false;
                    F_Sharp_11.BackColor = Color.LightGray;
                    F_Sharp_12.Enabled = false;
                    F_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (3):
                    F_Sharp_1.Enabled = true;
                    F_Sharp_1.BackColor = Color.Red;
                    F_Sharp_2.Enabled = true;
                    F_Sharp_2.BackColor = Color.Lime;
                    F_Sharp_3.Enabled = true;
                    F_Sharp_3.BackColor = Color.Blue;
                    F_Sharp_4.Enabled = false;
                    F_Sharp_4.BackColor = Color.LightGray;
                    F_Sharp_5.Enabled = false;
                    F_Sharp_5.BackColor = Color.LightGray;
                    F_Sharp_6.Enabled = false;
                    F_Sharp_6.BackColor = Color.LightGray;
                    F_Sharp_7.Enabled = false;
                    F_Sharp_7.BackColor = Color.LightGray;
                    F_Sharp_8.Enabled = false;
                    F_Sharp_8.BackColor = Color.LightGray;
                    F_Sharp_9.Enabled = false;
                    F_Sharp_9.BackColor = Color.LightGray;
                    F_Sharp_10.Enabled = false;
                    F_Sharp_10.BackColor = Color.LightGray;
                    F_Sharp_11.Enabled = false;
                    F_Sharp_11.BackColor = Color.LightGray;
                    F_Sharp_12.Enabled = false;
                    F_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (4):
                    F_Sharp_1.Enabled = true;
                    F_Sharp_1.BackColor = Color.Red;
                    F_Sharp_2.Enabled = true;
                    F_Sharp_2.BackColor = Color.Yellow;
                    F_Sharp_3.Enabled = true;
                    F_Sharp_3.BackColor = Color.Lime;
                    F_Sharp_4.Enabled = true;
                    F_Sharp_4.BackColor = Color.Blue;
                    F_Sharp_5.Enabled = false;
                    F_Sharp_5.BackColor = Color.LightGray;
                    F_Sharp_6.Enabled = false;
                    F_Sharp_6.BackColor = Color.LightGray;
                    F_Sharp_7.Enabled = false;
                    F_Sharp_7.BackColor = Color.LightGray;
                    F_Sharp_8.Enabled = false;
                    F_Sharp_8.BackColor = Color.LightGray;
                    F_Sharp_9.Enabled = false;
                    F_Sharp_9.BackColor = Color.LightGray;
                    F_Sharp_10.Enabled = false;
                    F_Sharp_10.BackColor = Color.LightGray;
                    F_Sharp_11.Enabled = false;
                    F_Sharp_11.BackColor = Color.LightGray;
                    F_Sharp_12.Enabled = false;
                    F_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (5):
                    F_Sharp_1.Enabled = true;
                    F_Sharp_1.BackColor = Color.Red;
                    F_Sharp_2.Enabled = true;
                    F_Sharp_2.BackColor = Color.Yellow;
                    F_Sharp_3.Enabled = true;
                    F_Sharp_3.BackColor = Color.Lime;
                    F_Sharp_4.Enabled = true;
                    F_Sharp_4.BackColor = Color.Cyan;
                    F_Sharp_5.Enabled = true;
                    F_Sharp_5.BackColor = Color.Blue;
                    F_Sharp_6.Enabled = false;
                    F_Sharp_6.BackColor = Color.LightGray;
                    F_Sharp_7.Enabled = false;
                    F_Sharp_7.BackColor = Color.LightGray;
                    F_Sharp_8.Enabled = false;
                    F_Sharp_8.BackColor = Color.LightGray;
                    F_Sharp_9.Enabled = false;
                    F_Sharp_9.BackColor = Color.LightGray;
                    F_Sharp_10.Enabled = false;
                    F_Sharp_10.BackColor = Color.LightGray;
                    F_Sharp_11.Enabled = false;
                    F_Sharp_11.BackColor = Color.LightGray;
                    F_Sharp_12.Enabled = false;
                    F_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (6):
                    F_Sharp_1.Enabled = true;
                    F_Sharp_1.BackColor = Color.Red;
                    F_Sharp_2.Enabled = true;
                    F_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_Sharp_3.Enabled = true;
                    F_Sharp_3.BackColor = Color.Yellow;
                    F_Sharp_4.Enabled = true;
                    F_Sharp_4.BackColor = Color.Lime;
                    F_Sharp_5.Enabled = true;
                    F_Sharp_5.BackColor = Color.Cyan;
                    F_Sharp_6.Enabled = true;
                    F_Sharp_6.BackColor = Color.Blue;
                    F_Sharp_7.Enabled = false;
                    F_Sharp_7.BackColor = Color.LightGray;
                    F_Sharp_8.Enabled = false;
                    F_Sharp_8.BackColor = Color.LightGray;
                    F_Sharp_9.Enabled = false;
                    F_Sharp_9.BackColor = Color.LightGray;
                    F_Sharp_10.Enabled = false;
                    F_Sharp_10.BackColor = Color.LightGray;
                    F_Sharp_11.Enabled = false;
                    F_Sharp_11.BackColor = Color.LightGray;
                    F_Sharp_12.Enabled = false;
                    F_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (7):
                    F_Sharp_1.Enabled = true;
                    F_Sharp_1.BackColor = Color.Red;
                    F_Sharp_2.Enabled = true;
                    F_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_Sharp_3.Enabled = true;
                    F_Sharp_3.BackColor = Color.Yellow;
                    F_Sharp_4.Enabled = true;
                    F_Sharp_4.BackColor = Color.Lime;
                    F_Sharp_5.Enabled = true;
                    F_Sharp_5.BackColor = Color.Cyan;
                    F_Sharp_6.Enabled = true;
                    F_Sharp_6.BackColor = Color.Blue;
                    F_Sharp_7.Enabled = true;
                    F_Sharp_7.BackColor = Color.FromArgb(128, 0, 255);
                    F_Sharp_8.Enabled = false;
                    F_Sharp_8.BackColor = Color.LightGray;
                    F_Sharp_9.Enabled = false;
                    F_Sharp_9.BackColor = Color.LightGray;
                    F_Sharp_10.Enabled = false;
                    F_Sharp_10.BackColor = Color.LightGray;
                    F_Sharp_11.Enabled = false;
                    F_Sharp_11.BackColor = Color.LightGray;
                    F_Sharp_12.Enabled = false;
                    F_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (8):
                    F_Sharp_1.Enabled = true;
                    F_Sharp_1.BackColor = Color.Red;
                    F_Sharp_2.Enabled = true;
                    F_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_Sharp_3.Enabled = true;
                    F_Sharp_3.BackColor = Color.Yellow;
                    F_Sharp_4.Enabled = true;
                    F_Sharp_4.BackColor = Color.Lime;
                    F_Sharp_5.Enabled = true;
                    F_Sharp_5.BackColor = Color.Cyan;
                    F_Sharp_6.Enabled = true;
                    F_Sharp_6.BackColor = Color.Blue;
                    F_Sharp_7.Enabled = true;
                    F_Sharp_7.BackColor = Color.FromArgb(128, 0, 255);
                    F_Sharp_8.Enabled = true;
                    F_Sharp_8.BackColor = Color.Magenta;
                    F_Sharp_9.Enabled = false;
                    F_Sharp_9.BackColor = Color.LightGray;
                    F_Sharp_10.Enabled = false;
                    F_Sharp_10.BackColor = Color.LightGray;
                    F_Sharp_11.Enabled = false;
                    F_Sharp_11.BackColor = Color.LightGray;
                    F_Sharp_12.Enabled = false;
                    F_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (9):
                    F_Sharp_1.Enabled = true;
                    F_Sharp_1.BackColor = Color.Red;
                    F_Sharp_2.Enabled = true;
                    F_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_Sharp_3.Enabled = true;
                    F_Sharp_3.BackColor = Color.Yellow;
                    F_Sharp_4.Enabled = true;
                    F_Sharp_4.BackColor = Color.FromArgb(196, 255, 0);
                    F_Sharp_5.Enabled = true;
                    F_Sharp_5.BackColor = Color.Lime;
                    F_Sharp_6.Enabled = true;
                    F_Sharp_6.BackColor = Color.Cyan;
                    F_Sharp_7.Enabled = true;
                    F_Sharp_7.BackColor = Color.Blue;
                    F_Sharp_8.Enabled = true;
                    F_Sharp_8.BackColor = Color.FromArgb(128, 0, 255);
                    F_Sharp_9.Enabled = true;
                    F_Sharp_9.BackColor = Color.Magenta;
                    F_Sharp_10.Enabled = false;
                    F_Sharp_10.BackColor = Color.LightGray;
                    F_Sharp_11.Enabled = false;
                    F_Sharp_11.BackColor = Color.LightGray;
                    F_Sharp_12.Enabled = false;
                    F_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (10):
                    F_Sharp_1.Enabled = true;
                    F_Sharp_1.BackColor = Color.Red;
                    F_Sharp_2.Enabled = true;
                    F_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_Sharp_3.Enabled = true;
                    F_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    F_Sharp_4.Enabled = true;
                    F_Sharp_4.BackColor = Color.Yellow;
                    F_Sharp_5.Enabled = true;
                    F_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    F_Sharp_6.Enabled = true;
                    F_Sharp_6.BackColor = Color.Lime;
                    F_Sharp_7.Enabled = true;
                    F_Sharp_7.BackColor = Color.Cyan;
                    F_Sharp_8.Enabled = true;
                    F_Sharp_8.BackColor = Color.Blue;
                    F_Sharp_9.Enabled = true;
                    F_Sharp_9.BackColor = Color.FromArgb(128, 0, 255);
                    F_Sharp_10.Enabled = true;
                    F_Sharp_10.BackColor = Color.Magenta;
                    F_Sharp_11.Enabled = false;
                    F_Sharp_11.BackColor = Color.LightGray;
                    F_Sharp_12.Enabled = false;
                    F_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (11):
                    F_Sharp_1.Enabled = true;
                    F_Sharp_1.BackColor = Color.Red;
                    F_Sharp_2.Enabled = true;
                    F_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_Sharp_3.Enabled = true;
                    F_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    F_Sharp_4.Enabled = true;
                    F_Sharp_4.BackColor = Color.Yellow;
                    F_Sharp_5.Enabled = true;
                    F_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    F_Sharp_6.Enabled = true;
                    F_Sharp_6.BackColor = Color.Lime;
                    F_Sharp_7.Enabled = true;
                    F_Sharp_7.BackColor = Color.FromArgb(0, 255, 196);
                    F_Sharp_8.Enabled = true;
                    F_Sharp_8.BackColor = Color.Cyan;
                    F_Sharp_9.Enabled = true;
                    F_Sharp_9.BackColor = Color.Blue;
                    F_Sharp_10.Enabled = true;
                    F_Sharp_10.BackColor = Color.FromArgb(128, 0, 255);
                    F_Sharp_11.Enabled = true;
                    F_Sharp_11.BackColor = Color.Magenta;
                    F_Sharp_12.Enabled = false;
                    F_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (12):
                    F_Sharp_1.Enabled = true;
                    F_Sharp_1.BackColor = Color.Red;
                    F_Sharp_2.Enabled = true;
                    F_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    F_Sharp_3.Enabled = true;
                    F_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    F_Sharp_4.Enabled = true;
                    F_Sharp_4.BackColor = Color.Yellow;
                    F_Sharp_5.Enabled = true;
                    F_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    F_Sharp_6.Enabled = true;
                    F_Sharp_6.BackColor = Color.Lime;
                    F_Sharp_7.Enabled = true;
                    F_Sharp_7.BackColor = Color.FromArgb(0, 255, 196);
                    F_Sharp_8.Enabled = true;
                    F_Sharp_8.BackColor = Color.Cyan;
                    F_Sharp_9.Enabled = true;
                    F_Sharp_9.BackColor = Color.Blue;
                    F_Sharp_10.Enabled = true;
                    F_Sharp_10.BackColor = Color.FromArgb(128, 0, 255);
                    F_Sharp_11.Enabled = true;
                    F_Sharp_11.BackColor = Color.FromArgb(196, 0, 255);
                    F_Sharp_12.Enabled = true;
                    F_Sharp_12.BackColor = Color.Magenta;
                    break;
            }
            switch (ncol[7])
            {
                case (0):
                    G_1.Enabled = false;
                    G_1.BackColor = Color.LightGray;
                    G_2.Enabled = false;
                    G_2.BackColor = Color.LightGray;
                    G_3.Enabled = false;
                    G_3.BackColor = Color.LightGray;
                    G_4.Enabled = false;
                    G_4.BackColor = Color.LightGray;
                    G_5.Enabled = false;
                    G_5.BackColor = Color.LightGray;
                    G_6.Enabled = false;
                    G_6.BackColor = Color.LightGray;
                    G_7.Enabled = false;
                    G_7.BackColor = Color.LightGray;
                    G_8.Enabled = false;
                    G_8.BackColor = Color.LightGray;
                    G_9.Enabled = false;
                    G_9.BackColor = Color.LightGray;
                    G_10.Enabled = false;
                    G_10.BackColor = Color.LightGray;
                    G_11.Enabled = false;
                    G_11.BackColor = Color.LightGray;
                    G_12.Enabled = false;
                    G_12.BackColor = Color.LightGray;
                    break;
                case (1):
                    G_1.Enabled = true;
                    G_1.BackColor = Color.Red;
                    G_2.Enabled = false;
                    G_2.BackColor = Color.LightGray;
                    G_3.Enabled = false;
                    G_3.BackColor = Color.LightGray;
                    G_4.Enabled = false;
                    G_4.BackColor = Color.LightGray;
                    G_5.Enabled = false;
                    G_5.BackColor = Color.LightGray;
                    G_6.Enabled = false;
                    G_6.BackColor = Color.LightGray;
                    G_7.Enabled = false;
                    G_7.BackColor = Color.LightGray;
                    G_8.Enabled = false;
                    G_8.BackColor = Color.LightGray;
                    G_9.Enabled = false;
                    G_9.BackColor = Color.LightGray;
                    G_10.Enabled = false;
                    G_10.BackColor = Color.LightGray;
                    G_11.Enabled = false;
                    G_11.BackColor = Color.LightGray;
                    G_12.Enabled = false;
                    G_12.BackColor = Color.LightGray;
                    break;
                case (2):
                    G_1.Enabled = true;
                    G_1.BackColor = Color.Red;
                    G_2.Enabled = true;
                    G_2.BackColor = Color.Blue;
                    G_3.Enabled = false;
                    G_3.BackColor = Color.LightGray;
                    G_4.Enabled = false;
                    G_4.BackColor = Color.LightGray;
                    G_5.Enabled = false;
                    G_5.BackColor = Color.LightGray;
                    G_6.Enabled = false;
                    G_6.BackColor = Color.LightGray;
                    G_7.Enabled = false;
                    G_7.BackColor = Color.LightGray;
                    G_8.Enabled = false;
                    G_8.BackColor = Color.LightGray;
                    G_9.Enabled = false;
                    G_9.BackColor = Color.LightGray;
                    G_10.Enabled = false;
                    G_10.BackColor = Color.LightGray;
                    G_11.Enabled = false;
                    G_11.BackColor = Color.LightGray;
                    G_12.Enabled = false;
                    G_12.BackColor = Color.LightGray;
                    break;
                case (3):
                    G_1.Enabled = true;
                    G_1.BackColor = Color.Red;
                    G_2.Enabled = true;
                    G_2.BackColor = Color.Lime;
                    G_3.Enabled = true;
                    G_3.BackColor = Color.Blue;
                    G_4.Enabled = false;
                    G_4.BackColor = Color.LightGray;
                    G_5.Enabled = false;
                    G_5.BackColor = Color.LightGray;
                    G_6.Enabled = false;
                    G_6.BackColor = Color.LightGray;
                    G_7.Enabled = false;
                    G_7.BackColor = Color.LightGray;
                    G_8.Enabled = false;
                    G_8.BackColor = Color.LightGray;
                    G_9.Enabled = false;
                    G_9.BackColor = Color.LightGray;
                    G_10.Enabled = false;
                    G_10.BackColor = Color.LightGray;
                    G_11.Enabled = false;
                    G_11.BackColor = Color.LightGray;
                    G_12.Enabled = false;
                    G_12.BackColor = Color.LightGray;
                    break;
                case (4):
                    G_1.Enabled = true;
                    G_1.BackColor = Color.Red;
                    G_2.Enabled = true;
                    G_2.BackColor = Color.Yellow;
                    G_3.Enabled = true;
                    G_3.BackColor = Color.Lime;
                    G_4.Enabled = true;
                    G_4.BackColor = Color.Blue;
                    G_5.Enabled = false;
                    G_5.BackColor = Color.LightGray;
                    G_6.Enabled = false;
                    G_6.BackColor = Color.LightGray;
                    G_7.Enabled = false;
                    G_7.BackColor = Color.LightGray;
                    G_8.Enabled = false;
                    G_8.BackColor = Color.LightGray;
                    G_9.Enabled = false;
                    G_9.BackColor = Color.LightGray;
                    G_10.Enabled = false;
                    G_10.BackColor = Color.LightGray;
                    G_11.Enabled = false;
                    G_11.BackColor = Color.LightGray;
                    G_12.Enabled = false;
                    G_12.BackColor = Color.LightGray;
                    break;
                case (5):
                    G_1.Enabled = true;
                    G_1.BackColor = Color.Red;
                    G_2.Enabled = true;
                    G_2.BackColor = Color.Yellow;
                    G_3.Enabled = true;
                    G_3.BackColor = Color.Lime;
                    G_4.Enabled = true;
                    G_4.BackColor = Color.Cyan;
                    G_5.Enabled = true;
                    G_5.BackColor = Color.Blue;
                    G_6.Enabled = false;
                    G_6.BackColor = Color.LightGray;
                    G_7.Enabled = false;
                    G_7.BackColor = Color.LightGray;
                    G_8.Enabled = false;
                    G_8.BackColor = Color.LightGray;
                    G_9.Enabled = false;
                    G_9.BackColor = Color.LightGray;
                    G_10.Enabled = false;
                    G_10.BackColor = Color.LightGray;
                    G_11.Enabled = false;
                    G_11.BackColor = Color.LightGray;
                    G_12.Enabled = false;
                    G_12.BackColor = Color.LightGray;
                    break;
                case (6):
                    G_1.Enabled = true;
                    G_1.BackColor = Color.Red;
                    G_2.Enabled = true;
                    G_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_3.Enabled = true;
                    G_3.BackColor = Color.Yellow;
                    G_4.Enabled = true;
                    G_4.BackColor = Color.Lime;
                    G_5.Enabled = true;
                    G_5.BackColor = Color.Cyan;
                    G_6.Enabled = true;
                    G_6.BackColor = Color.Blue;
                    G_7.Enabled = false;
                    G_7.BackColor = Color.LightGray;
                    G_8.Enabled = false;
                    G_8.BackColor = Color.LightGray;
                    G_9.Enabled = false;
                    G_9.BackColor = Color.LightGray;
                    G_10.Enabled = false;
                    G_10.BackColor = Color.LightGray;
                    G_11.Enabled = false;
                    G_11.BackColor = Color.LightGray;
                    G_12.Enabled = false;
                    G_12.BackColor = Color.LightGray;
                    break;
                case (7):
                    G_1.Enabled = true;
                    G_1.BackColor = Color.Red;
                    G_2.Enabled = true;
                    G_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_3.Enabled = true;
                    G_3.BackColor = Color.Yellow;
                    G_4.Enabled = true;
                    G_4.BackColor = Color.Lime;
                    G_5.Enabled = true;
                    G_5.BackColor = Color.Cyan;
                    G_6.Enabled = true;
                    G_6.BackColor = Color.Blue;
                    G_7.Enabled = true;
                    G_7.BackColor = Color.FromArgb(128, 0, 255);
                    G_8.Enabled = false;
                    G_8.BackColor = Color.LightGray;
                    G_9.Enabled = false;
                    G_9.BackColor = Color.LightGray;
                    G_10.Enabled = false;
                    G_10.BackColor = Color.LightGray;
                    G_11.Enabled = false;
                    G_11.BackColor = Color.LightGray;
                    G_12.Enabled = false;
                    G_12.BackColor = Color.LightGray;
                    break;
                case (8):
                    G_1.Enabled = true;
                    G_1.BackColor = Color.Red;
                    G_2.Enabled = true;
                    G_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_3.Enabled = true;
                    G_3.BackColor = Color.Yellow;
                    G_4.Enabled = true;
                    G_4.BackColor = Color.Lime;
                    G_5.Enabled = true;
                    G_5.BackColor = Color.Cyan;
                    G_6.Enabled = true;
                    G_6.BackColor = Color.Blue;
                    G_7.Enabled = true;
                    G_7.BackColor = Color.FromArgb(128, 0, 255);
                    G_8.Enabled = true;
                    G_8.BackColor = Color.Magenta;
                    G_9.Enabled = false;
                    G_9.BackColor = Color.LightGray;
                    G_10.Enabled = false;
                    G_10.BackColor = Color.LightGray;
                    G_11.Enabled = false;
                    G_11.BackColor = Color.LightGray;
                    G_12.Enabled = false;
                    G_12.BackColor = Color.LightGray;
                    break;
                case (9):
                    G_1.Enabled = true;
                    G_1.BackColor = Color.Red;
                    G_2.Enabled = true;
                    G_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_3.Enabled = true;
                    G_3.BackColor = Color.Yellow;
                    G_4.Enabled = true;
                    G_4.BackColor = Color.FromArgb(196, 255, 0);
                    G_5.Enabled = true;
                    G_5.BackColor = Color.Lime;
                    G_6.Enabled = true;
                    G_6.BackColor = Color.Cyan;
                    G_7.Enabled = true;
                    G_7.BackColor = Color.Blue;
                    G_8.Enabled = true;
                    G_8.BackColor = Color.FromArgb(128, 0, 255);
                    G_9.Enabled = true;
                    G_9.BackColor = Color.Magenta;
                    G_10.Enabled = false;
                    G_10.BackColor = Color.LightGray;
                    G_11.Enabled = false;
                    G_11.BackColor = Color.LightGray;
                    G_12.Enabled = false;
                    G_12.BackColor = Color.LightGray;
                    break;
                case (10):
                    G_1.Enabled = true;
                    G_1.BackColor = Color.Red;
                    G_2.Enabled = true;
                    G_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_3.Enabled = true;
                    G_3.BackColor = Color.FromArgb(255, 196, 0);
                    G_4.Enabled = true;
                    G_4.BackColor = Color.Yellow;
                    G_5.Enabled = true;
                    G_5.BackColor = Color.FromArgb(196, 255, 0);
                    G_6.Enabled = true;
                    G_6.BackColor = Color.Lime;
                    G_7.Enabled = true;
                    G_7.BackColor = Color.Cyan;
                    G_8.Enabled = true;
                    G_8.BackColor = Color.Blue;
                    G_9.Enabled = true;
                    G_9.BackColor = Color.FromArgb(128, 0, 255);
                    G_10.Enabled = true;
                    G_10.BackColor = Color.Magenta;
                    G_11.Enabled = false;
                    G_11.BackColor = Color.LightGray;
                    G_12.Enabled = false;
                    G_12.BackColor = Color.LightGray;
                    break;
                case (11):
                    G_1.Enabled = true;
                    G_1.BackColor = Color.Red;
                    G_2.Enabled = true;
                    G_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_3.Enabled = true;
                    G_3.BackColor = Color.FromArgb(255, 196, 0);
                    G_4.Enabled = true;
                    G_4.BackColor = Color.Yellow;
                    G_5.Enabled = true;
                    G_5.BackColor = Color.FromArgb(196, 255, 0);
                    G_6.Enabled = true;
                    G_6.BackColor = Color.Lime;
                    G_7.Enabled = true;
                    G_7.BackColor = Color.FromArgb(0, 255, 196);
                    G_8.Enabled = true;
                    G_8.BackColor = Color.Cyan;
                    G_9.Enabled = true;
                    G_9.BackColor = Color.Blue;
                    G_10.Enabled = true;
                    G_10.BackColor = Color.FromArgb(128, 0, 255);
                    G_11.Enabled = true;
                    G_11.BackColor = Color.Magenta;
                    G_12.Enabled = false;
                    G_12.BackColor = Color.LightGray;
                    break;
                case (12):
                    G_1.Enabled = true;
                    G_1.BackColor = Color.Red;
                    G_2.Enabled = true;
                    G_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_3.Enabled = true;
                    G_3.BackColor = Color.FromArgb(255, 196, 0);
                    G_4.Enabled = true;
                    G_4.BackColor = Color.Yellow;
                    G_5.Enabled = true;
                    G_5.BackColor = Color.FromArgb(196, 255, 0);
                    G_6.Enabled = true;
                    G_6.BackColor = Color.Lime;
                    G_7.Enabled = true;
                    G_7.BackColor = Color.FromArgb(0, 255, 196);
                    G_8.Enabled = true;
                    G_8.BackColor = Color.Cyan;
                    G_9.Enabled = true;
                    G_9.BackColor = Color.Blue;
                    G_10.Enabled = true;
                    G_10.BackColor = Color.FromArgb(128, 0, 255);
                    G_11.Enabled = true;
                    G_11.BackColor = Color.FromArgb(196, 0, 255);
                    G_12.Enabled = true;
                    G_12.BackColor = Color.Magenta;
                    break;
            }
            switch (ncol[8])
            {
                case (0):
                    G_Sharp_1.Enabled = false;
                    G_Sharp_1.BackColor = Color.LightGray;
                    G_Sharp_2.Enabled = false;
                    G_Sharp_2.BackColor = Color.LightGray;
                    G_Sharp_3.Enabled = false;
                    G_Sharp_3.BackColor = Color.LightGray;
                    G_Sharp_4.Enabled = false;
                    G_Sharp_4.BackColor = Color.LightGray;
                    G_Sharp_5.Enabled = false;
                    G_Sharp_5.BackColor = Color.LightGray;
                    G_Sharp_6.Enabled = false;
                    G_Sharp_6.BackColor = Color.LightGray;
                    G_Sharp_7.Enabled = false;
                    G_Sharp_7.BackColor = Color.LightGray;
                    G_Sharp_8.Enabled = false;
                    G_Sharp_8.BackColor = Color.LightGray;
                    G_Sharp_9.Enabled = false;
                    G_Sharp_9.BackColor = Color.LightGray;
                    G_Sharp_10.Enabled = false;
                    G_Sharp_10.BackColor = Color.LightGray;
                    G_Sharp_11.Enabled = false;
                    G_Sharp_11.BackColor = Color.LightGray;
                    G_Sharp_12.Enabled = false;
                    G_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (1):
                    G_Sharp_1.Enabled = true;
                    G_Sharp_1.BackColor = Color.Red;
                    G_Sharp_2.Enabled = false;
                    G_Sharp_2.BackColor = Color.LightGray;
                    G_Sharp_3.Enabled = false;
                    G_Sharp_3.BackColor = Color.LightGray;
                    G_Sharp_4.Enabled = false;
                    G_Sharp_4.BackColor = Color.LightGray;
                    G_Sharp_5.Enabled = false;
                    G_Sharp_5.BackColor = Color.LightGray;
                    G_Sharp_6.Enabled = false;
                    G_Sharp_6.BackColor = Color.LightGray;
                    G_Sharp_7.Enabled = false;
                    G_Sharp_7.BackColor = Color.LightGray;
                    G_Sharp_8.Enabled = false;
                    G_Sharp_8.BackColor = Color.LightGray;
                    G_Sharp_9.Enabled = false;
                    G_Sharp_9.BackColor = Color.LightGray;
                    G_Sharp_10.Enabled = false;
                    G_Sharp_10.BackColor = Color.LightGray;
                    G_Sharp_11.Enabled = false;
                    G_Sharp_11.BackColor = Color.LightGray;
                    G_Sharp_12.Enabled = false;
                    G_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (2):
                    G_Sharp_1.Enabled = true;
                    G_Sharp_1.BackColor = Color.Red;
                    G_Sharp_2.Enabled = true;
                    G_Sharp_2.BackColor = Color.Blue;
                    G_Sharp_3.Enabled = false;
                    G_Sharp_3.BackColor = Color.LightGray;
                    G_Sharp_4.Enabled = false;
                    G_Sharp_4.BackColor = Color.LightGray;
                    G_Sharp_5.Enabled = false;
                    G_Sharp_5.BackColor = Color.LightGray;
                    G_Sharp_6.Enabled = false;
                    G_Sharp_6.BackColor = Color.LightGray;
                    G_Sharp_7.Enabled = false;
                    G_Sharp_7.BackColor = Color.LightGray;
                    G_Sharp_8.Enabled = false;
                    G_Sharp_8.BackColor = Color.LightGray;
                    G_Sharp_9.Enabled = false;
                    G_Sharp_9.BackColor = Color.LightGray;
                    G_Sharp_10.Enabled = false;
                    G_Sharp_10.BackColor = Color.LightGray;
                    G_Sharp_11.Enabled = false;
                    G_Sharp_11.BackColor = Color.LightGray;
                    G_Sharp_12.Enabled = false;
                    G_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (3):
                    G_Sharp_1.Enabled = true;
                    G_Sharp_1.BackColor = Color.Red;
                    G_Sharp_2.Enabled = true;
                    G_Sharp_2.BackColor = Color.Lime;
                    G_Sharp_3.Enabled = true;
                    G_Sharp_3.BackColor = Color.Blue;
                    G_Sharp_4.Enabled = false;
                    G_Sharp_4.BackColor = Color.LightGray;
                    G_Sharp_5.Enabled = false;
                    G_Sharp_5.BackColor = Color.LightGray;
                    G_Sharp_6.Enabled = false;
                    G_Sharp_6.BackColor = Color.LightGray;
                    G_Sharp_7.Enabled = false;
                    G_Sharp_7.BackColor = Color.LightGray;
                    G_Sharp_8.Enabled = false;
                    G_Sharp_8.BackColor = Color.LightGray;
                    G_Sharp_9.Enabled = false;
                    G_Sharp_9.BackColor = Color.LightGray;
                    G_Sharp_10.Enabled = false;
                    G_Sharp_10.BackColor = Color.LightGray;
                    G_Sharp_11.Enabled = false;
                    G_Sharp_11.BackColor = Color.LightGray;
                    G_Sharp_12.Enabled = false;
                    G_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (4):
                    G_Sharp_1.Enabled = true;
                    G_Sharp_1.BackColor = Color.Red;
                    G_Sharp_2.Enabled = true;
                    G_Sharp_2.BackColor = Color.Yellow;
                    G_Sharp_3.Enabled = true;
                    G_Sharp_3.BackColor = Color.Lime;
                    G_Sharp_4.Enabled = true;
                    G_Sharp_4.BackColor = Color.Blue;
                    G_Sharp_5.Enabled = false;
                    G_Sharp_5.BackColor = Color.LightGray;
                    G_Sharp_6.Enabled = false;
                    G_Sharp_6.BackColor = Color.LightGray;
                    G_Sharp_7.Enabled = false;
                    G_Sharp_7.BackColor = Color.LightGray;
                    G_Sharp_8.Enabled = false;
                    G_Sharp_8.BackColor = Color.LightGray;
                    G_Sharp_9.Enabled = false;
                    G_Sharp_9.BackColor = Color.LightGray;
                    G_Sharp_10.Enabled = false;
                    G_Sharp_10.BackColor = Color.LightGray;
                    G_Sharp_11.Enabled = false;
                    G_Sharp_11.BackColor = Color.LightGray;
                    G_Sharp_12.Enabled = false;
                    G_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (5):
                    G_Sharp_1.Enabled = true;
                    G_Sharp_1.BackColor = Color.Red;
                    G_Sharp_2.Enabled = true;
                    G_Sharp_2.BackColor = Color.Yellow;
                    G_Sharp_3.Enabled = true;
                    G_Sharp_3.BackColor = Color.Lime;
                    G_Sharp_4.Enabled = true;
                    G_Sharp_4.BackColor = Color.Cyan;
                    G_Sharp_5.Enabled = true;
                    G_Sharp_5.BackColor = Color.Blue;
                    G_Sharp_6.Enabled = false;
                    G_Sharp_6.BackColor = Color.LightGray;
                    G_Sharp_7.Enabled = false;
                    G_Sharp_7.BackColor = Color.LightGray;
                    G_Sharp_8.Enabled = false;
                    G_Sharp_8.BackColor = Color.LightGray;
                    G_Sharp_9.Enabled = false;
                    G_Sharp_9.BackColor = Color.LightGray;
                    G_Sharp_10.Enabled = false;
                    G_Sharp_10.BackColor = Color.LightGray;
                    G_Sharp_11.Enabled = false;
                    G_Sharp_11.BackColor = Color.LightGray;
                    G_Sharp_12.Enabled = false;
                    G_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (6):
                    G_Sharp_1.Enabled = true;
                    G_Sharp_1.BackColor = Color.Red;
                    G_Sharp_2.Enabled = true;
                    G_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_Sharp_3.Enabled = true;
                    G_Sharp_3.BackColor = Color.Yellow;
                    G_Sharp_4.Enabled = true;
                    G_Sharp_4.BackColor = Color.Lime;
                    G_Sharp_5.Enabled = true;
                    G_Sharp_5.BackColor = Color.Cyan;
                    G_Sharp_6.Enabled = true;
                    G_Sharp_6.BackColor = Color.Blue;
                    G_Sharp_7.Enabled = false;
                    G_Sharp_7.BackColor = Color.LightGray;
                    G_Sharp_8.Enabled = false;
                    G_Sharp_8.BackColor = Color.LightGray;
                    G_Sharp_9.Enabled = false;
                    G_Sharp_9.BackColor = Color.LightGray;
                    G_Sharp_10.Enabled = false;
                    G_Sharp_10.BackColor = Color.LightGray;
                    G_Sharp_11.Enabled = false;
                    G_Sharp_11.BackColor = Color.LightGray;
                    G_Sharp_12.Enabled = false;
                    G_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (7):
                    G_Sharp_1.Enabled = true;
                    G_Sharp_1.BackColor = Color.Red;
                    G_Sharp_2.Enabled = true;
                    G_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_Sharp_3.Enabled = true;
                    G_Sharp_3.BackColor = Color.Yellow;
                    G_Sharp_4.Enabled = true;
                    G_Sharp_4.BackColor = Color.Lime;
                    G_Sharp_5.Enabled = true;
                    G_Sharp_5.BackColor = Color.Cyan;
                    G_Sharp_6.Enabled = true;
                    G_Sharp_6.BackColor = Color.Blue;
                    G_Sharp_7.Enabled = true;
                    G_Sharp_7.BackColor = Color.FromArgb(128, 0, 255);
                    G_Sharp_8.Enabled = false;
                    G_Sharp_8.BackColor = Color.LightGray;
                    G_Sharp_9.Enabled = false;
                    G_Sharp_9.BackColor = Color.LightGray;
                    G_Sharp_10.Enabled = false;
                    G_Sharp_10.BackColor = Color.LightGray;
                    G_Sharp_11.Enabled = false;
                    G_Sharp_11.BackColor = Color.LightGray;
                    G_Sharp_12.Enabled = false;
                    G_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (8):
                    G_Sharp_1.Enabled = true;
                    G_Sharp_1.BackColor = Color.Red;
                    G_Sharp_2.Enabled = true;
                    G_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_Sharp_3.Enabled = true;
                    G_Sharp_3.BackColor = Color.Yellow;
                    G_Sharp_4.Enabled = true;
                    G_Sharp_4.BackColor = Color.Lime;
                    G_Sharp_5.Enabled = true;
                    G_Sharp_5.BackColor = Color.Cyan;
                    G_Sharp_6.Enabled = true;
                    G_Sharp_6.BackColor = Color.Blue;
                    G_Sharp_7.Enabled = true;
                    G_Sharp_7.BackColor = Color.FromArgb(128, 0, 255);
                    G_Sharp_8.Enabled = true;
                    G_Sharp_8.BackColor = Color.Magenta;
                    G_Sharp_9.Enabled = false;
                    G_Sharp_9.BackColor = Color.LightGray;
                    G_Sharp_10.Enabled = false;
                    G_Sharp_10.BackColor = Color.LightGray;
                    G_Sharp_11.Enabled = false;
                    G_Sharp_11.BackColor = Color.LightGray;
                    G_Sharp_12.Enabled = false;
                    G_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (9):
                    G_Sharp_1.Enabled = true;
                    G_Sharp_1.BackColor = Color.Red;
                    G_Sharp_2.Enabled = true;
                    G_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_Sharp_3.Enabled = true;
                    G_Sharp_3.BackColor = Color.Yellow;
                    G_Sharp_4.Enabled = true;
                    G_Sharp_4.BackColor = Color.FromArgb(196, 255, 0);
                    G_Sharp_5.Enabled = true;
                    G_Sharp_5.BackColor = Color.Lime;
                    G_Sharp_6.Enabled = true;
                    G_Sharp_6.BackColor = Color.Cyan;
                    G_Sharp_7.Enabled = true;
                    G_Sharp_7.BackColor = Color.Blue;
                    G_Sharp_8.Enabled = true;
                    G_Sharp_8.BackColor = Color.FromArgb(128, 0, 255);
                    G_Sharp_9.Enabled = true;
                    G_Sharp_9.BackColor = Color.Magenta;
                    G_Sharp_10.Enabled = false;
                    G_Sharp_10.BackColor = Color.LightGray;
                    G_Sharp_11.Enabled = false;
                    G_Sharp_11.BackColor = Color.LightGray;
                    G_Sharp_12.Enabled = false;
                    G_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (10):
                    G_Sharp_1.Enabled = true;
                    G_Sharp_1.BackColor = Color.Red;
                    G_Sharp_2.Enabled = true;
                    G_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_Sharp_3.Enabled = true;
                    G_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    G_Sharp_4.Enabled = true;
                    G_Sharp_4.BackColor = Color.Yellow;
                    G_Sharp_5.Enabled = true;
                    G_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    G_Sharp_6.Enabled = true;
                    G_Sharp_6.BackColor = Color.Lime;
                    G_Sharp_7.Enabled = true;
                    G_Sharp_7.BackColor = Color.Cyan;
                    G_Sharp_8.Enabled = true;
                    G_Sharp_8.BackColor = Color.Blue;
                    G_Sharp_9.Enabled = true;
                    G_Sharp_9.BackColor = Color.FromArgb(128, 0, 255);
                    G_Sharp_10.Enabled = true;
                    G_Sharp_10.BackColor = Color.Magenta;
                    G_Sharp_11.Enabled = false;
                    G_Sharp_11.BackColor = Color.LightGray;
                    G_Sharp_12.Enabled = false;
                    G_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (11):
                    G_Sharp_1.Enabled = true;
                    G_Sharp_1.BackColor = Color.Red;
                    G_Sharp_2.Enabled = true;
                    G_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_Sharp_3.Enabled = true;
                    G_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    G_Sharp_4.Enabled = true;
                    G_Sharp_4.BackColor = Color.Yellow;
                    G_Sharp_5.Enabled = true;
                    G_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    G_Sharp_6.Enabled = true;
                    G_Sharp_6.BackColor = Color.Lime;
                    G_Sharp_7.Enabled = true;
                    G_Sharp_7.BackColor = Color.FromArgb(0, 255, 196);
                    G_Sharp_8.Enabled = true;
                    G_Sharp_8.BackColor = Color.Cyan;
                    G_Sharp_9.Enabled = true;
                    G_Sharp_9.BackColor = Color.Blue;
                    G_Sharp_10.Enabled = true;
                    G_Sharp_10.BackColor = Color.FromArgb(128, 0, 255);
                    G_Sharp_11.Enabled = true;
                    G_Sharp_11.BackColor = Color.Magenta;
                    G_Sharp_12.Enabled = false;
                    G_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (12):
                    G_Sharp_1.Enabled = true;
                    G_Sharp_1.BackColor = Color.Red;
                    G_Sharp_2.Enabled = true;
                    G_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    G_Sharp_3.Enabled = true;
                    G_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    G_Sharp_4.Enabled = true;
                    G_Sharp_4.BackColor = Color.Yellow;
                    G_Sharp_5.Enabled = true;
                    G_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    G_Sharp_6.Enabled = true;
                    G_Sharp_6.BackColor = Color.Lime;
                    G_Sharp_7.Enabled = true;
                    G_Sharp_7.BackColor = Color.FromArgb(0, 255, 196);
                    G_Sharp_8.Enabled = true;
                    G_Sharp_8.BackColor = Color.Cyan;
                    G_Sharp_9.Enabled = true;
                    G_Sharp_9.BackColor = Color.Blue;
                    G_Sharp_10.Enabled = true;
                    G_Sharp_10.BackColor = Color.FromArgb(128, 0, 255);
                    G_Sharp_11.Enabled = true;
                    G_Sharp_11.BackColor = Color.FromArgb(196, 0, 255);
                    G_Sharp_12.Enabled = true;
                    G_Sharp_12.BackColor = Color.Magenta;
                    break;
            }
            switch (ncol[9])
            {
                case (0):
                    A_1.Enabled = false;
                    A_1.BackColor = Color.LightGray;
                    A_2.Enabled = false;
                    A_2.BackColor = Color.LightGray;
                    A_3.Enabled = false;
                    A_3.BackColor = Color.LightGray;
                    A_4.Enabled = false;
                    A_4.BackColor = Color.LightGray;
                    A_5.Enabled = false;
                    A_5.BackColor = Color.LightGray;
                    A_6.Enabled = false;
                    A_6.BackColor = Color.LightGray;
                    A_7.Enabled = false;
                    A_7.BackColor = Color.LightGray;
                    A_8.Enabled = false;
                    A_8.BackColor = Color.LightGray;
                    A_9.Enabled = false;
                    A_9.BackColor = Color.LightGray;
                    A_10.Enabled = false;
                    A_10.BackColor = Color.LightGray;
                    A_11.Enabled = false;
                    A_11.BackColor = Color.LightGray;
                    A_12.Enabled = false;
                    A_12.BackColor = Color.LightGray;
                    break;
                case (1):
                    A_1.Enabled = true;
                    A_1.BackColor = Color.Red;
                    A_2.Enabled = false;
                    A_2.BackColor = Color.LightGray;
                    A_3.Enabled = false;
                    A_3.BackColor = Color.LightGray;
                    A_4.Enabled = false;
                    A_4.BackColor = Color.LightGray;
                    A_5.Enabled = false;
                    A_5.BackColor = Color.LightGray;
                    A_6.Enabled = false;
                    A_6.BackColor = Color.LightGray;
                    A_7.Enabled = false;
                    A_7.BackColor = Color.LightGray;
                    A_8.Enabled = false;
                    A_8.BackColor = Color.LightGray;
                    A_9.Enabled = false;
                    A_9.BackColor = Color.LightGray;
                    A_10.Enabled = false;
                    A_10.BackColor = Color.LightGray;
                    A_11.Enabled = false;
                    A_11.BackColor = Color.LightGray;
                    A_12.Enabled = false;
                    A_12.BackColor = Color.LightGray;
                    break;
                case (2):
                    A_1.Enabled = true;
                    A_1.BackColor = Color.Red;
                    A_2.Enabled = true;
                    A_2.BackColor = Color.Blue;
                    A_3.Enabled = false;
                    A_3.BackColor = Color.LightGray;
                    A_4.Enabled = false;
                    A_4.BackColor = Color.LightGray;
                    A_5.Enabled = false;
                    A_5.BackColor = Color.LightGray;
                    A_6.Enabled = false;
                    A_6.BackColor = Color.LightGray;
                    A_7.Enabled = false;
                    A_7.BackColor = Color.LightGray;
                    A_8.Enabled = false;
                    A_8.BackColor = Color.LightGray;
                    A_9.Enabled = false;
                    A_9.BackColor = Color.LightGray;
                    A_10.Enabled = false;
                    A_10.BackColor = Color.LightGray;
                    A_11.Enabled = false;
                    A_11.BackColor = Color.LightGray;
                    A_12.Enabled = false;
                    A_12.BackColor = Color.LightGray;
                    break;
                case (3):
                    A_1.Enabled = true;
                    A_1.BackColor = Color.Red;
                    A_2.Enabled = true;
                    A_2.BackColor = Color.Lime;
                    A_3.Enabled = true;
                    A_3.BackColor = Color.Blue;
                    A_4.Enabled = false;
                    A_4.BackColor = Color.LightGray;
                    A_5.Enabled = false;
                    A_5.BackColor = Color.LightGray;
                    A_6.Enabled = false;
                    A_6.BackColor = Color.LightGray;
                    A_7.Enabled = false;
                    A_7.BackColor = Color.LightGray;
                    A_8.Enabled = false;
                    A_8.BackColor = Color.LightGray;
                    A_9.Enabled = false;
                    A_9.BackColor = Color.LightGray;
                    A_10.Enabled = false;
                    A_10.BackColor = Color.LightGray;
                    A_11.Enabled = false;
                    A_11.BackColor = Color.LightGray;
                    A_12.Enabled = false;
                    A_12.BackColor = Color.LightGray;
                    break;
                case (4):
                    A_1.Enabled = true;
                    A_1.BackColor = Color.Red;
                    A_2.Enabled = true;
                    A_2.BackColor = Color.Yellow;
                    A_3.Enabled = true;
                    A_3.BackColor = Color.Lime;
                    A_4.Enabled = true;
                    A_4.BackColor = Color.Blue;
                    A_5.Enabled = false;
                    A_5.BackColor = Color.LightGray;
                    A_6.Enabled = false;
                    A_6.BackColor = Color.LightGray;
                    A_7.Enabled = false;
                    A_7.BackColor = Color.LightGray;
                    A_8.Enabled = false;
                    A_8.BackColor = Color.LightGray;
                    A_9.Enabled = false;
                    A_9.BackColor = Color.LightGray;
                    A_10.Enabled = false;
                    A_10.BackColor = Color.LightGray;
                    A_11.Enabled = false;
                    A_11.BackColor = Color.LightGray;
                    A_12.Enabled = false;
                    A_12.BackColor = Color.LightGray;
                    break;
                case (5):
                    A_1.Enabled = true;
                    A_1.BackColor = Color.Red;
                    A_2.Enabled = true;
                    A_2.BackColor = Color.Yellow;
                    A_3.Enabled = true;
                    A_3.BackColor = Color.Lime;
                    A_4.Enabled = true;
                    A_4.BackColor = Color.Cyan;
                    A_5.Enabled = true;
                    A_5.BackColor = Color.Blue;
                    A_6.Enabled = false;
                    A_6.BackColor = Color.LightGray;
                    A_7.Enabled = false;
                    A_7.BackColor = Color.LightGray;
                    A_8.Enabled = false;
                    A_8.BackColor = Color.LightGray;
                    A_9.Enabled = false;
                    A_9.BackColor = Color.LightGray;
                    A_10.Enabled = false;
                    A_10.BackColor = Color.LightGray;
                    A_11.Enabled = false;
                    A_11.BackColor = Color.LightGray;
                    A_12.Enabled = false;
                    A_12.BackColor = Color.LightGray;
                    break;
                case (6):
                    A_1.Enabled = true;
                    A_1.BackColor = Color.Red;
                    A_2.Enabled = true;
                    A_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_3.Enabled = true;
                    A_3.BackColor = Color.Yellow;
                    A_4.Enabled = true;
                    A_4.BackColor = Color.Lime;
                    A_5.Enabled = true;
                    A_5.BackColor = Color.Cyan;
                    A_6.Enabled = true;
                    A_6.BackColor = Color.Blue;
                    A_7.Enabled = false;
                    A_7.BackColor = Color.LightGray;
                    A_8.Enabled = false;
                    A_8.BackColor = Color.LightGray;
                    A_9.Enabled = false;
                    A_9.BackColor = Color.LightGray;
                    A_10.Enabled = false;
                    A_10.BackColor = Color.LightGray;
                    A_11.Enabled = false;
                    A_11.BackColor = Color.LightGray;
                    A_12.Enabled = false;
                    A_12.BackColor = Color.LightGray;
                    break;
                case (7):
                    A_1.Enabled = true;
                    A_1.BackColor = Color.Red;
                    A_2.Enabled = true;
                    A_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_3.Enabled = true;
                    A_3.BackColor = Color.Yellow;
                    A_4.Enabled = true;
                    A_4.BackColor = Color.Lime;
                    A_5.Enabled = true;
                    A_5.BackColor = Color.Cyan;
                    A_6.Enabled = true;
                    A_6.BackColor = Color.Blue;
                    A_7.Enabled = true;
                    A_7.BackColor = Color.FromArgb(128, 0, 255);
                    A_8.Enabled = false;
                    A_8.BackColor = Color.LightGray;
                    A_9.Enabled = false;
                    A_9.BackColor = Color.LightGray;
                    A_10.Enabled = false;
                    A_10.BackColor = Color.LightGray;
                    A_11.Enabled = false;
                    A_11.BackColor = Color.LightGray;
                    A_12.Enabled = false;
                    A_12.BackColor = Color.LightGray;
                    break;
                case (8):
                    A_1.Enabled = true;
                    A_1.BackColor = Color.Red;
                    A_2.Enabled = true;
                    A_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_3.Enabled = true;
                    A_3.BackColor = Color.Yellow;
                    A_4.Enabled = true;
                    A_4.BackColor = Color.Lime;
                    A_5.Enabled = true;
                    A_5.BackColor = Color.Cyan;
                    A_6.Enabled = true;
                    A_6.BackColor = Color.Blue;
                    A_7.Enabled = true;
                    A_7.BackColor = Color.FromArgb(128, 0, 255);
                    A_8.Enabled = true;
                    A_8.BackColor = Color.Magenta;
                    A_9.Enabled = false;
                    A_9.BackColor = Color.LightGray;
                    A_10.Enabled = false;
                    A_10.BackColor = Color.LightGray;
                    A_11.Enabled = false;
                    A_11.BackColor = Color.LightGray;
                    A_12.Enabled = false;
                    A_12.BackColor = Color.LightGray;
                    break;
                case (9):
                    A_1.Enabled = true;
                    A_1.BackColor = Color.Red;
                    A_2.Enabled = true;
                    A_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_3.Enabled = true;
                    A_3.BackColor = Color.Yellow;
                    A_4.Enabled = true;
                    A_4.BackColor = Color.FromArgb(196, 255, 0);
                    A_5.Enabled = true;
                    A_5.BackColor = Color.Lime;
                    A_6.Enabled = true;
                    A_6.BackColor = Color.Cyan;
                    A_7.Enabled = true;
                    A_7.BackColor = Color.Blue;
                    A_8.Enabled = true;
                    A_8.BackColor = Color.FromArgb(128, 0, 255);
                    A_9.Enabled = true;
                    A_9.BackColor = Color.Magenta;
                    A_10.Enabled = false;
                    A_10.BackColor = Color.LightGray;
                    A_11.Enabled = false;
                    A_11.BackColor = Color.LightGray;
                    A_12.Enabled = false;
                    A_12.BackColor = Color.LightGray;
                    break;
                case (10):
                    A_1.Enabled = true;
                    A_1.BackColor = Color.Red;
                    A_2.Enabled = true;
                    A_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_3.Enabled = true;
                    A_3.BackColor = Color.FromArgb(255, 196, 0);
                    A_4.Enabled = true;
                    A_4.BackColor = Color.Yellow;
                    A_5.Enabled = true;
                    A_5.BackColor = Color.FromArgb(196, 255, 0);
                    A_6.Enabled = true;
                    A_6.BackColor = Color.Lime;
                    A_7.Enabled = true;
                    A_7.BackColor = Color.Cyan;
                    A_8.Enabled = true;
                    A_8.BackColor = Color.Blue;
                    A_9.Enabled = true;
                    A_9.BackColor = Color.FromArgb(128, 0, 255);
                    A_10.Enabled = true;
                    A_10.BackColor = Color.Magenta;
                    A_11.Enabled = false;
                    A_11.BackColor = Color.LightGray;
                    A_12.Enabled = false;
                    A_12.BackColor = Color.LightGray;
                    break;
                case (11):
                    A_1.Enabled = true;
                    A_1.BackColor = Color.Red;
                    A_2.Enabled = true;
                    A_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_3.Enabled = true;
                    A_3.BackColor = Color.FromArgb(255, 196, 0);
                    A_4.Enabled = true;
                    A_4.BackColor = Color.Yellow;
                    A_5.Enabled = true;
                    A_5.BackColor = Color.FromArgb(196, 255, 0);
                    A_6.Enabled = true;
                    A_6.BackColor = Color.Lime;
                    A_7.Enabled = true;
                    A_7.BackColor = Color.FromArgb(0, 255, 196);
                    A_8.Enabled = true;
                    A_8.BackColor = Color.Cyan;
                    A_9.Enabled = true;
                    A_9.BackColor = Color.Blue;
                    A_10.Enabled = true;
                    A_10.BackColor = Color.FromArgb(128, 0, 255);
                    A_11.Enabled = true;
                    A_11.BackColor = Color.Magenta;
                    A_12.Enabled = false;
                    A_12.BackColor = Color.LightGray;
                    break;
                case (12):
                    A_1.Enabled = true;
                    A_1.BackColor = Color.Red;
                    A_2.Enabled = true;
                    A_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_3.Enabled = true;
                    A_3.BackColor = Color.FromArgb(255, 196, 0);
                    A_4.Enabled = true;
                    A_4.BackColor = Color.Yellow;
                    A_5.Enabled = true;
                    A_5.BackColor = Color.FromArgb(196, 255, 0);
                    A_6.Enabled = true;
                    A_6.BackColor = Color.Lime;
                    A_7.Enabled = true;
                    A_7.BackColor = Color.FromArgb(0, 255, 196);
                    A_8.Enabled = true;
                    A_8.BackColor = Color.Cyan;
                    A_9.Enabled = true;
                    A_9.BackColor = Color.Blue;
                    A_10.Enabled = true;
                    A_10.BackColor = Color.FromArgb(128, 0, 255);
                    A_11.Enabled = true;
                    A_11.BackColor = Color.FromArgb(196, 0, 255);
                    A_12.Enabled = true;
                    A_12.BackColor = Color.Magenta;
                    break;
            }
            switch (ncol[10])
            {
                case (0):
                    A_Sharp_1.Enabled = false;
                    A_Sharp_1.BackColor = Color.LightGray;
                    A_Sharp_2.Enabled = false;
                    A_Sharp_2.BackColor = Color.LightGray;
                    A_Sharp_3.Enabled = false;
                    A_Sharp_3.BackColor = Color.LightGray;
                    A_Sharp_4.Enabled = false;
                    A_Sharp_4.BackColor = Color.LightGray;
                    A_Sharp_5.Enabled = false;
                    A_Sharp_5.BackColor = Color.LightGray;
                    A_Sharp_6.Enabled = false;
                    A_Sharp_6.BackColor = Color.LightGray;
                    A_Sharp_7.Enabled = false;
                    A_Sharp_7.BackColor = Color.LightGray;
                    A_Sharp_8.Enabled = false;
                    A_Sharp_8.BackColor = Color.LightGray;
                    A_Sharp_9.Enabled = false;
                    A_Sharp_9.BackColor = Color.LightGray;
                    A_Sharp_10.Enabled = false;
                    A_Sharp_10.BackColor = Color.LightGray;
                    A_Sharp_11.Enabled = false;
                    A_Sharp_11.BackColor = Color.LightGray;
                    A_Sharp_12.Enabled = false;
                    A_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (1):
                    A_Sharp_1.Enabled = true;
                    A_Sharp_1.BackColor = Color.Red;
                    A_Sharp_2.Enabled = false;
                    A_Sharp_2.BackColor = Color.LightGray;
                    A_Sharp_3.Enabled = false;
                    A_Sharp_3.BackColor = Color.LightGray;
                    A_Sharp_4.Enabled = false;
                    A_Sharp_4.BackColor = Color.LightGray;
                    A_Sharp_5.Enabled = false;
                    A_Sharp_5.BackColor = Color.LightGray;
                    A_Sharp_6.Enabled = false;
                    A_Sharp_6.BackColor = Color.LightGray;
                    A_Sharp_7.Enabled = false;
                    A_Sharp_7.BackColor = Color.LightGray;
                    A_Sharp_8.Enabled = false;
                    A_Sharp_8.BackColor = Color.LightGray;
                    A_Sharp_9.Enabled = false;
                    A_Sharp_9.BackColor = Color.LightGray;
                    A_Sharp_10.Enabled = false;
                    A_Sharp_10.BackColor = Color.LightGray;
                    A_Sharp_11.Enabled = false;
                    A_Sharp_11.BackColor = Color.LightGray;
                    A_Sharp_12.Enabled = false;
                    A_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (2):
                    A_Sharp_1.Enabled = true;
                    A_Sharp_1.BackColor = Color.Red;
                    A_Sharp_2.Enabled = true;
                    A_Sharp_2.BackColor = Color.Blue;
                    A_Sharp_3.Enabled = false;
                    A_Sharp_3.BackColor = Color.LightGray;
                    A_Sharp_4.Enabled = false;
                    A_Sharp_4.BackColor = Color.LightGray;
                    A_Sharp_5.Enabled = false;
                    A_Sharp_5.BackColor = Color.LightGray;
                    A_Sharp_6.Enabled = false;
                    A_Sharp_6.BackColor = Color.LightGray;
                    A_Sharp_7.Enabled = false;
                    A_Sharp_7.BackColor = Color.LightGray;
                    A_Sharp_8.Enabled = false;
                    A_Sharp_8.BackColor = Color.LightGray;
                    A_Sharp_9.Enabled = false;
                    A_Sharp_9.BackColor = Color.LightGray;
                    A_Sharp_10.Enabled = false;
                    A_Sharp_10.BackColor = Color.LightGray;
                    A_Sharp_11.Enabled = false;
                    A_Sharp_11.BackColor = Color.LightGray;
                    A_Sharp_12.Enabled = false;
                    A_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (3):
                    A_Sharp_1.Enabled = true;
                    A_Sharp_1.BackColor = Color.Red;
                    A_Sharp_2.Enabled = true;
                    A_Sharp_2.BackColor = Color.Lime;
                    A_Sharp_3.Enabled = true;
                    A_Sharp_3.BackColor = Color.Blue;
                    A_Sharp_4.Enabled = false;
                    A_Sharp_4.BackColor = Color.LightGray;
                    A_Sharp_5.Enabled = false;
                    A_Sharp_5.BackColor = Color.LightGray;
                    A_Sharp_6.Enabled = false;
                    A_Sharp_6.BackColor = Color.LightGray;
                    A_Sharp_7.Enabled = false;
                    A_Sharp_7.BackColor = Color.LightGray;
                    A_Sharp_8.Enabled = false;
                    A_Sharp_8.BackColor = Color.LightGray;
                    A_Sharp_9.Enabled = false;
                    A_Sharp_9.BackColor = Color.LightGray;
                    A_Sharp_10.Enabled = false;
                    A_Sharp_10.BackColor = Color.LightGray;
                    A_Sharp_11.Enabled = false;
                    A_Sharp_11.BackColor = Color.LightGray;
                    A_Sharp_12.Enabled = false;
                    A_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (4):
                    A_Sharp_1.Enabled = true;
                    A_Sharp_1.BackColor = Color.Red;
                    A_Sharp_2.Enabled = true;
                    A_Sharp_2.BackColor = Color.Yellow;
                    A_Sharp_3.Enabled = true;
                    A_Sharp_3.BackColor = Color.Lime;
                    A_Sharp_4.Enabled = true;
                    A_Sharp_4.BackColor = Color.Blue;
                    A_Sharp_5.Enabled = false;
                    A_Sharp_5.BackColor = Color.LightGray;
                    A_Sharp_6.Enabled = false;
                    A_Sharp_6.BackColor = Color.LightGray;
                    A_Sharp_7.Enabled = false;
                    A_Sharp_7.BackColor = Color.LightGray;
                    A_Sharp_8.Enabled = false;
                    A_Sharp_8.BackColor = Color.LightGray;
                    A_Sharp_9.Enabled = false;
                    A_Sharp_9.BackColor = Color.LightGray;
                    A_Sharp_10.Enabled = false;
                    A_Sharp_10.BackColor = Color.LightGray;
                    A_Sharp_11.Enabled = false;
                    A_Sharp_11.BackColor = Color.LightGray;
                    A_Sharp_12.Enabled = false;
                    A_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (5):
                    A_Sharp_1.Enabled = true;
                    A_Sharp_1.BackColor = Color.Red;
                    A_Sharp_2.Enabled = true;
                    A_Sharp_2.BackColor = Color.Yellow;
                    A_Sharp_3.Enabled = true;
                    A_Sharp_3.BackColor = Color.Lime;
                    A_Sharp_4.Enabled = true;
                    A_Sharp_4.BackColor = Color.Cyan;
                    A_Sharp_5.Enabled = true;
                    A_Sharp_5.BackColor = Color.Blue;
                    A_Sharp_6.Enabled = false;
                    A_Sharp_6.BackColor = Color.LightGray;
                    A_Sharp_7.Enabled = false;
                    A_Sharp_7.BackColor = Color.LightGray;
                    A_Sharp_8.Enabled = false;
                    A_Sharp_8.BackColor = Color.LightGray;
                    A_Sharp_9.Enabled = false;
                    A_Sharp_9.BackColor = Color.LightGray;
                    A_Sharp_10.Enabled = false;
                    A_Sharp_10.BackColor = Color.LightGray;
                    A_Sharp_11.Enabled = false;
                    A_Sharp_11.BackColor = Color.LightGray;
                    A_Sharp_12.Enabled = false;
                    A_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (6):
                    A_Sharp_1.Enabled = true;
                    A_Sharp_1.BackColor = Color.Red;
                    A_Sharp_2.Enabled = true;
                    A_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_Sharp_3.Enabled = true;
                    A_Sharp_3.BackColor = Color.Yellow;
                    A_Sharp_4.Enabled = true;
                    A_Sharp_4.BackColor = Color.Lime;
                    A_Sharp_5.Enabled = true;
                    A_Sharp_5.BackColor = Color.Cyan;
                    A_Sharp_6.Enabled = true;
                    A_Sharp_6.BackColor = Color.Blue;
                    A_Sharp_7.Enabled = false;
                    A_Sharp_7.BackColor = Color.LightGray;
                    A_Sharp_8.Enabled = false;
                    A_Sharp_8.BackColor = Color.LightGray;
                    A_Sharp_9.Enabled = false;
                    A_Sharp_9.BackColor = Color.LightGray;
                    A_Sharp_10.Enabled = false;
                    A_Sharp_10.BackColor = Color.LightGray;
                    A_Sharp_11.Enabled = false;
                    A_Sharp_11.BackColor = Color.LightGray;
                    A_Sharp_12.Enabled = false;
                    A_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (7):
                    A_Sharp_1.Enabled = true;
                    A_Sharp_1.BackColor = Color.Red;
                    A_Sharp_2.Enabled = true;
                    A_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_Sharp_3.Enabled = true;
                    A_Sharp_3.BackColor = Color.Yellow;
                    A_Sharp_4.Enabled = true;
                    A_Sharp_4.BackColor = Color.Lime;
                    A_Sharp_5.Enabled = true;
                    A_Sharp_5.BackColor = Color.Cyan;
                    A_Sharp_6.Enabled = true;
                    A_Sharp_6.BackColor = Color.Blue;
                    A_Sharp_7.Enabled = true;
                    A_Sharp_7.BackColor = Color.FromArgb(128, 0, 255);
                    A_Sharp_8.Enabled = false;
                    A_Sharp_8.BackColor = Color.LightGray;
                    A_Sharp_9.Enabled = false;
                    A_Sharp_9.BackColor = Color.LightGray;
                    A_Sharp_10.Enabled = false;
                    A_Sharp_10.BackColor = Color.LightGray;
                    A_Sharp_11.Enabled = false;
                    A_Sharp_11.BackColor = Color.LightGray;
                    A_Sharp_12.Enabled = false;
                    A_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (8):
                    A_Sharp_1.Enabled = true;
                    A_Sharp_1.BackColor = Color.Red;
                    A_Sharp_2.Enabled = true;
                    A_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_Sharp_3.Enabled = true;
                    A_Sharp_3.BackColor = Color.Yellow;
                    A_Sharp_4.Enabled = true;
                    A_Sharp_4.BackColor = Color.Lime;
                    A_Sharp_5.Enabled = true;
                    A_Sharp_5.BackColor = Color.Cyan;
                    A_Sharp_6.Enabled = true;
                    A_Sharp_6.BackColor = Color.Blue;
                    A_Sharp_7.Enabled = true;
                    A_Sharp_7.BackColor = Color.FromArgb(128, 0, 255);
                    A_Sharp_8.Enabled = true;
                    A_Sharp_8.BackColor = Color.Magenta;
                    A_Sharp_9.Enabled = false;
                    A_Sharp_9.BackColor = Color.LightGray;
                    A_Sharp_10.Enabled = false;
                    A_Sharp_10.BackColor = Color.LightGray;
                    A_Sharp_11.Enabled = false;
                    A_Sharp_11.BackColor = Color.LightGray;
                    A_Sharp_12.Enabled = false;
                    A_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (9):
                    A_Sharp_1.Enabled = true;
                    A_Sharp_1.BackColor = Color.Red;
                    A_Sharp_2.Enabled = true;
                    A_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_Sharp_3.Enabled = true;
                    A_Sharp_3.BackColor = Color.Yellow;
                    A_Sharp_4.Enabled = true;
                    A_Sharp_4.BackColor = Color.FromArgb(196, 255, 0);
                    A_Sharp_5.Enabled = true;
                    A_Sharp_5.BackColor = Color.Lime;
                    A_Sharp_6.Enabled = true;
                    A_Sharp_6.BackColor = Color.Cyan;
                    A_Sharp_7.Enabled = true;
                    A_Sharp_7.BackColor = Color.Blue;
                    A_Sharp_8.Enabled = true;
                    A_Sharp_8.BackColor = Color.FromArgb(128, 0, 255);
                    A_Sharp_9.Enabled = true;
                    A_Sharp_9.BackColor = Color.Magenta;
                    A_Sharp_10.Enabled = false;
                    A_Sharp_10.BackColor = Color.LightGray;
                    A_Sharp_11.Enabled = false;
                    A_Sharp_11.BackColor = Color.LightGray;
                    A_Sharp_12.Enabled = false;
                    A_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (10):
                    A_Sharp_1.Enabled = true;
                    A_Sharp_1.BackColor = Color.Red;
                    A_Sharp_2.Enabled = true;
                    A_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_Sharp_3.Enabled = true;
                    A_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    A_Sharp_4.Enabled = true;
                    A_Sharp_4.BackColor = Color.Yellow;
                    A_Sharp_5.Enabled = true;
                    A_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    A_Sharp_6.Enabled = true;
                    A_Sharp_6.BackColor = Color.Lime;
                    A_Sharp_7.Enabled = true;
                    A_Sharp_7.BackColor = Color.Cyan;
                    A_Sharp_8.Enabled = true;
                    A_Sharp_8.BackColor = Color.Blue;
                    A_Sharp_9.Enabled = true;
                    A_Sharp_9.BackColor = Color.FromArgb(128, 0, 255);
                    A_Sharp_10.Enabled = true;
                    A_Sharp_10.BackColor = Color.Magenta;
                    A_Sharp_11.Enabled = false;
                    A_Sharp_11.BackColor = Color.LightGray;
                    A_Sharp_12.Enabled = false;
                    A_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (11):
                    A_Sharp_1.Enabled = true;
                    A_Sharp_1.BackColor = Color.Red;
                    A_Sharp_2.Enabled = true;
                    A_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_Sharp_3.Enabled = true;
                    A_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    A_Sharp_4.Enabled = true;
                    A_Sharp_4.BackColor = Color.Yellow;
                    A_Sharp_5.Enabled = true;
                    A_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    A_Sharp_6.Enabled = true;
                    A_Sharp_6.BackColor = Color.Lime;
                    A_Sharp_7.Enabled = true;
                    A_Sharp_7.BackColor = Color.FromArgb(0, 255, 196);
                    A_Sharp_8.Enabled = true;
                    A_Sharp_8.BackColor = Color.Cyan;
                    A_Sharp_9.Enabled = true;
                    A_Sharp_9.BackColor = Color.Blue;
                    A_Sharp_10.Enabled = true;
                    A_Sharp_10.BackColor = Color.FromArgb(128, 0, 255);
                    A_Sharp_11.Enabled = true;
                    A_Sharp_11.BackColor = Color.Magenta;
                    A_Sharp_12.Enabled = false;
                    A_Sharp_12.BackColor = Color.LightGray;
                    break;
                case (12):
                    A_Sharp_1.Enabled = true;
                    A_Sharp_1.BackColor = Color.Red;
                    A_Sharp_2.Enabled = true;
                    A_Sharp_2.BackColor = Color.FromArgb(255, 128, 0);
                    A_Sharp_3.Enabled = true;
                    A_Sharp_3.BackColor = Color.FromArgb(255, 196, 0);
                    A_Sharp_4.Enabled = true;
                    A_Sharp_4.BackColor = Color.Yellow;
                    A_Sharp_5.Enabled = true;
                    A_Sharp_5.BackColor = Color.FromArgb(196, 255, 0);
                    A_Sharp_6.Enabled = true;
                    A_Sharp_6.BackColor = Color.Lime;
                    A_Sharp_7.Enabled = true;
                    A_Sharp_7.BackColor = Color.FromArgb(0, 255, 196);
                    A_Sharp_8.Enabled = true;
                    A_Sharp_8.BackColor = Color.Cyan;
                    A_Sharp_9.Enabled = true;
                    A_Sharp_9.BackColor = Color.Blue;
                    A_Sharp_10.Enabled = true;
                    A_Sharp_10.BackColor = Color.FromArgb(128, 0, 255);
                    A_Sharp_11.Enabled = true;
                    A_Sharp_11.BackColor = Color.FromArgb(196, 0, 255);
                    A_Sharp_12.Enabled = true;
                    A_Sharp_12.BackColor = Color.Magenta;
                    break;
            }
            switch (ncol[11])
            {
                case (0):
                    B_1.Enabled = false;
                    B_1.BackColor = Color.LightGray;
                    B_2.Enabled = false;
                    B_2.BackColor = Color.LightGray;
                    B_3.Enabled = false;
                    B_3.BackColor = Color.LightGray;
                    B_4.Enabled = false;
                    B_4.BackColor = Color.LightGray;
                    B_5.Enabled = false;
                    B_5.BackColor = Color.LightGray;
                    B_6.Enabled = false;
                    B_6.BackColor = Color.LightGray;
                    B_7.Enabled = false;
                    B_7.BackColor = Color.LightGray;
                    B_8.Enabled = false;
                    B_8.BackColor = Color.LightGray;
                    B_9.Enabled = false;
                    B_9.BackColor = Color.LightGray;
                    B_10.Enabled = false;
                    B_10.BackColor = Color.LightGray;
                    B_11.Enabled = false;
                    B_11.BackColor = Color.LightGray;
                    B_12.Enabled = false;
                    B_12.BackColor = Color.LightGray;
                    break;
                case (1):
                    B_1.Enabled = true;
                    B_1.BackColor = Color.Red;
                    B_2.Enabled = false;
                    B_2.BackColor = Color.LightGray;
                    B_3.Enabled = false;
                    B_3.BackColor = Color.LightGray;
                    B_4.Enabled = false;
                    B_4.BackColor = Color.LightGray;
                    B_5.Enabled = false;
                    B_5.BackColor = Color.LightGray;
                    B_6.Enabled = false;
                    B_6.BackColor = Color.LightGray;
                    B_7.Enabled = false;
                    B_7.BackColor = Color.LightGray;
                    B_8.Enabled = false;
                    B_8.BackColor = Color.LightGray;
                    B_9.Enabled = false;
                    B_9.BackColor = Color.LightGray;
                    B_10.Enabled = false;
                    B_10.BackColor = Color.LightGray;
                    B_11.Enabled = false;
                    B_11.BackColor = Color.LightGray;
                    B_12.Enabled = false;
                    B_12.BackColor = Color.LightGray;
                    break;
                case (2):
                    B_1.Enabled = true;
                    B_1.BackColor = Color.Red;
                    B_2.Enabled = true;
                    B_2.BackColor = Color.Blue;
                    B_3.Enabled = false;
                    B_3.BackColor = Color.LightGray;
                    B_4.Enabled = false;
                    B_4.BackColor = Color.LightGray;
                    B_5.Enabled = false;
                    B_5.BackColor = Color.LightGray;
                    B_6.Enabled = false;
                    B_6.BackColor = Color.LightGray;
                    B_7.Enabled = false;
                    B_7.BackColor = Color.LightGray;
                    B_8.Enabled = false;
                    B_8.BackColor = Color.LightGray;
                    B_9.Enabled = false;
                    B_9.BackColor = Color.LightGray;
                    B_10.Enabled = false;
                    B_10.BackColor = Color.LightGray;
                    B_11.Enabled = false;
                    B_11.BackColor = Color.LightGray;
                    B_12.Enabled = false;
                    B_12.BackColor = Color.LightGray;
                    break;
                case (3):
                    B_1.Enabled = true;
                    B_1.BackColor = Color.Red;
                    B_2.Enabled = true;
                    B_2.BackColor = Color.Lime;
                    B_3.Enabled = true;
                    B_3.BackColor = Color.Blue;
                    B_4.Enabled = false;
                    B_4.BackColor = Color.LightGray;
                    B_5.Enabled = false;
                    B_5.BackColor = Color.LightGray;
                    B_6.Enabled = false;
                    B_6.BackColor = Color.LightGray;
                    B_7.Enabled = false;
                    B_7.BackColor = Color.LightGray;
                    B_8.Enabled = false;
                    B_8.BackColor = Color.LightGray;
                    B_9.Enabled = false;
                    B_9.BackColor = Color.LightGray;
                    B_10.Enabled = false;
                    B_10.BackColor = Color.LightGray;
                    B_11.Enabled = false;
                    B_11.BackColor = Color.LightGray;
                    B_12.Enabled = false;
                    B_12.BackColor = Color.LightGray;
                    break;
                case (4):
                    B_1.Enabled = true;
                    B_1.BackColor = Color.Red;
                    B_2.Enabled = true;
                    B_2.BackColor = Color.Yellow;
                    B_3.Enabled = true;
                    B_3.BackColor = Color.Lime;
                    B_4.Enabled = true;
                    B_4.BackColor = Color.Blue;
                    B_5.Enabled = false;
                    B_5.BackColor = Color.LightGray;
                    B_6.Enabled = false;
                    B_6.BackColor = Color.LightGray;
                    B_7.Enabled = false;
                    B_7.BackColor = Color.LightGray;
                    B_8.Enabled = false;
                    B_8.BackColor = Color.LightGray;
                    B_9.Enabled = false;
                    B_9.BackColor = Color.LightGray;
                    B_10.Enabled = false;
                    B_10.BackColor = Color.LightGray;
                    B_11.Enabled = false;
                    B_11.BackColor = Color.LightGray;
                    B_12.Enabled = false;
                    B_12.BackColor = Color.LightGray;
                    break;
                case (5):
                    B_1.Enabled = true;
                    B_1.BackColor = Color.Red;
                    B_2.Enabled = true;
                    B_2.BackColor = Color.Yellow;
                    B_3.Enabled = true;
                    B_3.BackColor = Color.Lime;
                    B_4.Enabled = true;
                    B_4.BackColor = Color.Cyan;
                    B_5.Enabled = true;
                    B_5.BackColor = Color.Blue;
                    B_6.Enabled = false;
                    B_6.BackColor = Color.LightGray;
                    B_7.Enabled = false;
                    B_7.BackColor = Color.LightGray;
                    B_8.Enabled = false;
                    B_8.BackColor = Color.LightGray;
                    B_9.Enabled = false;
                    B_9.BackColor = Color.LightGray;
                    B_10.Enabled = false;
                    B_10.BackColor = Color.LightGray;
                    B_11.Enabled = false;
                    B_11.BackColor = Color.LightGray;
                    B_12.Enabled = false;
                    B_12.BackColor = Color.LightGray;
                    break;
                case (6):
                    B_1.Enabled = true;
                    B_1.BackColor = Color.Red;
                    B_2.Enabled = true;
                    B_2.BackColor = Color.FromArgb(255, 128, 0);
                    B_3.Enabled = true;
                    B_3.BackColor = Color.Yellow;
                    B_4.Enabled = true;
                    B_4.BackColor = Color.Lime;
                    B_5.Enabled = true;
                    B_5.BackColor = Color.Cyan;
                    B_6.Enabled = true;
                    B_6.BackColor = Color.Blue;
                    B_7.Enabled = false;
                    B_7.BackColor = Color.LightGray;
                    B_8.Enabled = false;
                    B_8.BackColor = Color.LightGray;
                    B_9.Enabled = false;
                    B_9.BackColor = Color.LightGray;
                    B_10.Enabled = false;
                    B_10.BackColor = Color.LightGray;
                    B_11.Enabled = false;
                    B_11.BackColor = Color.LightGray;
                    B_12.Enabled = false;
                    B_12.BackColor = Color.LightGray;
                    break;
                case (7):
                    B_1.Enabled = true;
                    B_1.BackColor = Color.Red;
                    B_2.Enabled = true;
                    B_2.BackColor = Color.FromArgb(255, 128, 0);
                    B_3.Enabled = true;
                    B_3.BackColor = Color.Yellow;
                    B_4.Enabled = true;
                    B_4.BackColor = Color.Lime;
                    B_5.Enabled = true;
                    B_5.BackColor = Color.Cyan;
                    B_6.Enabled = true;
                    B_6.BackColor = Color.Blue;
                    B_7.Enabled = true;
                    B_7.BackColor = Color.FromArgb(128, 0, 255);
                    B_8.Enabled = false;
                    B_8.BackColor = Color.LightGray;
                    B_9.Enabled = false;
                    B_9.BackColor = Color.LightGray;
                    B_10.Enabled = false;
                    B_10.BackColor = Color.LightGray;
                    B_11.Enabled = false;
                    B_11.BackColor = Color.LightGray;
                    B_12.Enabled = false;
                    B_12.BackColor = Color.LightGray;
                    break;
                case (8):
                    B_1.Enabled = true;
                    B_1.BackColor = Color.Red;
                    B_2.Enabled = true;
                    B_2.BackColor = Color.FromArgb(255, 128, 0);
                    B_3.Enabled = true;
                    B_3.BackColor = Color.Yellow;
                    B_4.Enabled = true;
                    B_4.BackColor = Color.Lime;
                    B_5.Enabled = true;
                    B_5.BackColor = Color.Cyan;
                    B_6.Enabled = true;
                    B_6.BackColor = Color.Blue;
                    B_7.Enabled = true;
                    B_7.BackColor = Color.FromArgb(128, 0, 255);
                    B_8.Enabled = true;
                    B_8.BackColor = Color.Magenta;
                    B_9.Enabled = false;
                    B_9.BackColor = Color.LightGray;
                    B_10.Enabled = false;
                    B_10.BackColor = Color.LightGray;
                    B_11.Enabled = false;
                    B_11.BackColor = Color.LightGray;
                    B_12.Enabled = false;
                    B_12.BackColor = Color.LightGray;
                    break;
                case (9):
                    B_1.Enabled = true;
                    B_1.BackColor = Color.Red;
                    B_2.Enabled = true;
                    B_2.BackColor = Color.FromArgb(255, 128, 0);
                    B_3.Enabled = true;
                    B_3.BackColor = Color.Yellow;
                    B_4.Enabled = true;
                    B_4.BackColor = Color.FromArgb(196, 255, 0);
                    B_5.Enabled = true;
                    B_5.BackColor = Color.Lime;
                    B_6.Enabled = true;
                    B_6.BackColor = Color.Cyan;
                    B_7.Enabled = true;
                    B_7.BackColor = Color.Blue;
                    B_8.Enabled = true;
                    B_8.BackColor = Color.FromArgb(128, 0, 255);
                    B_9.Enabled = true;
                    B_9.BackColor = Color.Magenta;
                    B_10.Enabled = false;
                    B_10.BackColor = Color.LightGray;
                    B_11.Enabled = false;
                    B_11.BackColor = Color.LightGray;
                    B_12.Enabled = false;
                    B_12.BackColor = Color.LightGray;
                    break;
                case (10):
                    B_1.Enabled = true;
                    B_1.BackColor = Color.Red;
                    B_2.Enabled = true;
                    B_2.BackColor = Color.FromArgb(255, 128, 0);
                    B_3.Enabled = true;
                    B_3.BackColor = Color.FromArgb(255, 196, 0);
                    B_4.Enabled = true;
                    B_4.BackColor = Color.Yellow;
                    B_5.Enabled = true;
                    B_5.BackColor = Color.FromArgb(196, 255, 0);
                    B_6.Enabled = true;
                    B_6.BackColor = Color.Lime;
                    B_7.Enabled = true;
                    B_7.BackColor = Color.Cyan;
                    B_8.Enabled = true;
                    B_8.BackColor = Color.Blue;
                    B_9.Enabled = true;
                    B_9.BackColor = Color.FromArgb(128, 0, 255);
                    B_10.Enabled = true;
                    B_10.BackColor = Color.Magenta;
                    B_11.Enabled = false;
                    B_11.BackColor = Color.LightGray;
                    B_12.Enabled = false;
                    B_12.BackColor = Color.LightGray;
                    break;
                case (11):
                    B_1.Enabled = true;
                    B_1.BackColor = Color.Red;
                    B_2.Enabled = true;
                    B_2.BackColor = Color.FromArgb(255, 128, 0);
                    B_3.Enabled = true;
                    B_3.BackColor = Color.FromArgb(255, 196, 0);
                    B_4.Enabled = true;
                    B_4.BackColor = Color.Yellow;
                    B_5.Enabled = true;
                    B_5.BackColor = Color.FromArgb(196, 255, 0);
                    B_6.Enabled = true;
                    B_6.BackColor = Color.Lime;
                    B_7.Enabled = true;
                    B_7.BackColor = Color.FromArgb(0, 255, 196);
                    B_8.Enabled = true;
                    B_8.BackColor = Color.Cyan;
                    B_9.Enabled = true;
                    B_9.BackColor = Color.Blue;
                    B_10.Enabled = true;
                    B_10.BackColor = Color.FromArgb(128, 0, 255);
                    B_11.Enabled = true;
                    B_11.BackColor = Color.Magenta;
                    B_12.Enabled = false;
                    B_12.BackColor = Color.LightGray;
                    break;
                case (12):
                    B_1.Enabled = true;
                    B_1.BackColor = Color.Red;
                    B_2.Enabled = true;
                    B_2.BackColor = Color.FromArgb(255, 128, 0);
                    B_3.Enabled = true;
                    B_3.BackColor = Color.FromArgb(255, 196, 0);
                    B_4.Enabled = true;
                    B_4.BackColor = Color.Yellow;
                    B_5.Enabled = true;
                    B_5.BackColor = Color.FromArgb(196, 255, 0);
                    B_6.Enabled = true;
                    B_6.BackColor = Color.Lime;
                    B_7.Enabled = true;
                    B_7.BackColor = Color.FromArgb(0, 255, 196);
                    B_8.Enabled = true;
                    B_8.BackColor = Color.Cyan;
                    B_9.Enabled = true;
                    B_9.BackColor = Color.Blue;
                    B_10.Enabled = true;
                    B_10.BackColor = Color.FromArgb(128, 0, 255);
                    B_11.Enabled = true;
                    B_11.BackColor = Color.FromArgb(196, 0, 255);
                    B_12.Enabled = true;
                    B_12.BackColor = Color.Magenta;
                    break;
            }
        }

        private void Amplitude_ValueChanged(object sender, EventArgs e)
        {
            volume = (double) (Amplitude.Value / 500);
        }

        private void Octave_ValueChanged(object sender, EventArgs e)
        {
            int i = (int)Octave.Value;
            switch(i)
            {
                case (0):
                    base_freq = 32.75;
                    break;
                case (1):
                    base_freq = 65.5;
                    break;
                case (2):
                    base_freq = 131;
                    break;
                case (3):
                    base_freq = 262;
                    break;
                case (4):
                    base_freq = 524;
                    break;
                case (5):
                    base_freq = 1048;
                    break;
                case (6):
                    base_freq = 2096;
                    break;
                default:
                    base_freq = 262;
                    break;
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            switch(e.KeyCode)
            {
                case (Keys.Z):
                    if (numcol[0] >= color && !ksounds.isPlaying[0])
                    {
                        WaveSample wv = new WaveSample(base_freq * power(multiplier, color - 1), volume, wvtp, duty);
                        ksounds.snds[0] = new DirectSoundOut();
                        ksounds.snds[0].Init(wv);
                        ksounds.snds[0].Play();
                        ksounds.isPlaying[0] = true;
                    }
                    break;
                case (Keys.S):
                    if (numcol[1] >= color && !ksounds.isPlaying[1])
                    {
                        WaveSample wv = new WaveSample(base_freq * power(multiplier, color + numcol[0] - 1), volume, wvtp, duty);
                        ksounds.snds[1] = new DirectSoundOut();
                        ksounds.snds[1].Init(wv);
                        ksounds.snds[1].Play();
                        ksounds.isPlaying[1] = true;
                    }
                    break;
                case (Keys.X):
                    if (numcol[2] >= color && !ksounds.isPlaying[2])
                    {
                        WaveSample wv = new WaveSample(base_freq * power(multiplier, color + numcol[0] + numcol[1] - 1), volume, wvtp, duty);
                        ksounds.snds[2] = new DirectSoundOut();
                        ksounds.snds[2].Init(wv);
                        ksounds.snds[2].Play();
                        ksounds.isPlaying[2] = true;
                    }
                    break;
                case (Keys.D):
                    if (numcol[3] >= color && !ksounds.isPlaying[3])
                    {
                        WaveSample wv = new WaveSample(base_freq * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] - 1), volume, wvtp, duty);
                        ksounds.snds[3] = new DirectSoundOut();
                        ksounds.snds[3].Init(wv);
                        ksounds.snds[3].Play();
                        ksounds.isPlaying[3] = true;
                    }
                    break;
                case (Keys.C):
                    if (numcol[4] >= color && !ksounds.isPlaying[4])
                    {
                        WaveSample wv = new WaveSample(base_freq * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] - 1), volume, wvtp, duty);
                        ksounds.snds[4] = new DirectSoundOut();
                        ksounds.snds[4].Init(wv);
                        ksounds.snds[4].Play();
                        ksounds.isPlaying[4] = true;
                    }
                    break;
                case (Keys.V):
                    if (numcol[5] >= color && !ksounds.isPlaying[5])
                    {
                        WaveSample wv = new WaveSample(base_freq * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] - 1), volume, wvtp, duty);
                        ksounds.snds[5] = new DirectSoundOut();
                        ksounds.snds[5].Init(wv);
                        ksounds.snds[5].Play();
                        ksounds.isPlaying[5] = true;
                    }
                    break;
                case (Keys.G):
                    if (numcol[6] >= color && !ksounds.isPlaying[6])
                    {
                        WaveSample wv = new WaveSample(base_freq * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] - 1), volume, wvtp, duty);
                        ksounds.snds[6] = new DirectSoundOut();
                        ksounds.snds[6].Init(wv);
                        ksounds.snds[6].Play();
                        ksounds.isPlaying[6] = true;
                    }
                    break;
                case (Keys.B):
                    if (numcol[7] >= color && !ksounds.isPlaying[7])
                    {
                        WaveSample wv = new WaveSample(base_freq * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] - 1), volume, wvtp, duty);
                        ksounds.snds[7] = new DirectSoundOut();
                        ksounds.snds[7].Init(wv);
                        ksounds.snds[7].Play();
                        ksounds.isPlaying[7] = true;
                    }
                    break;
                case (Keys.H):
                    if (numcol[8] >= color && !ksounds.isPlaying[8])
                    {
                        WaveSample wv = new WaveSample(base_freq * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] - 1), volume, wvtp, duty);
                        ksounds.snds[8] = new DirectSoundOut();
                        ksounds.snds[8].Init(wv);
                        ksounds.snds[8].Play();
                        ksounds.isPlaying[8] = true;
                    }
                    break;
                case (Keys.N):
                    if (numcol[9] >= color && !ksounds.isPlaying[9])
                    {
                        WaveSample wv = new WaveSample(base_freq * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] - 1), volume, wvtp, duty);
                        ksounds.snds[9] = new DirectSoundOut();
                        ksounds.snds[9].Init(wv);
                        ksounds.snds[9].Play();
                        ksounds.isPlaying[9] = true;
                    }
                    break;
                case (Keys.J):
                    if (numcol[10] >= color && !ksounds.isPlaying[10])
                    {
                        WaveSample wv = new WaveSample(base_freq * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] - 1), volume, wvtp, duty);
                        ksounds.snds[10] = new DirectSoundOut();
                        ksounds.snds[10].Init(wv);
                        ksounds.snds[10].Play();
                        ksounds.isPlaying[10] = true;
                    }
                    break;
                case (Keys.M):
                    if (numcol[11] >= color && !ksounds.isPlaying[11])
                    {
                        WaveSample wv = new WaveSample(base_freq * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] - 1), volume, wvtp, duty);
                        ksounds.snds[11] = new DirectSoundOut();
                        ksounds.snds[11].Init(wv);
                        ksounds.snds[11].Play();
                        ksounds.isPlaying[11] = true;
                    }
                    break;
                case (Keys.Oemcomma):
                    if (numcol[0] >= color && !ksounds.isPlaying[12])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color - 1), volume, wvtp, duty);
                        ksounds.snds[12] = new DirectSoundOut();
                        ksounds.snds[12].Init(wv);
                        ksounds.snds[12].Play();
                        ksounds.isPlaying[12] = true;
                    }
                    break;
                case (Keys.Q):
                    if (numcol[0] >= color && !ksounds.isPlaying[12])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color - 1), volume, wvtp, duty);
                        ksounds.snds[12] = new DirectSoundOut();
                        ksounds.snds[12].Init(wv);
                        ksounds.snds[12].Play();
                        ksounds.isPlaying[12] = true;
                    }
                    break;
                case (Keys.D2):
                    if (numcol[1] >= color && !ksounds.isPlaying[13])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color + numcol[0] - 1), volume, wvtp, duty);
                        ksounds.snds[13] = new DirectSoundOut();
                        ksounds.snds[13].Init(wv);
                        ksounds.snds[13].Play();
                        ksounds.isPlaying[13] = true;
                    }
                    break;
                case (Keys.W):
                    if (numcol[2] >= color && !ksounds.isPlaying[14])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color + numcol[0] + numcol[1] - 1), volume, wvtp, duty);
                        ksounds.snds[14] = new DirectSoundOut();
                        ksounds.snds[14].Init(wv);
                        ksounds.snds[14].Play();
                        ksounds.isPlaying[14] = true;
                    }
                    break;
                case (Keys.D3):
                    if (numcol[3] >= color && !ksounds.isPlaying[15])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] - 1), volume, wvtp, duty);
                        ksounds.snds[15] = new DirectSoundOut();
                        ksounds.snds[15].Init(wv);
                        ksounds.snds[15].Play();
                        ksounds.isPlaying[15] = true;
                    }
                    break;
                case (Keys.E):
                    if (numcol[4] >= color && !ksounds.isPlaying[16])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] - 1), volume, wvtp, duty);
                        ksounds.snds[16] = new DirectSoundOut();
                        ksounds.snds[16].Init(wv);
                        ksounds.snds[16].Play();
                        ksounds.isPlaying[16] = true;
                    }
                    break;
                case (Keys.R):
                    if (numcol[5] >= color && !ksounds.isPlaying[17])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] - 1), volume, wvtp, duty);
                        ksounds.snds[17] = new DirectSoundOut();
                        ksounds.snds[17].Init(wv);
                        ksounds.snds[17].Play();
                        ksounds.isPlaying[17] = true;
                    }
                    break;
                case (Keys.D5):
                    if (numcol[6] >= color && !ksounds.isPlaying[18])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] - 1), volume, wvtp, duty);
                        ksounds.snds[18] = new DirectSoundOut();
                        ksounds.snds[18].Init(wv);
                        ksounds.snds[18].Play();
                        ksounds.isPlaying[18] = true;
                    }
                    break;
                case (Keys.T):
                    if (numcol[7] >= color && !ksounds.isPlaying[19])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] - 1), volume, wvtp, duty);
                        ksounds.snds[19] = new DirectSoundOut();
                        ksounds.snds[19].Init(wv);
                        ksounds.snds[19].Play();
                        ksounds.isPlaying[19] = true;
                    }
                    break;
                case (Keys.D6):
                    if (numcol[8] >= color && !ksounds.isPlaying[20])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] - 1), volume, wvtp, duty);
                        ksounds.snds[20] = new DirectSoundOut();
                        ksounds.snds[20].Init(wv);
                        ksounds.snds[20].Play();
                        ksounds.isPlaying[20] = true;
                    }
                    break;
                case (Keys.Y):
                    if (numcol[9] >= color && !ksounds.isPlaying[21])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] - 1), volume, wvtp, duty);
                        ksounds.snds[21] = new DirectSoundOut();
                        ksounds.snds[21].Init(wv);
                        ksounds.snds[21].Play();
                        ksounds.isPlaying[21] = true;
                    }
                    break;
                case (Keys.D7):
                    if (numcol[10] >= color && !ksounds.isPlaying[22])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] - 1), volume, wvtp, duty);
                        ksounds.snds[22] = new DirectSoundOut();
                        ksounds.snds[22].Init(wv);
                        ksounds.snds[22].Play();
                        ksounds.isPlaying[22] = true;
                    }
                    break;
                case (Keys.U):
                    if (numcol[11] >= color && !ksounds.isPlaying[23])
                    {
                        WaveSample wv = new WaveSample(base_freq * 2 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] - 1), volume, wvtp, duty);
                        ksounds.snds[23] = new DirectSoundOut();
                        ksounds.snds[23].Init(wv);
                        ksounds.snds[23].Play();
                        ksounds.isPlaying[23] = true;
                    }
                    break;
                case (Keys.I):
                    if (numcol[0] >= color && !ksounds.isPlaying[24])
                    {
                        WaveSample wv = new WaveSample(base_freq * 4 * power(multiplier, color - 1), volume, wvtp, duty);
                        ksounds.snds[24] = new DirectSoundOut();
                        ksounds.snds[24].Init(wv);
                        ksounds.snds[24].Play();
                        ksounds.isPlaying[24] = true;
                    }
                    break;
                case (Keys.D9):
                    if (numcol[1] >= color && !ksounds.isPlaying[25])
                    {
                        WaveSample wv = new WaveSample(base_freq * 4 * power(multiplier, color + numcol[0] - 1), volume, wvtp, duty);
                        ksounds.snds[25] = new DirectSoundOut();
                        ksounds.snds[25].Init(wv);
                        ksounds.snds[25].Play();
                        ksounds.isPlaying[25] = true;
                    }
                    break;
                case (Keys.O):
                    if (numcol[2] >= color && !ksounds.isPlaying[26])
                    {
                        WaveSample wv = new WaveSample(base_freq * 4 * power(multiplier, color + numcol[0] + numcol[1] - 1), volume, wvtp, duty);
                        ksounds.snds[26] = new DirectSoundOut();
                        ksounds.snds[26].Init(wv);
                        ksounds.snds[26].Play();
                        ksounds.isPlaying[26] = true;
                    }
                    break;
                case (Keys.D0):
                    if (numcol[3] >= color && !ksounds.isPlaying[27])
                    {
                        WaveSample wv = new WaveSample(base_freq * 4 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] - 1), volume, wvtp, duty);
                        ksounds.snds[27] = new DirectSoundOut();
                        ksounds.snds[27].Init(wv);
                        ksounds.snds[27].Play();
                        ksounds.isPlaying[27] = true;
                    }
                    break;
                case (Keys.P):
                    if (numcol[4] >= color && !ksounds.isPlaying[28])
                    {
                        WaveSample wv = new WaveSample(base_freq * 4 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] - 1), volume, wvtp, duty);
                        ksounds.snds[28] = new DirectSoundOut();
                        ksounds.snds[28].Init(wv);
                        ksounds.snds[28].Play();
                        ksounds.isPlaying[28] = true;
                    }
                    break;
                case (Keys.OemOpenBrackets):
                    if (numcol[5] >= color && !ksounds.isPlaying[29])
                    {
                        WaveSample wv = new WaveSample(base_freq * 4 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] - 1), volume, wvtp, duty);
                        ksounds.snds[29] = new DirectSoundOut();
                        ksounds.snds[29].Init(wv);
                        ksounds.snds[29].Play();
                        ksounds.isPlaying[29] = true;
                    }
                    break;
                case (Keys.Oemplus):
                    if (numcol[6] >= color && !ksounds.isPlaying[30])
                    {
                        WaveSample wv = new WaveSample(base_freq * 4 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] - 1), volume, wvtp, duty);
                        ksounds.snds[30] = new DirectSoundOut();
                        ksounds.snds[30].Init(wv);
                        ksounds.snds[30].Play();
                        ksounds.isPlaying[30] = true;
                    }
                    break;
                case (Keys.OemCloseBrackets):
                    if (numcol[7] >= color && !ksounds.isPlaying[31])
                    {
                        WaveSample wv = new WaveSample(base_freq * 4 * power(multiplier, color + numcol[0] + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] - 1), volume, wvtp, duty);
                        ksounds.snds[31] = new DirectSoundOut();
                        ksounds.snds[31].Init(wv);
                        ksounds.snds[31].Play();
                        ksounds.isPlaying[31] = true;
                    }
                    break;
                case (Keys.F1):
                    color = 1;
                    Color_Disp.BackColor = Color.Red;
                    break;
                case (Keys.F2):
                    if (tot_cols >= 2)
                    {
                        color = 2;
                        Color_Disp.BackColor = C_2.BackColor;
                    }
                    break;
                case (Keys.F3):
                    if (tot_cols >= 3)
                    {
                        color = 3;
                        Color_Disp.BackColor = C_3.BackColor;
                    }
                    break;
                case (Keys.F4):
                    if (tot_cols >= 4)
                    {
                        color = 4;
                        Color_Disp.BackColor = C_4.BackColor;
                    }
                    break;
                case (Keys.F5):
                    if (tot_cols >= 5)
                    {
                        color = 5;
                        Color_Disp.BackColor = C_5.BackColor;
                    }
                    break;
                case (Keys.F6):
                    if (tot_cols >= 6)
                    {
                        color = 6;
                        Color_Disp.BackColor = C_6.BackColor;
                    }
                    break;
                case (Keys.F7):
                    if (tot_cols >= 7)
                    {
                        color = 7;
                        Color_Disp.BackColor = C_7.BackColor;
                    }
                    break;
                case (Keys.F8):
                    if (tot_cols >= 8)
                    {
                        color = 8;
                        Color_Disp.BackColor = C_8.BackColor;
                    }
                    break;
                case (Keys.F9):
                    if (tot_cols >= 9)
                    {
                        color = 9;
                        Color_Disp.BackColor = C_9.BackColor;
                    }
                    break;
                case (Keys.F10):
                    if (tot_cols >= 10)
                    {
                        color = 10;
                        Color_Disp.BackColor = C_10.BackColor;
                    }
                    break;
                case (Keys.F11):
                    if (tot_cols >= 11)
                    {
                        color = 11;
                        Color_Disp.BackColor = C_11.BackColor;
                    }
                    break;
                case (Keys.F12):
                    if (tot_cols >= 12)
                    {
                        color = 12;
                        Color_Disp.BackColor = C_12.BackColor;
                    }
                    break;
                case (Keys.Oemtilde):
                    Octave.Value = 0;
                    break;
                case (Keys.D1):
                    Octave.Value = 1;
                    break;
                case (Keys.OemSemicolon):
                    Octave.Value = 3;
                    break;
                case (Keys.OemQuestion):
                    Octave.Value = 5;
                    break;
                case (Keys.OemQuotes):
                    Octave.Value = 6;
                    break;
            }
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            switch (e.KeyChar)
            {
                case ((char)Keys.Space):
                    if (hold)
                    {
                        hold = false;
                        foreach(NAudio.Wave.DirectSoundOut w in sounds.ToList())
                        {
                            w.Stop();
                            sounds.Remove(w);
                        }
                        break;
                    }  
                    if (!hold)
                        hold = true;
                    break;
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            switch(e.KeyCode)
            {
                case (Keys.Z):
                    if (ksounds.isPlaying[0])
                    {
                        ksounds.snds[0].Stop();
                        ksounds.isPlaying[0] = false;
                    }
                    break;
                case (Keys.S):
                    if (ksounds.isPlaying[1])
                    {
                        ksounds.snds[1].Stop();
                        ksounds.isPlaying[1] = false;
                    }
                    break;
                case (Keys.X):
                    if (ksounds.isPlaying[2])
                    {
                        ksounds.snds[2].Stop();
                        ksounds.isPlaying[2] = false;
                    }
                    break;
                case (Keys.D):
                    if (ksounds.isPlaying[3])
                    {
                        ksounds.snds[3].Stop();
                        ksounds.isPlaying[3] = false;
                    }
                    break;
                case (Keys.C):
                    if (ksounds.isPlaying[4])
                    {
                        ksounds.snds[4].Stop();
                        ksounds.isPlaying[4] = false;
                    }
                    break;
                case (Keys.V):
                    if (ksounds.isPlaying[5])
                    {
                        ksounds.snds[5].Stop();
                        ksounds.isPlaying[5] = false;
                    }
                    break;
                case (Keys.G):
                    if (ksounds.isPlaying[6])
                    {
                        ksounds.snds[6].Stop();
                        ksounds.isPlaying[6] = false;
                    }
                    break;
                case (Keys.B):
                    if (ksounds.isPlaying[7])
                    {
                        ksounds.snds[7].Stop();
                        ksounds.isPlaying[7] = false;
                    }
                    break;
                case (Keys.H):
                    if (ksounds.isPlaying[8])
                    {
                        ksounds.snds[8].Stop();
                        ksounds.isPlaying[8] = false;
                    }
                    break;
                case (Keys.N):
                    if (ksounds.isPlaying[9])
                    {
                        ksounds.snds[9].Stop();
                        ksounds.isPlaying[9] = false;
                    }
                    break;
                case (Keys.J):
                    if (ksounds.isPlaying[10])
                    {
                        ksounds.snds[10].Stop();
                        ksounds.isPlaying[10] = false;
                    }
                    break;
                case (Keys.M):
                    if (ksounds.isPlaying[11])
                    {
                        ksounds.snds[11].Stop();
                        ksounds.isPlaying[11] = false;
                    }
                    break;
                case (Keys.Oemcomma):
                    if (ksounds.isPlaying[12])
                    {
                        ksounds.snds[12].Stop();
                        ksounds.isPlaying[12] = false;
                    }
                    break;
                case (Keys.Q):
                    if (ksounds.isPlaying[12])
                    {
                        ksounds.snds[12].Stop();
                        ksounds.isPlaying[12] = false;
                    }
                    break;
                case (Keys.D2):
                    if (ksounds.isPlaying[13])
                    {
                        ksounds.snds[13].Stop();
                        ksounds.isPlaying[13] = false;
                    }
                    break;
                case (Keys.W):
                    if (ksounds.isPlaying[14])
                    {
                        ksounds.snds[14].Stop();
                        ksounds.isPlaying[14] = false;
                    }
                    break;
                case (Keys.D3):
                    if (ksounds.isPlaying[15])
                    {
                        ksounds.snds[15].Stop();
                        ksounds.isPlaying[15] = false;
                    }
                    break;
                case (Keys.E):
                    if (ksounds.isPlaying[16])
                    {
                        ksounds.snds[16].Stop();
                        ksounds.isPlaying[16] = false;
                    }
                    break;
                case (Keys.R):
                    if (ksounds.isPlaying[17])
                    {
                        ksounds.snds[17].Stop();
                        ksounds.isPlaying[17] = false;
                    }
                    break;
                case (Keys.D5):
                    if (ksounds.isPlaying[18])
                    {
                        ksounds.snds[18].Stop();
                        ksounds.isPlaying[18] = false;
                    }
                    break;
                case (Keys.T):
                    if (ksounds.isPlaying[19])
                    {
                        ksounds.snds[19].Stop();
                        ksounds.isPlaying[19] = false;
                    }
                    break;
                case (Keys.D6):
                    if (ksounds.isPlaying[20])
                    {
                        ksounds.snds[20].Stop();
                        ksounds.isPlaying[20] = false;
                    }
                    break;
                case (Keys.Y):
                    if (ksounds.isPlaying[21])
                    {
                        ksounds.snds[21].Stop();
                        ksounds.isPlaying[21] = false;
                    }
                    break;
                case (Keys.D7):
                    if (ksounds.isPlaying[22])
                    {
                        ksounds.snds[22].Stop();
                        ksounds.isPlaying[22] = false;
                    }
                    break;
                case (Keys.U):
                    if (ksounds.isPlaying[23])
                    {
                        ksounds.snds[23].Stop();
                        ksounds.isPlaying[23] = false;
                    }
                    break;
                case (Keys.I):
                    if (ksounds.isPlaying[24])
                    {
                        ksounds.snds[24].Stop();
                        ksounds.isPlaying[24] = false;
                    }
                    break;
                case (Keys.D9):
                    if (ksounds.isPlaying[25])
                    {
                        ksounds.snds[25].Stop();
                        ksounds.isPlaying[25] = false;
                    }
                    break;
                case (Keys.O):
                    if (ksounds.isPlaying[26])
                    {
                        ksounds.snds[26].Stop();
                        ksounds.isPlaying[26] = false;
                    }
                    break;
                case (Keys.D0):
                    if (ksounds.isPlaying[27])
                    {
                        ksounds.snds[27].Stop();
                        ksounds.isPlaying[27] = false;
                    }
                    break;
                case (Keys.P):
                    if (ksounds.isPlaying[28])
                    {
                        ksounds.snds[28].Stop();
                        ksounds.isPlaying[28] = false;
                    }
                    break;
                case (Keys.OemOpenBrackets):
                    if (ksounds.isPlaying[29])
                    {
                        ksounds.snds[29].Stop();
                        ksounds.isPlaying[29] = false;
                    }
                    break;
                case (Keys.Oemplus):
                    if (ksounds.isPlaying[30])
                    {
                        ksounds.snds[30].Stop();
                        ksounds.isPlaying[30] = false;
                    }
                    break;
                case (Keys.OemCloseBrackets):
                    if (ksounds.isPlaying[31])
                    {
                        ksounds.snds[31].Stop();
                        ksounds.isPlaying[31] = false;
                    }
                    break;
            }
        }

        private void C_1_MouseDown(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 1)
            {
                WaveSample wv = new WaveSample(base_freq, volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_1_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 1 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_2_MouseDown(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 2)
            {
                WaveSample wv = new WaveSample(base_freq * multiplier, volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_2_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 2 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_3_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 3 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_3_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[0] >= 3)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 2), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_4_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[0] >= 4)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 3), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_4_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 4 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_5_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[0] >= 5)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 4), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_5_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 5 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_6_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[0] >= 6)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 5), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_6_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 6 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_7_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[0] >= 7)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 6), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_7_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 7 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_8_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[0] >= 8)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 7), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_8_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 8 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_9_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[0] >= 9)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 8), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_9_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_10_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[0] >= 10)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 9), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_10_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 10 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_11_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[0] >= 11)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 10), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_11_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 11 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_12_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[0] >= 12)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 11), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_12_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[0] >= 12 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_1_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 1)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_Sharp_1_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[1] >= 1 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_2_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 2)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + 1), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_Sharp_2_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[1] >= 2 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_3_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 3)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + 2), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_Sharp_3_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[1] >= 3 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_4_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 4)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + 3), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_Sharp_4_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[1] >= 4 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_5_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 5)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + 4), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_Sharp_5_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[1] >= 5 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_6_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 6)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + 5), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_Sharp_6_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[1] >= 6 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_7_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 7)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + 6), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_Sharp_7_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[1] >= 7 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_8_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 8)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + 7), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_Sharp_8_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[1] >= 8 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_9_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 9)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + 8), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_Sharp_9_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_10_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 10)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + 9), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_Sharp_10_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[1] >= 10 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_11_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 11)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + 10), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_Sharp_11_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[1] >= 11 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void C_Sharp_12_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[1] >= 12)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + 11), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void C_Sharp_12_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[1] >= 12 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_1_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 1)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_1_MouseUp(object sender, MouseEventArgs e)
        {
            if(numcol[2] >= 1 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_2_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 2)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + 1), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_2_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 2 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_3_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 3)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + 2), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_3_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 3 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_4_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 4)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + 3), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_4_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[2] >=4 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_5_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 5)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + 4), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_5_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 5 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_6_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 6)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + 5), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_6_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 7)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_7_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 7)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + 6), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_7_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 7 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_8_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 8)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + 7), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_8_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_9_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 9)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + 8), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_9_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_10_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 10)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + 9), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_10_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 10 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_11_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 11)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + 10), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_11_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 11 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_12_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 12)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + 11), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_12_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[2] >= 12 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_1_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 1)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_Sharp_2_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 2 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_1_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 1 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_2_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 2)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + 1), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_Sharp_3_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 3)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + 2), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_Sharp_3_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 3 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_4_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 4)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + 3), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_Sharp_4_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 4 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_5_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 5)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + 4), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_Sharp_5_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 5 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_6_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 6)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + 5), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_Sharp_6_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 6 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_7_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 7)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + 6), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_Sharp_7_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 7 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_8_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 8)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + 7), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_Sharp_8_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 8 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_9_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 9)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + 8), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_Sharp_9_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_10_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 10)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + 9), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_Sharp_10_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 10 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_11_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 11)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + 10), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_Sharp_11_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 11 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void D_Sharp_12_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 12)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + 11), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void D_Sharp_12_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[3] >= 12 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_1_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 1)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void E_1_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 1 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_2_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 2)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + 1), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void E_2_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 2 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_3_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 3)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + 2), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void E_3_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 3 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_4_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 4)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + 3), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void E_4_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 4 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_5_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 5)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + 4), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void E_5_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 5 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_6_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 6)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + 5), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void E_6_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 6 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_7_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 7)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + 6), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void E_7_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 7 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_8_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 8)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + 7), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void E_8_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 8 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_9_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 9)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + 8), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void E_9_MouseMove(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_10_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 10)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + 9), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void E_10_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 10 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_11_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 11)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + 10), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void E_11_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 11 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void E_12_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 12)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + 11), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void E_12_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[4] >= 12 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_1_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 1)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_1_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[5] >=1 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_2_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 2)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + 1), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_2_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 2 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_3_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 3)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + 2), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_3_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 3 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_4_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 4)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + 3), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_4_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 4 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_5_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 5)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + 4), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_5_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 5 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_6_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 6)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + 5), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_6_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 6 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_7_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 7)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + 6), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_7_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 7 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_8_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 8)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + 7), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_8_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[5] >=8 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_9_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 9)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + 8), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_9_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_10_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 10)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + 9), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_10_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 10 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_11_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 11)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + 10), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_11_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 11 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_12_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 12)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + 11), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_12_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[5] >= 12 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_1_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 1)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_Sharp_1_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 1 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_2_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 2)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + 1), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_Sharp_2_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 2 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_3_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 3)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + 2), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_Sharp_3_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 3 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_4_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 4)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + 3), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_Sharp_4_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 4 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_5_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 5)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + 4), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_Sharp_5_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 5 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_6_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 6)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + 5), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_Sharp_6_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 6 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_7_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 7)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + 6), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_Sharp_7_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 7 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_8_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 8)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + 7), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_Sharp_8_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 8 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_9_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 9)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + 8), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_Sharp_9_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_10_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 10)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + 9), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_Sharp_10_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 10 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_11_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 11)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + 10), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_Sharp_11_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 11 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void F_Sharp_12_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 12)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + 11), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void F_Sharp_12_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[6] >= 12 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_1_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 1)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_1_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 1 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_2_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 2)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + 1), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_2_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 2 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_3_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 3)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + 2), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_3_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 3 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_4_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 4)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + 3), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_4_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 4 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_5_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 5)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + 4), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_5_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 5 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_6_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 6)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + 5), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_6_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 6 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_7_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 7)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + 6), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_7_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 7 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_8_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 8)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + 7), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_8_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 8 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_9_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 9)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + 8), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_9_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_10_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 10)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + 9), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_10_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 10 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_11_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 11)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + 10), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_11_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 11 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_12_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 12)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + 11), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_12_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[7] >= 12 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_1_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 1)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_Sharp_1_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 1 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_2_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 2)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + 1), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_Sharp_2_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 2 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_3_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 3)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + 2), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_Sharp_3_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 3 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_4_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 4)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + 3), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_Sharp_4_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 4 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_5_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 5)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + 4), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_Sharp_5_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 5 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_6_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 6)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + 5), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_Sharp_6_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 6 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_7_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 7)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + 6), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_Sharp_7_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 7 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_8_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 8)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + 7), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_Sharp_8_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 8 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_9_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 9)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + 8), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_Sharp_9_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_10_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 10)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + 9), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_Sharp_10_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 10 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_11_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 11)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + 10), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_Sharp_11_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 11 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void G_Sharp_12_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 12)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + 11), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void G_Sharp_12_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[8] >= 12 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_1_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 1)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_1_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 1 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_2_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 2)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + 1), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_2_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 2 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_3_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 3)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + 2), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_3_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 3 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_4_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 4)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + 3), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_4_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[9] >=4 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_5_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 5)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + 4), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_5_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 5 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_6_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 6)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + 5), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_6_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 6 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_7_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 7)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + 6), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_7_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 7 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_8_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 8)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + 7), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_8_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 8 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_9_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 9)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + 8), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_9_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_10_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 10)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + 9), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_10_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 10 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_11_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 11)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + 10), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_11_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 11 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_12_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 12)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + 11), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_12_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[9] >= 12 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_1_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 1)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_Sharp_1_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 1 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_2_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 2)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + 1), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_Sharp_2_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 2 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_3_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 3)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + 2), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_Sharp_3_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 3 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_4_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 4)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + 3), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_Sharp_4_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 4 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_5_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 5)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + 4), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_Sharp_5_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 5 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_6_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 6)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + 5), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_Sharp_6_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 6 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_7_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 7)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + 6), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_Sharp_7_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 7 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_8_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 8)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + 7), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_Sharp_8_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 8 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_9_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 9)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + 8), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_Sharp_9_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_10_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 10)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + 9), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_Sharp_10_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 10 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_11_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 11)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + 10), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_Sharp_11_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 11 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void A_Sharp_12_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 12)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + 11), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void A_Sharp_12_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[10] >= 12 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void B_1_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 1)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + numcol[11]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void B_1_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 1 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void B_2_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 2)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 1 + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + numcol[11]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void B_2_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 2 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void B_3_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 3)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 2 + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + numcol[11]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void B_3_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 3 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void B_4_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 4)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 3 + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + numcol[11]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void B_4_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 4 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void B_5_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 5)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 4 + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + numcol[11]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void B_5_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 5 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void B_6_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 6)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 5 + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + numcol[11]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void B_6_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 6 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void B_7_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 7)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 6 + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + numcol[11]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void B_7_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 7 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void B_8_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 8)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 7 + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + numcol[11]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void B_8_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 8 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void B_9_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 9)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 8 + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + numcol[11]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void B_9_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 9 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void B_10_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 10)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 9 + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + numcol[11]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void B_10_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 10 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void B_11_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 11)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 10 + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + numcol[11]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void B_11_MouseUp(object sender, MouseEventArgs e)
        {
            if ( numcol[11] >= 11 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }

        private void B_12_MouseDown(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 12)
            {
                WaveSample wv = new WaveSample(base_freq * power(multiplier, 11 + numcol[1] + numcol[2] + numcol[3] + numcol[4] + numcol[5] + numcol[6] + numcol[7] + numcol[8] + numcol[9] + numcol[10] + numcol[11]), volume, wvtp, duty);
                sound = new DirectSoundOut();
                sounds.Add(sound);
                sound.Init(wv);
                sound.Play();
            }
        }

        private void B_12_MouseUp(object sender, MouseEventArgs e)
        {
            if (numcol[11] >= 12 && !hold)
            {
                sound.Stop();
                sounds.Remove(sound);
            }
        }
    }
    
}
